# Phase 2C-3 — Tile Lens / Local Mini-Map

Tile Lens is a visual inspection/navigation tool for large maps.

## Hover Lens
- Move the pointer onto a tile.
- Stay on the same tile for about 2 seconds.
- A temporary 5x5 magnified neighborhood opens.
- Moving off the map closes the unpinned lens.

## Pinned Lens
There are two ways to pin:
1. Hover until the lens opens, then press "Pin This Tile".
2. Set Tool = Tile Lens and click a tile.

The pinned source tile receives a double focus marker on the main map.

## 5x5 Lens
The selected tile is always the center.
The lens shows two neighboring cells in every direction.
At map edges, out-of-map cells are shown as neutral dark squares.

## Tile Stack
The lens lists every occupied layer on the center tile from highest render
layer to lowest. Elevation entries also show their physical height in feet.

## Authority
Tile Lens changes no map data.
It does not affect:
- seed
- coordinates
- ASCII
- render layer values
- elevation height
- generation
- overrides
- mechanics

## Later
Player View / Full (GM) View can eventually reuse this same lens and filter
hidden information without requiring a second map format.
