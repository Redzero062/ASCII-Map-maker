# Phase 4A — Live Bitmap Renderer

Large maps were slow because Tkinter Canvas had to own thousands of individual
rectangles, polygons, texture marks, lines and text objects.

Phase 4A changes only the live visual renderer:

- Pillow renders the battlefield into one bitmap.
- Tkinter displays that bitmap as one Canvas image.
- Terrain Pen preview still sits above it as lightweight Canvas overlay objects.
- Terrain layer membership is calculated once per frame instead of repeatedly
  for every layer of every cell.
- Natural-shape rendering reuses those precomputed cell sets.

No authoritative generation, coordinates, symbols, overrides, Castle theme,
Sea theme, Guide Lines, or Terrain Pen rules were changed.

When you change a visual setting, the status bar now includes the render time
in milliseconds.

This is Phase 4A only. Caching unchanged bitmaps and dirty-cell rendering belong
to later optimization passes if still needed.
