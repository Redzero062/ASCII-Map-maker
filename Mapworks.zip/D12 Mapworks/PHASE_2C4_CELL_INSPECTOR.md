# Phase 2C-4 — Tile Lens Cell Inspector

Version: 0.8.3-phase2c4-cell-inspector

## What changed

- The existing 5x5 Tile Lens is now the working cell editor.
- Hover still creates the 5x5 local view after the normal delay.
- Left-clicking any enlarged square locks the lens and selects that exact map cell.
- While locked, any of the 25 enlarged squares can be clicked for inspection/editing.
- The inspector uses a fixed 2x5 symbol-slot layout plus Height and Direction.
- Dropdown categories are intentionally broad and provisional so the legend audit can refine them after hands-on testing.
- Custom values are available for edge cases without expanding the permanent UI.

## Current fixed slots

1. Terrain Effect
2. Liquid
3. Obstruction
4. Cover
5. Trap State
6. Lighting
7. Misc 1
8. Misc 2
9. Special 1
10. Special 2
11. Height (ft)
12. Direction

## Authority / compatibility

Where a slot already has a direct legacy Universal equivalent, the inspector writes through to the existing authoritative layer data instead of creating a second terrain map. New semantic values are saved in per-cell structured metadata and included in the authoritative fingerprint/save file.

Regenerating a map clears manual cell-inspector data just as it already clears manual terrain overrides.

## Intent

This is a hands-on prototype for the upcoming legend audit. The point is to put the cell schema in the user's hands first, then adjust names, legal values, and relationships based on actual use instead of designing the final schema in prose.
