@echo off
setlocal
cd /d "%~dp0"

if not exist "app.py" (
    echo.
    echo ============================================================
    echo D12 MAPWORKS COULD NOT START
    echo ============================================================
    echo.
    echo app.py is not beside this launcher.
    echo.
    echo This usually means Windows is running this file directly
    echo from inside the ZIP instead of from an extracted folder.
    echo.
    echo FIX:
    echo 1. Close this window.
    echo 2. Right-click D12_Mapworks_Phase1B_FIXED_v2.zip
    echo 3. Choose "Extract All..."
    echo 4. Open the NEW extracted folder.
    echo 5. Double-click run_mapworks.bat there.
    echo.
    pause
    exit /b 1
)

python app.py
if errorlevel 1 (
    echo.
    echo D12 Mapworks stopped with an error shown above.
    pause
)
