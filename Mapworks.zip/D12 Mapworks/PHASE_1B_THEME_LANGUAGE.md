# Phase 1B — Theme Skin Language

## Authority boundary

The Universal remains the rule. The skin is only its physical presentation.

Example:

- Mechanical layer: `Rough Terrain`
- Tundra skin: `Broken Frozen Ground / Deep Snow`
- Tropical skin: `Roots / Mud / Ferns`

Changing from Tundra to Tropical does not regenerate the map and does not change the Rough Terrain coordinates.

## Rendering order

1. Read authoritative final cell/layer state.
2. Apply theme base color.
3. Draw deterministic theme texture details.
4. Draw art-only connectivity.
5. Draw the authoritative ASCII symbol on top when symbols are enabled.

## Deterministic decoration

Small decorative differences inside a tile are generated from:

`seed + visual theme + Universal + x coordinate + y coordinate`

This means the same map, theme, and coordinates produce the same tile decoration again without storing decoration as map data.

## Current theme families

- Generic
- Tundra
- Desert
- Forest
- Tropical
- Volcanic

Tundra and Tropical are the Phase 1B contrast pair used to prove that one mechanical battlefield can receive very different environmental skins without geometry drift.

## Corruption guard

Theme names, labels, colors, texture patterns, connective brush strokes, and decorative gap hints are visual-only. They are forbidden from writing to the seed, base layer coordinates, overrides, custom cells, or ASCII grid.
