# Phase 2B — Terrain Pen

This build adds the second Phase 2B tool only.

## Terrain Pen

Terrain Pen edits the authoritative map.

- Left-drag = paint the selected terrain layer.
- Right-drag = erase only the selected terrain layer.
- Pen Width = 1 through 7 cells.

Unlike Guide Line, Terrain Pen changes the map's override data and therefore changes
the authoritative ASCII result.

## Performance design

Dragging does NOT rebuild the entire map on every mouse movement.

During a stroke:
- authoritative cell edits are recorded;
- a lightweight preview is drawn.

On mouse release:
- Mapworks performs one complete redraw.

This is intentional because large maps were already showing redraw cost.

## Separation

Guide Line = visual-only direction.
Terrain Pen = authoritative terrain editing.

No curves, snapping, spline tools, or layer relationships are included in this build.
