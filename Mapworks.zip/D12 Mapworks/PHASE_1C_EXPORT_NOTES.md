# Phase 1C — Export / Print Notes

## Purpose

Phase 1C turns the current visual renderer into something that can leave the app cleanly.

The important boundary remains:

**ASCII / JSON = authoritative map.**  
**PNG / print HTML = visual presentation.**

## PNG controls

- Grid on/off
- ASCII symbols on/off
- Legend on/off
- Resolution scale 1x–6x

The map geometry does not change when these options change.

## Print output

Mapworks creates:
1. a visual PNG beside the print file;
2. an HTML print page that references that PNG.

The HTML can be opened in a normal browser and printed with the browser's Print Preview.

Supported page presets:
- Letter landscape
- Letter portrait
- A4 landscape
- A4 portrait

Large maps are fit to the page while preserving their aspect ratio.
