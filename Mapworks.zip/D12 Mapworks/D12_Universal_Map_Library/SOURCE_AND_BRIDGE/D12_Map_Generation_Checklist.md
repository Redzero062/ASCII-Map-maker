# D12 MAP GENERATION CHECKLIST
**Printable Working Draft - Map Generator / Playtest Workflow**

Use this as the run-through sheet for building a map from separate coordinate-matched layers.

---

## A. CANVAS
- [ ] Map width
- [ ] Map height
- [ ] Base ground established
- [ ] Coordinate system established

**Example**
- Size: 30 x 30
- Base: plain traversable ground
- Coordinates: A-AD / 1-30

---

## B. ENVIRONMENT RECIPE
- [ ] Named preset selected, if any
- [ ] Universal values loaded
- [ ] Uniquities loaded

**Example**
- Preset: Plains
- Uniquity: none
- Result: the preset pre-fills Universal settings; it is not a separate map system.

---

## C. DENSITY / OCCUPANCY
For each physical feature that will exist on the map:
- [ ] Density selected
- [ ] Occupancy pattern selected
- [ ] Coordinates established

**Working density language**
- None
- Sparse
- Some
- Many
- Dense

**Example**
- Vegetation: Many
- Rough Terrain: Some
- Hazards: Sparse

The density / occupancy layer answers **how much** and **where**, not what the feature looks like.

---

## D. DISTRIBUTION / SHAPE
- [ ] Distribution pattern selected for each applicable physical feature

**Possible distribution patterns**
- Blob
- Several Pockets
- Band / Strip
- Edge Intrusion
- Center Mass
- Crescent
- Ring
- Scattered Islands
- Branching / Veins
- Corridor / Channel

**Example**
- Vegetation: Many + Several Pockets
- Liquid: Some + Edge Intrusion

Same amount, different battlefield shape.

---

## E. PHYSICAL UNIVERSALS
Apply only the physical layers needed for the map.
- [ ] Rough Terrain
- [ ] Unstable Ground
- [ ] Half Obstructions
- [ ] Full Obstructions
- [ ] Hazards
- [ ] Vegetation
- [ ] Elevation
- [ ] Liquid Areas
- [ ] Routes / Passages
- [ ] Restricted Passages
- [ ] Vertical Connections

**Open Ground**
Open Ground is normally whatever usable space remains after the physical layers resolve.

**Example**
- Rough Terrain: Some
- Vegetation: Dense
- Elevation: Sparse
- Liquid: None

---

## F. FEATURE / ENVIRONMENT SKIN
- [ ] Convert occupied coordinates into environment-appropriate features
- [ ] Keep the underlying coordinates fixed
- [ ] Add Creator Notes where exact behavior is needed

**Example**
The same Half Obstruction coordinates could become:
- Forest: fallen logs / brush / rocks
- City: crates / carts / low walls
- Hostile Structure: tables / rubble / pillars
- Volcanic: basalt formations

The occupancy map decides **where**. The skin decides **what**.

---

## G. SETTINGS LAYER
These are Universal settings, but they are separate from the physical-density overlay.
- [ ] Time
- [ ] Temperature
- [ ] Lighting
- [ ] Weather
- [ ] Life / Survivability

**Example**
- Time: Midnight
- Temperature: Cold
- Weather: Light Rain
- Life: Some

### Lighting sub-check
- [ ] Ambient lighting established
- [ ] Light sources placed
- [ ] Light-source type recorded
- [ ] Light spread calculated
- [ ] Overlapping light resolved

**Working torch convention**
- Source square = zero point / origin
- First 15 ft outward = Fully Lit
- 20 ft = Partly Lit
- 25 ft = Dim
- 30 ft = Barely Visible
- 35+ ft = No Usable Light

---

## H. SCENARIO LAYER
Only add what the scenario actually needs.
- [ ] Primary Objective
- [ ] Points of Interest
- [ ] Interaction Points
- [ ] Mechanisms / Controls
- [ ] Known Dangers
- [ ] Hidden Dangers
- [ ] Special Scenario Markers

**Examples**
- Retrieve an object
- Activate a mechanism
- Investigate a point of interest
- No objective at all

A map does not automatically need combat or an objective.

---

## I. ACCESS / TRANSFER
- [ ] Entrance(s)
- [ ] Exit(s)
- [ ] Reinforcement entry, if any
- [ ] Transfers to another floor / map, if any

**Examples**
- West road entrance
- North extraction point
- Shaft transfers to lower map
- Reinforcements enter from east gate

---

## J. DEPLOYMENT
Deployment is separate from general access. It establishes where actors begin this specific scenario.
- [ ] Player deployment area / placement
- [ ] Enemy deployment area / placement
- [ ] Neutral NPC deployment, if needed
- [ ] Hidden / unrevealed deployment, if needed
- [ ] Reinforcement deployment timing / location
- [ ] Deployment legality checked against terrain and obstructions

**Examples**
- Players may deploy anywhere inside a 7 x 3 placement box.
- Enemies begin behind the eastern barricade.
- A neutral merchant begins inside the shelter.
- Reinforcements use the marked reinforcement entry on Round 4.

Deployment does not automatically establish hostility.

---

## K. CREATURE / ACTOR LAYER
- [ ] Players added
- [ ] Enemies / NPCs added
- [ ] Other creatures added
- [ ] Actor knowledge established
- [ ] Actor motives / immediate behavior established where needed

Actors decide what happens after setup. Placement alone does not force combat.

---

## L. CREATOR NOTES / METADATA
Add only when the visible symbol is not enough.
- [ ] Exact coordinates
- [ ] Height / depth
- [ ] Direction
- [ ] Distance / radius
- [ ] Force / movement
- [ ] Linked mechanism
- [ ] Destination
- [ ] Trigger
- [ ] Duration
- [ ] Hidden information
- [ ] Magical / mundane state where relevant

**Example**
`⌘ A`
- Trigger: lever pulled
- Controls: locked gate C12
- Duration: permanent until reset

---

## M. VALIDATION
Before play:
- [ ] Coordinate layers align
- [ ] Movement paths exist
- [ ] Restricted routes make sense
- [ ] Obstructions do not accidentally seal the map
- [ ] Elevation / vertical connections agree
- [ ] Lighting resolves correctly
- [ ] Entrances and exits are usable
- [ ] Deployment areas are legal
- [ ] Scenario elements are reachable where intended
- [ ] Impossible overlaps removed or intentionally explained

---

## N. PLAYTEST
- [ ] Run the scenario
- [ ] Let actors act from their own information and motives
- [ ] Record what breaks
- [ ] Record ambiguity
- [ ] Record unexpected useful behavior
- [ ] Keep successful patterns for the generator library

**Workflow reminder**
Build one layer at a time. Do not try to invent the finished map in one pass.

---

# SHORT FORM - GENERATION ORDER

1. Canvas
2. Environment Recipe
3. Density / Occupancy
4. Distribution / Shape
5. Physical Universals
6. Environment Skin
7. Settings
8. Scenario
9. Access / Transfer
10. Deployment
11. Creatures / Actors
12. Creator Notes
13. Validation
14. Playtest

**Core idea:** pre-generated randomness + coordinate-matched layers + environment skinning.
