# SOURCE REFERENCE NOTE

This package's generator bridge was developed using the following project sources:

- D12_Map_Generation_Checklist.md — current internal generation/playtest checklist.
- D12_Universal_Map_Library.zip — 30×30 reference pattern library and zero-state ground.
- D12_Density_Occupancy_Overlay_30x30.txt — neutral occupancy-density overlay.
- ASCII Legend.txt — reserved Universal map symbols.
- ASCII symbol meanings.txt — map semantics, metadata pattern, environment libraries, and earlier generation order.

For actual D12 encounter simulation, the generator must additionally consult the current:
- D12 Player Handbook.md
- Monster Manual.md
- GM.md

IMPORTANT:
The 30×30 maps are reference patterns only. They must be scaled/re-sampled to requested map dimensions.
Preset percentages are tile-quantity targets, not mandatory straight-edged rectangles.
Default percentage orientation is vertical left-to-right in the order requested unless the user specifies otherwise.
