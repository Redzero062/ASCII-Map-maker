# D12 MAP GENERATOR — BRIDGE SPECIFICATION & PROOF-OF-CONCEPT

**Purpose:** Preserve the working logic used to turn a short natural-language map request into layered ASCII generation, so another agent or a future Base44 implementation can reproduce the same process.

This file records the generator architecture, the scaling rules, the percentage rules, the prototype request parser, and the 46×51 Coast / Plains / Forest proof-of-concept.

---

## 1. CORE IDEA

The generator does NOT hand-author every possible finished map.

It uses a small library of reusable, coordinate-matched source layers and combines them.

Core principle:

> **Pre-generated randomness + mandatory constraints + coordinate-matched layers + environment skinning.**

The user supplies only the values they care about. Unspecified checklist fields may be generated.

The full internal checklist still exists so the generator always has a repeatable workflow.

---

## 2. MAPS MAY BE ANY SIZE

The 30×30 files are **reference-pattern masters**, not final-map-size restrictions.

Requested maps may use custom or intentionally strange proportions.

Examples:

- 30×30 = original reference size
- 60×30 = width is 200% of the reference width
- 30×75 = height is 250% of the reference height
- 60×75 = width ×2.0 and height ×2.5 compared with the 30×30 reference

Do NOT simply stretch ASCII characters like resizing an image.

Instead:

1. Convert the 30×30 pattern into normalized coordinate / shape information.
2. Scale the pattern independently in X and Y.
3. Scale quantities by total requested map area.
4. Preserve the general shape language: blobs, strips, pockets, edge intrusions, channels, etc.
5. Recalculate exact final coordinates on the requested map.

A density of about 16% on a 30×30 map occupies about 144 of 900 squares.
The same 16% on a 60×75 map occupies about 720 of 4,500 squares.

The percentage is therefore an **area / tile-count instruction**, not a fixed number of symbols.

---

## 3. PRESET PERCENTAGES = TILE QUANTITY

When terrain presets are supplied as percentages, the percentage describes approximately how many underlying map tiles belong to that preset.

Example:

- Coast 40%
- Plains 20%
- Forest 40%

The percentages are NOT instructions to draw perfectly straight rectangular bands.

### Default allocation direction

Unless the user says otherwise, preset percentages are allocated as **vertical slices** across the map.

The listed order controls left-to-right order.

Example:

> Coast 40%, Plains 20%, Forest 40%

means approximately:

> WEST = Coast  
> CENTER = Plains  
> EAST = Forest

### Natural boundary rule

Preset boundaries should look organic.

They may:

- wave back and forth;
- bulge into the neighboring preset;
- retreat;
- form a narrow finger / shoot into another area;
- create coves, pockets, peninsulas, or irregular edges.

A local boundary may normally wander about **2–3 rows or columns** away from its nominal division when doing so makes the geography feel natural.

The final tile quota should still remain reasonably faithful to the requested percentages.

When useful, the generator may compensate elsewhere along the boundary so one local intrusion is balanced by a retreat elsewhere.

---

## 4. TERRAIN TILES DO NOT OVERLAP

Each underlying ground/preset tile belongs to one primary preset.

For example, a square is Coast OR Plains OR Forest at the base-preset level.

However, the **visual-art stage may blend neighboring preset tiles**.

Examples:

- beach grass creeping into sand;
- tree roots crossing the forest edge;
- wet sand / marshy grass at a coast-plains transition;
- scattered trees extending a few visual feet into an open field.

This should be recorded as an **Editor / Visual Note**.

The visual blend does not mean the underlying generator tile belongs to two presets at once.

---

## 5. LAYER STACK

All backstage maps use the same final coordinate system.

Recommended working stack:

1. Canvas / Base Ground
2. Preset / Terrain Allocation
3. Density / Occupancy
4. Distribution / Shape
5. Physical Universals
6. Environment Skin
7. Settings
8. Scenario
9. Access / Transfer
10. Deployment
11. Creature / Actor Layer
12. Creator Notes / Metadata
13. Validation
14. Playtest / Simulation

The generator should complete one layer before passing the established coordinates to the next.

---

## 6. DENSITY / OCCUPANCY

Density answers:

> **How much of this feature exists, and where may it occupy space?**

Working density language:

- None
- Sparse
- Some
- Many
- Dense

The current rough-draft 30×30 library uses approximate reference values:

- None = 0%
- Sparse ≈ 6%
- Some ≈ 16%
- Many ≈ 32%
- Dense ≈ 52%

These values are working targets, not locked game rules.

The Density / Occupancy map is neutral.

It does NOT decide what an occupied tile physically looks like.

---

## 7. DISTRIBUTION / SHAPE

Distribution answers:

> **What shape does that amount take?**

Working examples:

- Blob
- Several Pockets
- Band / Strip
- Edge Intrusion
- Center Mass
- Crescent
- Ring
- Scattered Islands
- Branching / Veins
- Corridor / Channel

Example:

> Vegetation = Many  
> Distribution = Several Pockets

and

> Vegetation = Many  
> Distribution = Edge Intrusion

use a similar quantity but produce very different battlefields.

---

## 8. PHYSICAL UNIVERSALS

These are appropriate for coordinate / ASCII occupancy passes:

- Rough Terrain
- Unstable Ground
- Half Obstructions
- Full Obstructions
- Hazards
- Vegetation
- Elevation
- Liquid Areas
- Routes / Passages
- Restricted Passages
- Vertical Connections

Open Ground is normally the usable space remaining after other physical layers resolve.

The physical Universal layer establishes coordinates first.

The Environment Skin later decides what those coordinates mean in the selected preset.

Example:

**Half Obstruction coordinates**

- Forest → fallen log / brush / boulder
- City → cart / crates / low wall
- Hostile Structure → furniture / rubble / pillar base
- Volcanic → basalt formation

Same mechanical placement. Different physical representation.

---

## 9. SETTINGS UNIVERSALS

These are universal, but they are not treated as the same kind of physical occupancy layer:

- Time
- Temperature
- Lighting
- Weather
- Life / Survivability

Settings may apply to the whole map or, when necessary, to coordinate regions.

They should normally remain on a separate backstage Settings map.

---

## 10. LIGHTING

Reserved light-source symbols:

- `☀` = Strong Light Source
- `☼` = Normal Light Source
- `◌` = Weak / Dim Light Source

Working lighting-state language:

- `.` = Fully Lit
- `░` = Partly Lit
- `▒` = Dim
- `▓` = Barely Visible
- `█` = No Usable Light / Darkness

### Working torch convention

The torch's source square is the **zero point / origin**.

The source square does NOT consume 5 feet of the listed light distance.

From the edge of the source square:

- first 15 ft outward = Fully Lit
- 20 ft = Partly Lit
- 25 ft = Dim
- 30 ft = Barely Visible
- 35+ ft = No Usable Light

This remains a working playtest convention unless later promoted into a formal rule.

When light areas overlap, use the brightest applicable light state.

Actor-specific vision may alter the Effective Lighting Level without rebuilding the map itself.

---

## 11. ACCESS VS DEPLOYMENT

Access and Deployment are separate.

### Access / Transfer

Defines how the map connects to the world:

- entrance;
- exit / extraction;
- reinforcement entry;
- transfer to another floor or map.

### Deployment

Defines where actors begin THIS scenario:

- player deployment area;
- enemy deployment area;
- neutral actor placement;
- hidden placement;
- reinforcement placement/timing.

Deployment does not automatically establish hostility.

---

## 12. SCENARIO

Scenario information is added after the physical map exists.

Possible scenario elements:

- Primary Objective
- Point of Interest
- Interaction Point
- Mechanism / Control
- Known Danger
- Hidden Danger
- Special Scenario Marker

A generated map does not automatically require an objective or combat.

Actors retain their own motives and information.

---

## 13. CREATOR NOTES / METADATA

Visible ASCII tells us **WHAT IS THERE**.

Metadata tells us **WHAT IT DOES / EXACTLY HOW MUCH**.

Possible metadata:

- exact coordinates;
- height / depth;
- direction;
- radius / distance;
- force;
- linked mechanism;
- destination;
- trigger;
- duration;
- hidden information;
- magical / mundane state;
- visual blending instructions.

Visual transition example:

> Forest / Plains boundary: underlying tiles remain exclusive.  
> Art pass may blend grass, scattered saplings, roots, and brush across the boundary for 1–2 visual tiles.

---

## 14. SHORT-PROMPT / LAZY-MODE BRIDGE

The final goal is that the user should NOT need to fill the full checklist manually.

A short request can look like:

```text
Map 46x51
Coast 40%
Plains 20%
Forest 40%

3 full obstructions
Dense trees in forest
Open plains field
3 rough terrain regions
16 unknown hazards
3 known hazards

Night
Torches on ground 30 ft apart

3 Giant Crabs 2/3
5 Brown Bears 6/2

Player locations:
2 deployment areas 2x3
1 deployment area 2x1
7 players:
2 Ranged levels 8 and 7
3 Magic: level 10 Water/Ice, level 9 Fire/Wind, level 6 Healing
2 Melee levels 8 and 10

Scenario: hunt for food
Victory: kill 4 monsters and exit
Players start southwest
Exit southwest
```

The parser expands this into the internal checklist.

Anything explicitly supplied is mandatory.

Anything not supplied may be generated.

---

## 15. PROMPT PARSER / EXPANSION PROCEDURE

1. Parse requested width and height.
2. Build final coordinate grid.
3. Parse preset percentages.
4. Verify / normalize percentages when needed.
5. Allocate preset tile quotas.
6. Apply default vertical ordering unless the user gives another orientation.
7. Generate irregular preset boundaries while preserving tile quotas.
8. Scale / sample density and distribution reference patterns to the new canvas.
9. Apply explicitly requested physical features.
10. Generate unspecified physical details when allowed.
11. Apply environment skin to occupied coordinates.
12. Apply Settings.
13. Add scenario dangers / objectives.
14. Add access.
15. Add deployment.
16. Build / place creatures and player characters.
17. Add Creator Notes.
18. Validate coordinates, routes, lighting, deployment, and impossible overlaps.
19. Render ASCII / visual representation.
20. Run simulation if requested.

---

## 16. PROOF-OF-CONCEPT MAP REQUEST

Test request used:

- Map: 46×51
- Coast 40%
- Plains 20%
- Forest 40%
- Plains between Coast and Forest
- 3 Full Obstructions
- Dense trees in Forest
- Open field
- 3 Rough Terrain regions
- 16 Unknown Hazards
- 3 Known Dangers
- Night
- Ground torches 30 ft apart
- 3 Giant Crabs — Threat 2 / Tier 3
- 5 Brown Bears — Threat 6 / Tier 2
- 2 deployment areas at 2×3
- 1 deployment area at 2×1
- 7 players total
- 2 Ranged: Level 8 and Level 7
- 3 Magic: Level 10 Water/Ice; Level 9 Fire/Wind; Level 6 Healing
- 2 Melee: Level 8 and Level 10
- Scenario: Hunt for food
- Victory: kill 4 monsters and exit
- Players begin southwest
- Exit southwest

### Terrain allocation

46 × 51 = 2,346 underlying preset tiles.

Target allocation used for the proof of concept:

- Coast = 938 tiles
- Plains = 470 tiles
- Forest = 938 tiles

This preserves the requested 40% / 20% / 40% split as closely as whole tiles allow.

The prototype used WEST → EAST ordering:

> Coast → Plains → Forest

The borders were intentionally allowed to wave locally instead of using perfectly straight cuts.

---

## 17. PROTOTYPE DISPLAY SYMBOLS

Reserved / source-backed map symbols used:

- `▲` Player Placement / Entry
- `▶` Map Exit / Extraction
- `☼` Normal Light Source
- `⚠` Known Danger
- `¿` Unknown / Hidden Danger
- `▣` Full Cover / Full Obstruction

Generic physical symbol used:

- `r` Rough Terrain

Prototype-only temporary display symbols:

- `c` Coast tile
- `.` Plains / open ground tile
- `f` Forest floor
- `T` Dense forest tree / scenery
- `C` Giant Crab actor marker
- `B` Brown Bear actor marker

`C` and `B` were temporary test glyphs, not additions to the Universal reserved symbol language.

---

## 18. SIMULATION BRIDGE

Map generation and actual play simulation are separate stages.

Once the map is validated:

1. Build legal player sheets from the current Player Handbook.
2. Build legal monster sheets from the current Monster Manual.
3. Use the current GM / core rules for encounter adjudication.
4. Place actors according to deployment.
5. Establish each actor's knowledge and motives.
6. Do NOT force hostility merely because actors share a map.
7. Run initiative / exploration / combat as circumstances actually produce it.
8. Stop when the scenario victory / failure / retreat condition occurs.
9. Report turn count and emergent behavior.

For the food-hunt test:

> Success = at least 4 qualifying monsters are killed AND surviving players reach the designated exit.

The party may instead decide to retreat if their own behavior and situation lead them to do so.

---

## 19. VALIDATION RULES BEFORE RENDER / PLAY

Check:

- final map dimensions;
- preset tile totals;
- coordinate alignment across all backstage layers;
- no illegal base-preset overlap;
- movement paths remain possible;
- restricted passages make sense;
- full obstructions do not accidentally seal required routes unless intentional;
- lighting sources and gradients resolve;
- entrances / exits remain usable;
- deployment areas are legal;
- actors do not begin inside impossible terrain unless intentionally allowed;
- scenario objective can be completed;
- requested counts are satisfied;
- visual-editor notes exist for intentional blended boundaries.

---

## 20. FILES / SOURCES REFERENCED FOR THIS DESIGN

Future agents should use these files together rather than treating this bridge specification as a replacement for them.

### Map-system sources

**`D12_Map_Generation_Checklist.md`**
- Full generator / playtest workflow.
- Canvas → Environment Recipe → Density / Occupancy → Distribution → Physical Universals → Skin → Settings → Scenario → Access → Deployment → Actors → Creator Notes → Validation → Playtest.

**`D12_Universal_Map_Library.zip`**
- 30×30 zero-state ground.
- Rough-draft physical Universal pattern library.
- None / Sparse / Some / Many / Dense reference patterns.
- Settings notes.
- These are reference patterns, NOT final map-size restrictions.

**`D12_Density_Occupancy_Overlay_30x30.txt`**
- Neutral density / occupancy overlay concept.
- Separates "how occupied is this region?" from "what physical feature is there?"

**`ASCII Legend.txt`**
- Reserved Universal map symbols.
- Entry / Exit / Deployment.
- Lighting source symbols.
- Known / Unknown danger markers.
- Cover markers.
- Generic terrain vocabulary.

**`ASCII symbol meanings.txt`**
- Map language explanation.
- Environment vs mechanical effect vs metadata.
- Environment libraries.
- Metadata format.
- Earlier map-generation order.
- Used as supporting map-language reference.

### Gameplay / simulation sources

For an actual D12 play simulation, use the current authoritative gameplay sources:

**`D12 Player Handbook.md`**
- Player creation, Jobs, Magic Schools, equipment, combat, derived values.

**`Monster Manual.md`**
- Monster construction and monster operation.

**`GM.md`**
- GM adjudication / map-scale / scenario-support rules where applicable.

The map-generator library should NOT silently replace gameplay rules from those books.

---

## 21. BASE44 / DIGITAL IMPLEMENTATION NOTE

This architecture is suitable for a future Base44 or digital tutorial interface.

A simple front end could expose only:

- Width × Height
- Preset percentages
- Orientation/order
- Requested objects/features
- Settings
- Scenery notes
- Actors
- Scenario / Victory

An "Advanced" view could expose the full internal checklist.

The backend can keep each layer as coordinate data and render:

1. ASCII for development / debugging;
2. visual tiles for player-facing maps;
3. hidden GM layers for hazards, deployment, triggers, and metadata;
4. tutorial overlays that reveal one layer at a time.

This allows the same generator architecture to power:
- tabletop encounter generation;
- digital tutorial maps;
- random battle maps;
- scenario simulation;
- later visual map rendering.

---

## 22. DO NOT LOSE THESE PRINCIPLES

1. **Percentages mean tile quantity, not ruler-straight borders.**
2. **Vertical slices are the default orientation when preset percentages are supplied without another orientation.**
3. **Natural borders may wander locally by roughly 2–3 rows/columns.**
4. **Underlying preset tiles do not overlap.**
5. **Visual artwork may blend neighboring preset types; record that in Editor Notes.**
6. **30×30 is a reusable reference library, not a final-size restriction.**
7. **Scale pattern logic and quantities, not ASCII pixels.**
8. **All backstage layers share coordinates.**
9. **Occupancy decides where; environment skin decides what.**
10. **Settings remain separate from physical occupancy where appropriate.**
11. **Access and Deployment are different systems.**
12. **Placement does not force hostility.**
13. **Build one layer at a time.**
14. **Validate before simulation.**
15. **The user's short prompt should eventually be enough; the checklist belongs inside the generator.**
