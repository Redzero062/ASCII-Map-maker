# D12 Universal Map Pattern Library — Rough Draft

Purpose: build reusable 30x30 source layers before combining them.

## Zero-State Ground
`00_BASE_GROUND/Ground_30x30.txt` is the original 30x30 plain-ground texture.

## Physical Universals
Each physical Universal has separate None / Sparse / Some / Many / Dense pattern files.

Working density targets:
- None = 0%
- Sparse ≈ 6%
- Some ≈ 16%
- Many ≈ 32%
- Dense ≈ 52%

These are rough draft targets, not locked rules.

## Settings Universals
Temperature, Lighting, Weather, Time, and Life are stored separately because they are universal but are not part of the same physical-density overlay experiment.


## Visual Rules
`03_VISUAL_RULES` contains presentation rules for converting the established mechanical / ASCII map into a readable finished battle map. Visual rules do not replace mechanical Settings or Physical Universals.

Current locked visual direction: static-map lighting uses readable tonal grading, with torches rendered as a warm gold / amber center falling into cool blue-gray ambient darkness. Fog of war and blackout remain deferred optional add-ons.

## Coordinate Principle
All 30x30 physical layers share the same coordinate footprint. Later they can be overlaid, cropped, rotated, offset, or combined while preserving coordinate alignment.

## Current Work Rule
Do not combine the physical layers yet. Build and inspect the raw library first.
