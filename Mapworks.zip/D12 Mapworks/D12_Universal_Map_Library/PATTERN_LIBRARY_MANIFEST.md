# Physical Pattern Library

- Rough Terrain
- Unstable Ground
- Half Obstructions
- Full Obstructions
- Hazards
- Vegetation
- Elevation
- Liquid Areas
- Routes Passages
- Restricted Passages
- Vertical Connections

Each contains: None, Sparse, Some, Many, Dense.
