# Life / Survivability
Universal setting describing how readily the area supports living things rather than simply counting placed creatures.

Working scale:
- None
- Sparse
- Some
- Many
- Dense
- Abundant

This can influence vegetation, wildlife, insects, habitation signs, etc., without directly placing actors on the map.
