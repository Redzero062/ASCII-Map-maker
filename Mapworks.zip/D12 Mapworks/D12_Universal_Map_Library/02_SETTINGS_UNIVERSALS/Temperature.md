# Temperature
Universal setting, not part of the current 30x30 density-overlay test.

Working scale:
- Extreme Cold
- Cold
- Mild
- Warm
- Hot
- Extreme Hot

May later be map-wide or coordinate-based when a scenario needs localized temperature.
