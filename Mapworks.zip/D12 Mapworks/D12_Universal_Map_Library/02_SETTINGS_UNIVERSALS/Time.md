# Time
Universal scenario setting, not an ASCII density overlay.

Time and Lighting are separate.
Time may influence likely lighting, weather, traffic, life, and scenario behavior, but does not replace those settings.
