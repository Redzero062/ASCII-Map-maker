# Weather
Universal setting, not part of the current density-overlay pattern library.

Examples:
- Clear
- Cloudy
- Rain
- Heavy Rain
- Wind
- Storm
- Snow
- Fog / Mist
- Ash / Dust / Sand

Exact categories and mechanical effects remain future work.
