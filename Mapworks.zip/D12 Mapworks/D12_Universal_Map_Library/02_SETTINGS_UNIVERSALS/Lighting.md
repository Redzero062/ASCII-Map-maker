# Lighting
Universal setting layer, handled separately from physical density overlays.

Working light-state language:
- `.` Fully lit
- `░` Partly lit
- `▒` Dim
- `▓` Barely visible
- `█` No usable light / darkness

Light-source symbols:
- `☀` Strong light source
- `☼` Normal light source
- `◌` Weak / dim light source

Torch working playtest convention:
- Torch source square = zero point / origin.
- The source square does not consume the torch's listed distance.
- First 15 ft outward from the source square = Fully Lit.
- 20 ft = Partly Lit.
- 25 ft = Dim.
- 30 ft = Barely Visible.
- 35+ ft = No Usable Light.

This remains a working playtest convention rather than a locked book rule.

## Visual Rendering Relationship

This file owns the mechanical light-state language and working torch distances.

The finished static battle-map presentation is defined separately in:

`03_VISUAL_RULES/Lighting_Tonal_Standard.md`

The visual standard uses readable tonal grading rather than literal map blackout. It does not change the mechanical Lighting values recorded here.

