# D12 MAP GENERATOR — VISUAL RULES

Purpose: define how the finished mechanical map is translated into readable visual battle-map art.

## Authority Boundary

Visual Rules do **not** change map mechanics.

- `00_BASE_GROUND` owns the base canvas source.
- `01_PHYSICAL_UNIVERSALS` owns physical feature placement logic.
- `02_SETTINGS_UNIVERSALS` owns settings such as Time, Weather, Temperature, Life, and mechanical Lighting states.
- `03_VISUAL_RULES` owns how those established coordinates and settings are visually represented in a finished static battle map.
- `SOURCE_AND_BRIDGE` owns the generation workflow and bridge logic.

The ASCII / coordinate layers remain the mechanical truth. The visual map is a readable environment skin and presentation layer built from that truth.

## Visual-Pass Rule

Do not invent a new battlefield function merely because the visual map needs detail.

Examples:

- ASCII Full Obstruction -> visual boulder, wall, massive trunk, machinery, etc.
- ASCII Vegetation -> environment-appropriate trees, brush, cactus, reeds, fungi, etc.
- ASCII Elevation -> readable slope, shelf, mesa, ledge, stair, or other appropriate elevation art.
- ASCII Liquid Area -> visually appropriate water, mud, lava, acid, magical pool, etc.

The visual artist / renderer may add cosmetic detail, texture, debris, color variation, shadows, and natural transitions so long as those additions do not silently create new mechanical terrain.

## Readability Rule

A static battle map must remain readable and usable by humans.

Visual atmosphere may communicate danger, darkness, weather, heat, cold, magic, or other conditions, but it must not obscure the map so severely that terrain, routes, obstacles, actors, objectives, or grid relationships become unusable.

Exact mechanical behavior remains in the ASCII layers, metadata, and editorial notes.

## Current Visual Standards

- `Lighting_Tonal_Standard.md` — locked visual lighting direction for static maps and torch falloff.

## Optional Future Visual Systems

The following are intentionally **not** part of the base static-map standard at this stage:

- Fog of war
- Blackout overlays
- Hidden-area reveal masks
- Dynamic VTT lighting
- Continuously updated player-visibility masks

These may later exist as optional overlays or digital features without changing the base readable-map standard.
