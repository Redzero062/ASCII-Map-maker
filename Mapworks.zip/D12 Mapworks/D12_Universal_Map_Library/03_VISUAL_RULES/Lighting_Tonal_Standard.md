# D12 VISUAL LIGHTING STANDARD — TONAL LIGHTING

**Status: Locked visual direction for static battle maps.**

## 1. Core Principle

Lighting on a finished static battle map is represented through **tone and value grading**, not literal darkness simulation.

The map must remain readable and usable by human viewers even when the mechanical lighting state is extremely dark or provides no usable character visibility.

The visual map communicates the light state.
The Lighting setting, ASCII layers, metadata, and editorial notes define the exact mechanical visibility.

> **Tone communicates darkness. Mechanical rules determine sight.**

## 2. Tone, Not Simple Tint

The lighting pass should primarily control:

- value / brightness;
- saturation;
- warmth versus coolness;
- local contrast;
- clarity / softness at the edge of light.

Do not treat night lighting as merely placing a transparent blue color over the finished image.

The objective is a deliberate tonal grade that preserves terrain identity while clearly communicating the lighting condition.

## 3. Ambient Darkness Standard

For night, underground, dungeon, or otherwise dark environments:

- preserve enough terrain detail for practical play;
- shift the ambient scene cooler and darker;
- reduce saturation outside active light sources;
- soften contrast outside active light sources;
- maintain grid, route, obstruction, elevation, objective, and actor readability.

A mechanically dark area may therefore remain visibly represented on the static map. This is intentional and is **not** a statement that the characters can see that area normally.

## 4. Torch Visual Identity — Locked

A torch uses a **warm-center to cool-ambient radial tonal gradient**.

Visual progression:

1. **Torch Core / Source** — warm golden-yellow; highest local clarity.
2. **Fully Lit** — warm gold / warm amber; strong readable color and contrast.
3. **Partly Lit** — softer amber; slightly reduced warmth and contrast.
4. **Dim** — neutral-to-cool transition; reduced saturation and darker value.
5. **Barely Visible** — cool blue-gray ambient darkness; low contrast but still map-readable.
6. **No Usable Light** — darkest readable ambient tone; the visual map remains usable while the mechanical note controls actual character visibility.

The desired visual identity is:

> **warm gold center -> amber falloff -> neutral transition -> cool blue-gray darkness**

## 5. Torch Mechanical Relationship

This Visual Standard does not replace `02_SETTINGS_UNIVERSALS/Lighting.md`.

Use the current Lighting setting for the actual torch bands and distances. The visual renderer maps those established bands onto the tonal progression above.

Current working torch convention from the Lighting setting:

- Source square = zero point / origin.
- First 15 ft outward = Fully Lit.
- 20 ft = Partly Lit.
- 25 ft = Dim.
- 30 ft = Barely Visible.
- 35+ ft = No Usable Light.

If those mechanical distances are revised later, the visual identity remains the same unless this file is explicitly revised.

## 6. Static No-Light Rule — Locked

**No Usable Light does not mean a black static map.**

For static battle maps:

- use the darkest readable ambient tonal grade;
- preserve enough geometry and terrain information for human use;
- do not erase or black out the battlefield;
- record the actual visibility restriction in editorial notes / map metadata.

Suggested editorial note language:

> **Visual map is readability-adjusted. Actual character visibility is governed by the map's Lighting setting and scenario rules.**

## 7. Gradient Use

Use visible tonal gradients when a local light source affects only part of the map.

This is especially appropriate for:

- torches;
- lanterns;
- campfires;
- braziers;
- magical lights;
- glowing crystals;
- lava / heat glow;
- bioluminescent sources;
- other localized illumination.

The gradient should communicate changing light state without becoming a precise substitute for the mechanical radius metadata.

## 8. Multiple Light Sources

When light sources overlap:

- preserve the established mechanical overlap result from the Lighting setting / metadata;
- blend tonal fields naturally in the visual pass;
- avoid muddying the map with excessive opaque overlays;
- prioritize clear terrain and grid readability.

The renderer may blend visual warmth smoothly even when the underlying mechanical bands remain discrete.

## 9. Editorial Notes Relationship

The visual map communicates **how the light feels**.

Editorial notes / metadata communicate:

- ambient light state;
- light-source coordinates;
- light-source type;
- mechanical radius / distance;
- directional lighting when relevant;
- duration;
- magical or mundane source;
- special exceptions;
- actual visibility rule.

Do not force the image itself to carry information more reliably handled by metadata.

## 10. Fog of War / Blackout — Deferred Optional Add-On

Fog of war is **not** part of the base static-map lighting standard.

Do not continuously update static maps to reproduce player visibility.

Possible later optional systems:

- blackout overlay;
- fog-of-war mask;
- hidden-room overlay;
- GM reveal layer;
- VTT dynamic lighting.

These are add-ons. They do not replace the readable base battle map.

## 11. Rendering Pipeline Position

The lighting visual pass happens only after the mechanical map and Settings have been established.

Recommended relationship:

1. Generate mechanical / coordinate truth.
2. Apply Environment Skin.
3. Resolve Settings, including mechanical Lighting.
4. Finish Scenario / Access / Deployment / Actors / Metadata.
5. Validate the map.
6. Render the finished visual battle map.
7. Apply the tonal lighting presentation according to the already-established Lighting state.

The visual pass must never silently rewrite the mechanical map.
