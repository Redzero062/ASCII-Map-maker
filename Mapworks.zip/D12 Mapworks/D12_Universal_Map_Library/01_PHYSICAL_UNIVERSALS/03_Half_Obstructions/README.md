# Half Obstructions

Layer symbol: `▤`

Universal half-cover / half-obstruction marker.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
