# Restricted Passages

Layer symbol: `x`

Working restricted-passage symbol only; metadata defines lock, boulder, force wall, puzzle, etc.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
