# Routes Passages

Layer symbol: `=`

Working route/passage-layer symbol. Connected density is represented by linked bands.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
