# Vegetation

Layer symbol: `v`

Working vegetation-layer symbol only; preset/metadata decides grass, brush, trees, canopy, etc.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
