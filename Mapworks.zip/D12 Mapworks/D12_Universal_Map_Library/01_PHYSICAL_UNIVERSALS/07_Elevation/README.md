# Elevation

Layer symbol: `^`

Working elevation-layer symbol; exact rise/drop/plateau detail can be assigned later.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
