# Full Obstructions

Layer symbol: `▣`

Universal full-cover / full-obstruction marker.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
