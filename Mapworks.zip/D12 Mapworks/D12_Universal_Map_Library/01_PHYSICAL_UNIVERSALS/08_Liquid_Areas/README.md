# Liquid Areas

Layer symbol: `~`

Liquid-area placeholder; metadata determines water, lava, acid, mud, etc.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
