# Vertical Connections

Layer symbol: `↑`

Working vertical-connection marker; later may use ↑ / ↓ / ⇅ by connection type.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
