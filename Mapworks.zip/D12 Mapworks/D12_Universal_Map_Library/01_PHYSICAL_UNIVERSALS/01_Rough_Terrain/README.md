# Rough Terrain

Layer symbol: `r`

Rough terrain layer.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
