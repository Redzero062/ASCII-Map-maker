# Unstable Ground

Layer symbol: `u`

Working layer symbol only; metadata can later define thin ice, loose scree, collapsing floor, etc.

Working density targets (rough draft, not locked):
- None: 0%
- Sparse: ~6%
- Some: ~16%
- Many: ~32%
- Dense: ~52%
