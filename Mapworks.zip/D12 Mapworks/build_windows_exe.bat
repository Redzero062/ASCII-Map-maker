@echo off
setlocal
cd /d "%~dp0"

echo Installing/updating build tools...
python -m pip install --upgrade pyinstaller Pillow
if errorlevel 1 goto :fail

echo.
echo Building D12 Mapworks Phase 1D...
python -m PyInstaller --noconfirm --clean --windowed --name D12_Mapworks ^
  --add-data "D12_Universal_Map_Library;D12_Universal_Map_Library" ^
  app.py
if errorlevel 1 goto :fail

echo.
echo BUILD COMPLETE
echo EXE: %CD%\dist\D12_Mapworks\D12_Mapworks.exe
echo.
echo Open that EXE. The left panel should contain:
echo   Visual Theme
echo   Smart art connectivity
echo   Theme texture details
pause
exit /b 0

:fail
echo.
echo BUILD FAILED. See the messages above.
pause
exit /b 1
