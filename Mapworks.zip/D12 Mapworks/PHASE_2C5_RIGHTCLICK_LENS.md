# Phase 2C-5 — Right-Click Tile Lens Lock

## Change
When the 5×5 Tile Lens appears after hover, right-click the main map to lock the currently displayed lens in place.

Once locked:
- moving the mouse away no longer closes the lens,
- left-click any enlarged square inside the 5×5 lens to select/edit that exact tile,
- `Close / Unpin` releases it.

## Safety
The right-click lock only overrides normal right-click behavior while an unpinned hover lens is visibly open.
After the lens is pinned, right-click returns to the currently selected map tool behavior.
