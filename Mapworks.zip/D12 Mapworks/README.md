# D12 Mapworks — Phase 2C-3 Tile Lens

Version: 0.8.2-phase2c-tile-lens

This build adds deterministic theme texture/pattern language on top of the exact Phase 1A map geometry. Theme art remains display-only.

See `PHASE_1_CHECKLIST.md`. **Stop after Phase 1C validation** before Phase 1D.

# D12 Mapworks — Windows MVP 0.1

A local-first deterministic grid map generator/editor built from the D12 Universal Map Pattern Library.

## What this build does

- deterministic seed generation;
- arbitrary map sizes from 5×5 through 120×120;
- all 11 current Physical Universal layers;
- None / Sparse / Some / Many / Dense generation;
- ASCII view;
- color tile view;
- interactive layer selection;
- left-click to toggle the selected layer on a cell;
- right-click to erase map layers from a cell;
- custom markers;
- save/load `.d12map` files;
- reset overrides without changing the seed;
- **Copy Map** to clipboard;
- export authoritative ASCII `.txt`;
- export structured `.json`;
- print-friendly `.html`;
- optional `.png` tile preview when Pillow is installed;
- one-click **Export Bundle** for handing the map to another AI or archiving it.

## Important architecture

The picture is not the map.

The authoritative map is the saved coordinate/layer data plus the final ASCII representation. Tile colors are a visual skin over that data.

That means a future tileset can completely change appearance without changing the map itself.

## Running from Python on Windows

1. Install Python 3.11+ from python.org.
2. Open this folder in File Explorer.
3. Double-click `run_mapworks.bat`.

PNG export is optional. `run_mapworks.bat` attempts to install Pillow if needed.

## Building a Windows EXE

Double-click:

`build_windows_exe.bat`

It installs PyInstaller + Pillow and builds:

`dist\D12_Mapworks\D12_Mapworks.exe`

The bundled Universal Map Library is included in the build.

## Exporting for AI rendering

Use **Export Bundle**.

The `.txt` file contains:

- map name;
- seed;
- dimensions;
- terrain label;
- layer densities;
- legend;
- final ASCII grid;
- creator notes.

The `.json` file contains structured state and coordinates.

A useful handoff instruction is:

> Render this map visually while preserving its grid layout, coordinate relationships, obstacles, hazards, routes, elevation, liquid, and creator notes. Do not move map features unless explicitly asked.

## Seed rule

The generator uses stable hashing instead of Python's session-dependent `hash()` function. The same app version, seed, dimensions, density settings, and source library produce the same generated layers.

Manual edits are stored separately as overrides.

## Current MVP limits

- Environment skinning is still a label, not a full per-biome sprite system.
- Distribution/shape selection is not exposed yet; the source pattern library provides the shape language and the seed transforms it.
- Lighting/settings/scenario/deployment layers are not yet interactive editor layers.
- PNG rendering is intentionally simple; ASCII/TXT/JSON are the authoritative exports.

These are sensible next milestones after validating the desktop workflow.

## Phase 2C-4 — Tile Lens Cell Inspector
The 5x5 Tile Lens now doubles as the cell editor. Click an enlarged square to pin/select it, then use the fixed dropdown slots for Terrain Effect, Liquid, Obstruction, Cover, Trap State, Lighting, two Misc slots, two Special slots, Height, and Direction. See `PHASE_2C4_CELL_INSPECTOR.md`.
