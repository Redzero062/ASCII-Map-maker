# D12 MAPWORKS — PHASE 1 VISUAL GENERATOR CHECKLIST

Current build: **0.5.0-phase1d**

## Governing rule

**Map data is authoritative. Visual art is interpretive.**

The renderer may infer how neighboring art connects, but it must never create, delete, move, or reclassify a map cell.

A visual guess must never modify:
- seed
- dimensions
- base layers
- overrides
- custom cells
- final ASCII
- JSON coordinates
- mechanical meaning

If the visualizer is disabled, the authoritative map must remain identical.

---

# PHASE 1A — Faithful Renderer

## A1. Exact cell fidelity
- [x] Every visual tile occupies the same row/column as its authoritative map cell.
- [x] Tile View is generated from the same final ASCII/layer state as ASCII View.
- [x] Symbols can remain visible on top of tiles for auditing.
- [x] Theme changes do not regenerate or move map data.

## A2. Visual theme framework
- [x] Generic theme
- [x] Tundra theme
- [x] Desert theme
- [x] Forest theme
- [x] Tropical theme
- [x] Volcanic theme
- [x] Visual theme saved with `.d12map`
- [x] Older saved maps default safely to Generic

## A3. Smart art connectivity
These symbols may visually connect when neighboring copies form a pattern:

`  r  =  x  ↑  u  ^  v

- [x] Cardinal neighbors can connect visually.
- [x] Diagonal neighbors can connect visually.
- [x] An isolated symbol does not invent surrounding map data.
- [x] An open cell may receive a faint decorative bridge only when at least **two matching diagonal cues** surround it.
- [x] The decorative bridge is render-only.
- [x] Smart connectivity can be turned off for a strict square-by-square view.
- [x] Backtick is recognized as an art-side Darkness connector if used by a custom/imported map.
- [x] Backtick alone does **not** create mechanical darkness.

## A4. Corruption guard
- [x] Connectivity code reads ASCII but never writes ASCII.
- [x] Connectivity code never edits layer coordinates.
- [x] Connectivity code never edits overrides.
- [x] Connectivity code never edits custom cells.
- [x] Save/load remains authoritative-data only.

## A5. Phase 1A validation before moving on
- [ ] Launch Windows build.
- [ ] Generate one map.
- [ ] Screenshot/compare ASCII View against Tile View.
- [ ] Verify row count and column count match.
- [ ] Switch through all six themes; map geometry must not change.
- [ ] Toggle Smart Art Connectivity off/on; ASCII must not change.
- [ ] Save map with a theme selected.
- [ ] Close program.
- [ ] Reload map.
- [ ] Verify theme and connectivity setting persist.
- [ ] Export PNG.
- [ ] Verify PNG matches Tile View.
- [ ] Export JSON before and after toggling visual settings.
- [ ] Verify map coordinates remain identical.

**STOP HERE until Phase 1A passes.**

---

# PHASE 1B — Theme Skin Language

Phase 1B is now implemented. Human/UI validation remains before Phase 1C.

- [x] Define what each Universal looks like in each theme.
- [x] Add simple texture/pattern vocabulary instead of only flat colors.
- [x] Create environment-specific visual substitutions.
- [x] Allow themes to distinguish the same mechanic visually.
- [x] Keep the mechanical category visible beside the theme-specific visual label.
- [x] Tundra implemented as the first reference skin.
- [x] Tropical implemented as the contrasting reference skin.
- [x] Deterministic texture variation uses seed + theme + layer + coordinate.
- [x] Theme texture details can be turned off without changing map data.

## Phase 1B validation gate

- [ ] Open one saved/generated map in **Tundra**.
- [ ] Confirm tiles visibly suggest frozen ground, broken ice/snow, ice cracks, frozen vegetation, slopes, water, routes, and fissures.
- [ ] Without regenerating, switch the same map to **Tropical**.
- [ ] Confirm the geometry is identical while the tiles now suggest humid ground, roots/mud, jungle vegetation, water, paths, and tangled restrictions.
- [ ] Switch Theme Texture Details off/on; ASCII must remain identical.
- [ ] Switch Smart Art Connectivity off/on; ASCII must remain identical.
- [ ] Save and reload; theme + texture setting must persist.
- [ ] Export a PNG in Tundra and Tropical from the same map and compare coordinates.
- [ ] Export JSON before and after theme changes; base layer coordinates and overrides must remain identical.

**STOP HERE until Phase 1B passes. Do not begin Phase 1C yet.**

---

# PHASE 1C — Visual Export / Print

Phase 1C is implemented. Human/UI verification is the remaining gate.

- [x] Print-friendly visual HTML page.
- [x] PNG export at screen resolution.
- [x] Higher-resolution PNG export from 1x through 6x.
- [x] Optional grid on/off for exported image.
- [x] Optional ASCII symbols on/off for exported image.
- [x] Optional legend on/off.
- [x] Letter portrait and landscape setup.
- [x] A4 portrait and landscape setup.
- [x] Pixel-size and approximate 300-DPI physical-size estimate.
- [x] TXT/JSON remain separate authoritative exports.
- [x] Visual print page states that it is not authoritative map data.

## Phase 1C validation gate

- [ ] Load a known saved map.
- [ ] Open **Print / Export Setup**.
- [ ] Export a 1x PNG with grid + symbols.
- [ ] Export a 2x or 3x PNG and confirm it is larger/sharper.
- [ ] Export with grid off and confirm the geometry stays identical.
- [ ] Export with symbols off and confirm the terrain stays in the same cells.
- [ ] Export with legend on and confirm it describes the active theme.
- [ ] Create a **Letter - Landscape** print page.
- [ ] Open the HTML in a browser and check Print Preview.
- [ ] Confirm the map keeps its aspect ratio.
- [ ] Repeat once with the 97×56 ice-sheet stress-test map.
- [ ] Confirm export options never alter map coordinates or overrides.

**STOP HERE until Phase 1C passes. Do not begin Phase 1D yet.**

# PHASE 1D — Combined Regression

Phase 1D is implemented. This phase adds no new map art. It tests the stack.

- [x] Automated same-seed determinism check.
- [x] Automated different-seed placement check.
- [x] Automated visual-theme authority guard.
- [x] Automated Smart Connectivity authority guard.
- [x] Automated texture-detail authority guard.
- [x] Automated export-setting authority guard.
- [x] Automated save/load model round-trip.
- [x] Automated override persistence check.
- [x] Automated Reset Overrides isolation check.
- [x] Automated authoritative ASCII rectangularity check.
- [x] Self-test restores the live user map after testing.
- [x] Self-test report can be saved as TXT.
- [ ] Run self-test against the 97×56 ice-sheet stress-test map on Windows.
- [ ] Confirm all automated checks show PASS.
- [ ] Manually toggle Tundra/Tropical once after self-test.
- [ ] Manually export one PNG after self-test.
- [ ] Confirm the live map did not change.
- [ ] Record the existing UI/render-performance issue separately; functionality must remain correct.

## Phase 1 completion gate

When the Windows self-test passes and the live map remains unchanged:

**PHASE 1 — COMPLETE**

Known non-blocking optimization note:
Large maps with many Canvas objects can cause visible Windows/Desktop redraw behavior. Optimize rendering in the later performance pass without changing map authority or Phase 1 behavior.


# PHASE 2A — Natural Terrain Shape Renderer

- [x] Shape Style control: Strict / Connected / Natural.
- [x] Edge Strength control: Low / Medium / High.
- [x] Supported terrain region set isolated from routes/network symbols.
- [x] Connected mode removes internal formation borders.
- [x] Natural mode adds deterministic edge irregularity.
- [x] Natural irregularity stays inside authoritative cells.
- [x] Theme changes remain visual-only.
- [x] Shape settings saved in map state.
- [x] Shape settings excluded from authoritative fingerprint.
- [ ] Windows human test: Strict.
- [ ] Windows human test: Connected.
- [ ] Windows human test: Natural.
- [ ] Windows human test: Edge Strength Low/Medium/High.
- [ ] Windows human test: Tundra/Tropical geometry unchanged.
- [ ] Large-map performance acceptable enough to continue.

**STOP after 2A validation. Do not start 2B until 2A passes.**


# PHASE 2B — Guide Line Editor (Tool 1 only)

- [x] Visual Guide Line data model.
- [x] Uses selected supported terrain layer.
- [x] Two-click start/end creation.
- [x] Width 1–7.
- [x] Influence clipped to existing target terrain.
- [x] Live canvas rendering.
- [x] PNG export rendering.
- [x] Undo Last Guide.
- [x] Clear Guides.
- [x] Right-click cancels pending guide.
- [x] Save/load persistence.
- [x] Visual guides excluded from authoritative fingerprint.
- [x] ASCII/base/overrides remain unchanged.
- [ ] Windows test: width 1.
- [ ] Windows test: width 3.
- [ ] Windows test: Undo.
- [ ] Windows test: Clear.
- [ ] Windows test: save/reload.
- [ ] Confirm ASCII unchanged.

STOP HERE. Do not add Terrain Pen or layer relationships yet.


# PHASE 2B — Terrain Pen (Tool 2)

- [x] Terrain Pen added to tool selector.
- [x] Left-drag paints authoritative selected terrain.
- [x] Right-drag erases only authoritative selected terrain.
- [x] Pen Width 1–7.
- [x] Re-visiting a cell in one stroke does not toggle it back off.
- [x] Generated base remains separate from overrides.
- [x] Painting a previously removed base cell cancels the removal.
- [x] Erasing a generated base cell creates an override removal.
- [x] Dragging avoids full-map redraw per mouse movement.
- [x] Full redraw occurs once at stroke release.
- [x] Guide Line remains separate and visual-only.
- [ ] Windows test: width 1 paint.
- [ ] Windows test: right-drag erase.
- [ ] Windows test: width 3 paint.
- [ ] Windows test: save/reload painted terrain.
- [ ] Confirm ASCII changes exactly with authoritative edits.

STOP HERE before adding another editing tool.


# THEME EXPANSION — CASTLE + SEA

- [x] Castle visual theme added.
- [x] Sea visual theme added.
- [x] No new Universal categories.
- [x] No replacement symbol legend.
- [x] Castle reuses walls/fences/gates/passages/obstructions concepts.
- [x] Sea reuses water/current/hazard/obstruction/vegetation concepts.
- [x] Existing map coordinates are unchanged by theme selection.
- [x] Theme settings remain visual-only.
- [ ] Windows visual test: Castle.
- [ ] Windows visual test: Sea.
- [ ] Confirm no regeneration is required to switch themes.

NEXT: renderer optimization before more feature growth.
