# Phase 2B — Guide Line Editor

This build intentionally adds ONE tool only.

## What it does
A Guide Line gives already-mapped terrain a preferred visible direction.

The line is clipped to cells that already belong to the selected terrain layer.
It does not paint new terrain.

## How to use it
1. Choose a supported terrain layer under Edit Layer.
2. Set Tool = Guide Line.
3. Set Guide width from 1 to 7.
4. Click a start cell.
5. Click an end cell.

Supported layers:
Rough Terrain, Unstable Ground, Half Obstructions, Full Obstructions,
Hazards, Vegetation, Elevation, Liquid Areas.

## Safety rule
Guide Lines are visual-only metadata.

They do not change:
seed, ASCII, base-layer coordinates, overrides, or custom cells.

## Controls
Undo Last Guide
Clear Guides
Right-click cancels an unfinished guide.

Terrain Pen is not included yet.
Over/Under relationships are not included yet.
