# Castle / Fortification and Sea / Naval Themes

These are visual environment interpretations only.
They DO NOT create new Universal categories or a second symbol legend.

## Castle / Fortification

Existing Universals are re-skinned as built fortification features.

Examples:
- Full Obstructions -> castle wall / tower mass
- Half Obstructions -> fence / low wall / barricade
- Restricted Passages -> gates / choke points
- Routes / Passages -> courtyard roads / wall walks
- Vertical Connections -> stairs / ladders / tower access
- Liquid Areas -> moat / cistern
- Elevation -> battlements / raised walks

Existing structure symbols remain the structure language:
# | - walls/barriers
F fence
G gate
+ closed door
* locked door
/ open door
n archway
P pillar
B barricade
W walkway/bridge
S shelter

### Scale note for later structure generation
Design target supplied during Phase 2:
- one castle-wall section: 100 ft = 20 five-foot cells
- one fence run: 50 ft = 10 five-foot cells
- planned guard-tower space: 10 ft at each end

These dimensions are NOTES ONLY in this build.
No automatic castle-layout generator has been added yet.

## Sea / Naval

Open Ground is visually interpreted as open water.

Examples:
- Rough Terrain -> choppy water / heavy swell
- Unstable Ground -> strong current / rough water
- Hazards -> whirlpool / violent current / storm patch
- Half Obstructions -> reef / floating debris / shoal
- Full Obstructions -> exposed rock / reef mass / small island
- Vegetation -> kelp / dense sea growth
- Elevation -> wave crest / swell
- Liquid Areas -> deep / very deep water
- Routes / Passages -> sea lane / navigable channel
- Restricted Passages -> reef channel / shoal passage
- Vertical Connections -> depth transition / drop-off

The existing sea symbol language remains authoritative.
No new symbols were introduced.

## Next development priority

Performance optimization is moved forward immediately after this theme test.
Do not stack additional rendering features before the optimization pass.
