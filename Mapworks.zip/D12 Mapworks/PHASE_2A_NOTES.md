# Phase 2A — Natural Terrain Shape Renderer

## Goal
Make connected terrain cells read as one physical formation without changing map authority.

## Shape styles
- Strict — normal cell-by-cell drawing.
- Connected — adjacent cells share one visual formation; internal borders disappear.
- Natural — exposed edges receive deterministic seeded irregularity while staying inside authoritative cells.

## Edge strength
- Low
- Medium
- High

## Natural-shape layers
- Rough Terrain
- Unstable Ground
- Half Obstructions
- Full Obstructions
- Hazards
- Vegetation
- Elevation
- Liquid Areas

Routes, Restricted Passages, Vertical Connections and special network/object symbols are intentionally left alone in 2A.

## Hard rule
ASCII/JSON own the map.
The shape renderer may change only appearance.

Natural boundaries are generated from:
seed + layer + x + y + edge side + edge strength

The same map/settings must therefore render the same boundary every time.
