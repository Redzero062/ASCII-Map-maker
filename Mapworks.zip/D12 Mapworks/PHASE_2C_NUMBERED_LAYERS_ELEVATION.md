# Phase 2C — Numbered Render Layers + Elevation Height

## 2C-1 Numbered Render Layers

Every Universal layer now has a saved integer render layer.

Higher number = drawn later / visually on top.

This is VISUAL ONLY. It does not change:
- coordinates
- ASCII ownership
- mechanics
- generation
- seed determinism

Custom markers also receive render layer numbers.

The user can select any layer, enter a number from 0 to 999, and press
Apply Render Layer.

## 2C-2 Elevation Height Metadata

Elevation is still the existing Elevation Universal. No new symbol was created.

Each occupied Elevation cell can now carry a height in feet.

Terrain Pen behavior:
- select Elevation
- choose Elevation height (ft)
- left-drag
- those elevation cells receive that exact height

Cell Edit behavior:
- adding an Elevation cell assigns the current height
- removing it removes its stored height

Heights snap to 5-ft increments.

If an Elevation cell has no explicit height metadata, it defaults to 5 ft.

When Show symbols on tiles is enabled, elevation cells also display their height
as a small audit label such as 15'.

Elevation height is authoritative metadata and is included in save/load and the
authority fingerprint.

Render-layer numbers are visual metadata and are intentionally excluded from the
authority fingerprint.

## Future visibility work

Player View / Full (GM) View is intentionally NOT part of this build.
That later feature can hide secrets, hidden dangers, traps, unrevealed information,
and other GM-only content without changing the authoritative map.
