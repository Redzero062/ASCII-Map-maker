# Phase 2C-6 — Lens Editing Tools

## Added

### Copy Cell
A complete authoritative cell can now be copied to another cell.

On the main map:
1. Select `Copy Cell`.
2. Left-click the source cell.
3. Left-click the destination cell.

Inside the 5×5 Tile Lens:
- `Copy Selected Cell`
- `Paste Into Selected Cell`
- or use the `Copy Cell` tool with source-click then destination-click.

Copying includes normal physical layers, custom marker presence, fixed inspector slots, and elevation height. It does **not** copy map-wide renderer/theme settings.

### Lens Tool Controls
The pinned 5×5 lens now has its own controls:
- Tool
- Symbol / Layer
- Guide width
- Pen width

The Symbol / Layer dropdown displays the actual symbol beside its layer name.

### Terrain Pen in the Lens
- Left-click an enlarged tile to paint the selected layer.
- Right-click an enlarged tile to erase the selected layer.
- Pen width is shared with the main editor.

### Guide Line in the Lens
Choose Guide Line and click start/end directly on enlarged lens cells.

The lens and main-map controls share the same tool/layer state so they cannot drift apart.
