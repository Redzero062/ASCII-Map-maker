# Phase 2C-7 — Cell Schema Test

The pinned 5×5 Tile Lens now uses the current working cell structure.

Mechanical slots:
- Terrain
- Liquid
- Structure
- Cover
- Trap
- Lighting
- Vertical
- Clearance
- Scenario 1–4

Tile properties:
- Height
- Direction (compass buttons)
- Trap Radius

Map-wide Mood(s) is now a visual-only text field. Multiple moods can be entered with commas, including completely custom words, e.g.:
Frozen, Abandoned, Overgrown

Mood is stored in the map save but is excluded from the authoritative mechanical fingerprint.

This build also migrates the earlier prototype cell names when old test maps are opened.
