from __future__ import annotations

import hashlib
import json
import math
import os
import random
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, colorchooser
import time

APP_NAME = "D12 Mapworks"
APP_VERSION = "0.8.6-phase2c7-cell-schema-test"

DENSITIES = ["None", "Sparse", "Some", "Many", "Dense"]
DENSITY_PCT = {"None": 0.0, "Sparse": 0.06, "Some": 0.16, "Many": 0.32, "Dense": 0.52}

DEFAULT_RENDER_LAYERS = {
    "Rough Terrain": 20,
    "Unstable Ground": 25,
    "Elevation": 30,
    "Vegetation": 40,
    "Half Obstructions": 50,
    "Full Obstructions": 60,
    "Liquid Areas": 15,
    "Routes / Passages": 70,
    "Restricted Passages": 75,
    "Vertical Connections": 80,
    "Hazards": 85,
}
CUSTOM_RENDER_LAYER_DEFAULT = 90
DEFAULT_ELEVATION_HEIGHT_FT = 5

# Order is also visual precedence: later items draw over earlier items.
LAYER_DEFS = [
    ("Rough Terrain", "01_Rough_Terrain", "r", "#9a8f78"),
    ("Unstable Ground", "02_Unstable_Ground", "u", "#c39a6b"),
    ("Half Obstructions", "03_Half_Obstructions", "▤", "#7f8c8d"),
    ("Full Obstructions", "04_Full_Obstructions", "▣", "#4d5656"),
    ("Hazards", "05_Hazards", "⊗", "#c75b39"),
    ("Vegetation", "06_Vegetation", "v", "#5e8c61"),
    ("Elevation", "07_Elevation", "^", "#a88d60"),
    ("Liquid Areas", "08_Liquid_Areas", "~", "#4f81bd"),
    ("Routes / Passages", "09_Routes_Passages", "=", "#c2aa74"),
    ("Restricted Passages", "10_Restricted_Passages", "x", "#8e5a5a"),
    ("Vertical Connections", "11_Vertical_Connections", "↑", "#8867a8"),
]


# ---------------------------------------------------------------------------
# PHASE 1 VISUAL RENDERER
# ---------------------------------------------------------------------------
# The renderer may infer ART continuity, but never map state.
# Connectivity overlays are display/export-only and MUST NOT write into
# base_layers, overrides, custom_cells, final ASCII, or any mechanical data.

THEMES = {
    "Generic": {
        "Open Ground": "#d6cfb7",
        "Rough Terrain": "#9a8f78",
        "Unstable Ground": "#c39a6b",
        "Half Obstructions": "#7f8c8d",
        "Full Obstructions": "#4d5656",
        "Hazards": "#c75b39",
        "Vegetation": "#5e8c61",
        "Elevation": "#a88d60",
        "Liquid Areas": "#4f81bd",
        "Routes / Passages": "#c2aa74",
        "Restricted Passages": "#8e5a5a",
        "Vertical Connections": "#8867a8",
        "Darkness": "#262a2e",
    },
    "Tundra": {
        "Open Ground": "#edf5f8",
        "Rough Terrain": "#c7d3da",
        "Unstable Ground": "#a9d8e8",
        "Half Obstructions": "#8f9da6",
        "Full Obstructions": "#56636c",
        "Hazards": "#df8a38",
        "Vegetation": "#718c83",
        "Elevation": "#d7e5ec",
        "Liquid Areas": "#66b5da",
        "Routes / Passages": "#b6d0d7",
        "Restricted Passages": "#8d9ca7",
        "Vertical Connections": "#8095aa",
        "Darkness": "#26343d",
    },
    "Desert": {
        "Open Ground": "#e5ca92",
        "Rough Terrain": "#b99b67",
        "Unstable Ground": "#d9b46f",
        "Half Obstructions": "#9b8060",
        "Full Obstructions": "#66513e",
        "Hazards": "#bd5b33",
        "Vegetation": "#77814f",
        "Elevation": "#c59659",
        "Liquid Areas": "#4f98ae",
        "Routes / Passages": "#d4b982",
        "Restricted Passages": "#9c6c55",
        "Vertical Connections": "#806a63",
        "Darkness": "#372f2a",
    },
    "Forest": {
        "Open Ground": "#a8b889",
        "Rough Terrain": "#786f50",
        "Unstable Ground": "#8e7956",
        "Half Obstructions": "#6f755a",
        "Full Obstructions": "#3f493b",
        "Hazards": "#a85239",
        "Vegetation": "#4d754d",
        "Elevation": "#8d865f",
        "Liquid Areas": "#4e8593",
        "Routes / Passages": "#a28f66",
        "Restricted Passages": "#755e4d",
        "Vertical Connections": "#655e74",
        "Darkness": "#263128",
    },
    "Tropical": {
        "Open Ground": "#b9c983",
        "Rough Terrain": "#8f7b54",
        "Unstable Ground": "#9d855e",
        "Half Obstructions": "#6e795b",
        "Full Obstructions": "#42503e",
        "Hazards": "#ba613f",
        "Vegetation": "#39845b",
        "Elevation": "#8f9360",
        "Liquid Areas": "#42a4b5",
        "Routes / Passages": "#b29b69",
        "Restricted Passages": "#77614f",
        "Vertical Connections": "#6e6680",
        "Darkness": "#21372b",
    },
    "Volcanic": {
        "Open Ground": "#746e68",
        "Rough Terrain": "#57504a",
        "Unstable Ground": "#66574b",
        "Half Obstructions": "#575555",
        "Full Obstructions": "#302f31",
        "Hazards": "#e45b2f",
        "Vegetation": "#5f6951",
        "Elevation": "#67605b",
        "Liquid Areas": "#8f4936",
        "Routes / Passages": "#8a7b6b",
        "Restricted Passages": "#6d4945",
        "Vertical Connections": "#65536f",
        "Darkness": "#1e1d20",
    },
    "Castle": {
        "Open Ground": "#b9b2a5",
        "Rough Terrain": "#8f887d",
        "Unstable Ground": "#9b8270",
        "Half Obstructions": "#77756f",
        "Full Obstructions": "#4e514f",
        "Hazards": "#a65543",
        "Vegetation": "#66785e",
        "Elevation": "#8f8a80",
        "Liquid Areas": "#557f93",
        "Routes / Passages": "#a99b82",
        "Restricted Passages": "#655f5a",
        "Vertical Connections": "#756b78",
        "Darkness": "#292b2c",
    },
    "Sea": {
        "Open Ground": "#4d8fa8",
        "Rough Terrain": "#3f7f99",
        "Unstable Ground": "#34748f",
        "Half Obstructions": "#688184",
        "Full Obstructions": "#4d5f60",
        "Hazards": "#315f7c",
        "Vegetation": "#3f7b68",
        "Elevation": "#5a9eb4",
        "Liquid Areas": "#2d6f91",
        "Routes / Passages": "#6aa6bb",
        "Restricted Passages": "#376b73",
        "Vertical Connections": "#5b7f93",
        "Darkness": "#1d3039",
    },
}


# Theme skin language. These labels and patterns are VISUAL substitutions only.
# They never change the Universal/mechanical category underneath.
THEME_SKINS = {
    "Generic": {
        "Open Ground": ("Open Ground", "speckle"),
        "Rough Terrain": ("Broken Ground", "cracks"),
        "Unstable Ground": ("Unstable Surface", "fracture"),
        "Half Obstructions": ("Low Obstruction", "stone"),
        "Full Obstructions": ("Full Obstruction", "boulder"),
        "Hazards": ("Hazard", "hazard_ring"),
        "Vegetation": ("Vegetation", "tufts"),
        "Elevation": ("Rise / Slope", "contour"),
        "Liquid Areas": ("Liquid", "waves"),
        "Routes / Passages": ("Route / Passage", "track"),
        "Restricted Passages": ("Restricted Passage", "crosshatch"),
        "Vertical Connections": ("Vertical Connection", "steps"),
        "Darkness": ("Darkness", "dark_hatch"),
    },
    "Tundra": {
        "Open Ground": ("Frozen Ground / Snow", "snow_drift"),
        "Rough Terrain": ("Broken Frozen Ground / Deep Snow", "ice_rubble"),
        "Unstable Ground": ("Thin Ice / Ice Cracks", "ice_cracks"),
        "Half Obstructions": ("Ice Rubble / Frozen Boulder", "ice_stone"),
        "Full Obstructions": ("Ice Outcrop / Frozen Boulder", "ice_block"),
        "Hazards": ("Freezing Water / Ice Hazard", "cold_hazard"),
        "Vegetation": ("Sparse Frozen Vegetation", "frost_tufts"),
        "Elevation": ("Snow / Ice Slope", "snow_ridge"),
        "Liquid Areas": ("Meltwater / Cold Water", "cold_waves"),
        "Routes / Passages": ("Packed Snow Track", "snow_track"),
        "Restricted Passages": ("Ice Crack / Narrow Fissure", "ice_fissure"),
        "Vertical Connections": ("Drop / Ice Shelf", "ice_steps"),
        "Darkness": ("Polar Darkness / Shadow", "dark_hatch"),
    },
    "Desert": {
        "Open Ground": ("Dry Ground / Sand", "sand"),
        "Rough Terrain": ("Broken Badland Ground", "badland"),
        "Unstable Ground": ("Loose Sand / Cracked Earth", "loose_sand"),
        "Half Obstructions": ("Low Rock / Scrub", "desert_stone"),
        "Full Obstructions": ("Boulder / Stone Outcrop", "boulder"),
        "Hazards": ("Heat / Sink / Harsh Ground", "heat_hazard"),
        "Vegetation": ("Scrub / Thorn Growth", "scrub"),
        "Elevation": ("Dune / Slope", "dune"),
        "Liquid Areas": ("Water / Mudflat", "waves"),
        "Routes / Passages": ("Worn Sand Track", "track"),
        "Restricted Passages": ("Canyon / Narrow Crack", "fissure"),
        "Vertical Connections": ("Dune Rise / Drop", "steps"),
        "Darkness": ("Shadow", "dark_hatch"),
    },
    "Forest": {
        "Open Ground": ("Forest Floor", "leaf_litter"),
        "Rough Terrain": ("Roots / Broken Forest Floor", "roots"),
        "Unstable Ground": ("Loose Soil / Root Tangle", "fracture"),
        "Half Obstructions": ("Log / Brush / Low Rock", "log"),
        "Full Obstructions": ("Tree Trunk / Boulder", "tree_block"),
        "Hazards": ("Burning / Toxic / Natural Hazard", "hazard_ring"),
        "Vegetation": ("Brush / Dense Growth", "forest_tufts"),
        "Elevation": ("Wooded Rise / Slope", "contour"),
        "Liquid Areas": ("Forest Pool / Wet Ground", "waves"),
        "Routes / Passages": ("Forest Path", "track"),
        "Restricted Passages": ("Dense Growth / Narrow Gap", "crosshatch"),
        "Vertical Connections": ("Rise / Drop", "steps"),
        "Darkness": ("Deep Shade", "dark_hatch"),
    },
    "Tropical": {
        "Open Ground": ("Humid Ground / Grass", "tropical_ground"),
        "Rough Terrain": ("Roots / Mud / Ferns", "roots"),
        "Unstable Ground": ("Soft Mud / Loose Ground", "mud"),
        "Half Obstructions": ("Root / Fallen Log / Low Rock", "log"),
        "Full Obstructions": ("Large Trunk / Jungle Outcrop", "tree_block"),
        "Hazards": ("Toxic Growth / Steam / Bog Hazard", "tropical_hazard"),
        "Vegetation": ("Dense Tropical Growth", "jungle_tufts"),
        "Elevation": ("Jungle Rise / Terrace", "contour"),
        "Liquid Areas": ("Warm Shallow Water", "tropical_waves"),
        "Routes / Passages": ("Worn Jungle Path", "jungle_track"),
        "Restricted Passages": ("Tangled Growth / Ravine", "vine_crosshatch"),
        "Vertical Connections": ("Ridge / Drop / Root Step", "steps"),
        "Darkness": ("Canopy Shadow", "dark_hatch"),
    },
    "Volcanic": {
        "Open Ground": ("Stable Volcanic Stone", "basalt"),
        "Rough Terrain": ("Broken Volcanic Rock / Rough Lava", "lava_rubble"),
        "Unstable Ground": ("Cracked Crust / Fissured Ground", "lava_cracks"),
        "Half Obstructions": ("Basalt Rubble", "volcanic_stone"),
        "Full Obstructions": ("Basalt Outcrop", "basalt_block"),
        "Hazards": ("Lava / Steam / Burning Vent", "lava_hazard"),
        "Vegetation": ("Sparse Hardy Growth", "scrub"),
        "Elevation": ("Volcanic Slope", "lava_ridge"),
        "Liquid Areas": ("Hot Pool / Lava-like Flow", "hot_waves"),
        "Routes / Passages": ("Ash / Stone Track", "track"),
        "Restricted Passages": ("Fissure / Crater Edge", "lava_fissure"),
        "Vertical Connections": ("Crater Rise / Drop", "steps"),
        "Darkness": ("Ash Shadow", "dark_hatch"),
    },
    "Castle": {
        "Open Ground": ("Courtyard / Flagstone", "basalt"),
        "Rough Terrain": ("Rubble / Broken Masonry", "cracks"),
        "Unstable Ground": ("Damaged Floor / Loose Stone", "fracture"),
        "Half Obstructions": ("Fence / Low Wall / Barricade", "stone"),
        "Full Obstructions": ("Castle Wall / Tower Mass", "basalt_block"),
        "Hazards": ("Defensive Hazard / Kill Zone", "hazard_ring"),
        "Vegetation": ("Courtyard Growth / Hedge", "tufts"),
        "Elevation": ("Battlement / Raised Walk", "steps"),
        "Liquid Areas": ("Moat / Cistern / Water", "waves"),
        "Routes / Passages": ("Courtyard Road / Wall Walk", "track"),
        "Restricted Passages": ("Gate / Choke Point / Narrow Access", "crosshatch"),
        "Vertical Connections": ("Stairs / Ladder / Tower Access", "steps"),
        "Darkness": ("Interior Shadow / Dungeon Dark", "dark_hatch"),
    },
    "Sea": {
        "Open Ground": ("Open Water", "waves"),
        "Rough Terrain": ("Choppy Water / Heavy Swell", "waves"),
        "Unstable Ground": ("Strong Current / Rough Water", "cold_waves"),
        "Half Obstructions": ("Reef / Floating Debris / Shoal", "stone"),
        "Full Obstructions": ("Exposed Rock / Reef Mass / Small Island", "boulder"),
        "Hazards": ("Whirlpool / Violent Current / Storm Patch", "hazard_ring"),
        "Vegetation": ("Kelp / Dense Sea Growth", "jungle_tufts"),
        "Elevation": ("Wave Crest / Swell", "contour"),
        "Liquid Areas": ("Deep / Very Deep Water", "cold_waves"),
        "Routes / Passages": ("Sea Lane / Navigable Channel", "track"),
        "Restricted Passages": ("Reef Channel / Shoal Passage", "crosshatch"),
        "Vertical Connections": ("Drop-off / Depth Transition", "steps"),
        "Darkness": ("Deep Water / Storm Shadow", "dark_hatch"),
    },
}

# Symbols the visualizer is allowed to treat as art-connective patterns.
# Backtick is reserved here as a visual darkness marker. It does not create
# darkness mechanics by itself.
ART_CONNECTIVE_SYMBOLS = {"`", "r", "=", "x", "↑", "u", "^", "v"}

# For empty-space art inference: require at least two matching diagonal
# neighbors before showing a decorative bridge. This changes ONLY rendering.
ART_GAP_MIN_DIAGONALS = 2

CUSTOM_PREFIX = "Custom: "

# Phase 2C-7 fixed cell-schema test.
# Mechanical slots are deliberately narrow. Map Type / Mood remain visual-only.
SCENARIO_CHOICES = [
    "None",
    "Primary Objective",
    "Point of Interest",
    "Interaction Point",
    "Player Entry",
    "Enemy Entry",
    "Reinforcement Entry",
    "Map Entrance",
    "Map Exit / Extraction",
    "Control Point / Switch",
    "Healing / Recovery Source",
    "Harmful Environmental Source",
    "Magical / Anomalous Source",
    "Environmental Source / Vent",
    "Special Scenario Marker",
    "Custom...",
]

CELL_SLOT_CHOICES = {
    "terrain_effect": [
        "None",
        "Minor Movement Terrain",
        "Rough Terrain",
        "Unstable Ground",
        "Severe Terrain",
        "Damaging Terrain",
        "Physical Condition Terrain",
        "Internal Condition Terrain",
        "Magical Terrain",
        "Forced Movement / Instability",
        "Custom...",
    ],
    "liquid": [
        "None",
        "Shallow Water",
        "Flowing Water",
        "Water",
        "Deep Water",
        "Very Deep Water",
        "Rapids / Heavy Surf",
        "Whirlpool / Strong Current",
        "Custom...",
    ],
    "structure": [
        "None",
        "Wall / Solid Structure",
        "Vertical Wall / Barrier",
        "Horizontal Wall / Barrier",
        "Closed Door",
        "Locked Door",
        "Open Door",
        "Open Archway",
        "Gate",
        "Fence",
        "Bridge / Walkway",
        "Shelter",
        "Pillar",
        "Custom...",
    ],
    "cover": ["None", "Half Cover", "Full Cover"],
    "trap": ["None", "Inactive", "Active", "Used"],
    "lighting": [
        "Ambient / Default",
        "Fully Lit",
        "Partly Lit",
        "Dim",
        "Barely Visible",
        "No Usable Light",
        "Custom...",
    ],
    "vertical": [
        "None",
        "Rising Slope",
        "Descending Slope",
        "Raised Shelf / Plateau",
        "Depression",
        "Drop / Ledge",
        "Pit / Chasm",
        "Upward Passage",
        "Downward Passage",
        "Custom...",
    ],
    "clearance": [
        "None",
        "Low Ceiling",
        "Narrow Passage",
        "Crawlspace",
        "Overhang",
        "Squeeze / Tight Gap",
        "Custom...",
    ],
    "scenario_1": SCENARIO_CHOICES,
    "scenario_2": SCENARIO_CHOICES,
    "scenario_3": SCENARIO_CHOICES,
    "scenario_4": SCENARIO_CHOICES,
}

CELL_SLOT_LABELS = [
    ("terrain_effect", "Terrain"),
    ("liquid", "Liquid"),
    ("structure", "Structure"),
    ("cover", "Cover"),
    ("trap", "Trap"),
    ("lighting", "Lighting"),
    ("vertical", "Vertical"),
    ("clearance", "Clearance"),
    ("scenario_1", "Scenario 1"),
    ("scenario_2", "Scenario 2"),
    ("scenario_3", "Scenario 3"),
    ("scenario_4", "Scenario 4"),
]

CELL_SLOT_DEFAULTS = {
    "terrain_effect": "None",
    "liquid": "None",
    "structure": "None",
    "cover": "None",
    "trap": "None",
    "lighting": "Ambient / Default",
    "vertical": "None",
    "clearance": "None",
    "scenario_1": "None",
    "scenario_2": "None",
    "scenario_3": "None",
    "scenario_4": "None",
    "height_ft": 0,
    "direction": "None",
    "trap_radius_ft": 0,
}

DIRECTION_CHOICES = [
    "None", "North", "Northeast", "East", "Southeast",
    "South", "Southwest", "West", "Northwest", "Up", "Down", "Custom..."
]

MOOD_EXAMPLES = [
    "Haunted", "Frozen", "Abandoned", "Overgrown", "Well Preserved",
    "Ruined", "Ancient", "Corrupted", "Flooded", "Burned"
]

def resource_path(relative: str) -> Path:
    """Works in normal Python and PyInstaller one-file/one-folder builds."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / relative


def stable_int(*parts: object) -> int:
    h = hashlib.sha256("|".join(map(str, parts)).encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big", signed=False)


def col_label(index: int) -> str:
    n = index + 1
    s = ""
    while n:
        n, rem = divmod(n - 1, 26)
        s = chr(65 + rem) + s
    return s


@dataclass
class CustomLayer:
    name: str
    symbol: str
    color: str


@dataclass
class MapState:
    name: str = "Untitled Map"
    seed: str = "D12-001"
    width: int = 30
    height: int = 30
    terrain: str = "Generic"
    visual_theme: str = "Generic"
    mood_tags: list[str] = field(default_factory=list)
    smart_connectivity: bool = True
    textured_tiles: bool = True
    export_show_grid: bool = True
    export_show_symbols: bool = True
    export_show_legend: bool = True
    export_scale: int = 2
    shape_style: str = "Connected"
    edge_strength: str = "Medium"
    visual_guides: list[dict] = field(default_factory=list)
    render_layers: dict[str, int] = field(default_factory=lambda: dict(DEFAULT_RENDER_LAYERS))
    custom_render_layers: dict[str, int] = field(default_factory=dict)
    elevation_heights: dict[str, int] = field(default_factory=dict)
    notes: str = ""
    densities: dict[str, str] = field(default_factory=lambda: {name: "None" for name, *_ in LAYER_DEFS})
    base_layers: dict[str, list[list[int]]] = field(default_factory=dict)
    overrides_add: dict[str, list[list[int]]] = field(default_factory=dict)
    overrides_remove: dict[str, list[list[int]]] = field(default_factory=dict)
    custom_layers: list[CustomLayer] = field(default_factory=list)
    custom_cells: dict[str, list[list[int]]] = field(default_factory=dict)
    # Per-cell structured inspector values. Keys are coordinate labels such as "C3".
    # This is authoritative metadata for fields that do not yet have a legacy layer.
    cell_slots: dict[str, dict] = field(default_factory=dict)

    def to_json_dict(self) -> dict:
        d = asdict(self)
        d["custom_layers"] = [asdict(x) for x in self.custom_layers]
        return d

    @classmethod
    def from_json_dict(cls, d: dict) -> "MapState":
        d = dict(d)
        d.setdefault("visual_theme", "Generic")
        d.setdefault("mood_tags", [])
        d["mood_tags"] = [str(x) for x in d.get("mood_tags", []) if str(x).strip()]
        d.setdefault("smart_connectivity", True)
        d.setdefault("textured_tiles", True)
        d.setdefault("export_show_grid", True)
        d.setdefault("export_show_symbols", True)
        d.setdefault("export_show_legend", True)
        d.setdefault("export_scale", 2)
        d.setdefault("shape_style", "Connected")
        d.setdefault("edge_strength", "Medium")
        d.setdefault("visual_guides", [])
        d.setdefault("render_layers", dict(DEFAULT_RENDER_LAYERS))
        # Fill any defaults added by newer versions without overwriting saved choices.
        merged_render_layers = dict(DEFAULT_RENDER_LAYERS)
        merged_render_layers.update({k: int(v) for k, v in d.get("render_layers", {}).items()})
        d["render_layers"] = merged_render_layers
        d.setdefault("custom_render_layers", {})
        d["custom_render_layers"] = {k: int(v) for k, v in d.get("custom_render_layers", {}).items()}
        d.setdefault("elevation_heights", {})
        d.setdefault("cell_slots", {})
        d["elevation_heights"] = {str(k): int(v) for k, v in d.get("elevation_heights", {}).items()}
        d["cell_slots"] = {str(k): dict(v) for k, v in d.get("cell_slots", {}).items() if isinstance(v, dict)}
        d["custom_layers"] = [CustomLayer(**x) for x in d.get("custom_layers", [])]
        allowed = {f.name for f in __import__("dataclasses").fields(cls)}
        d = {k: v for k, v in d.items() if k in allowed}
        return cls(**d)


class PatternLibrary:
    def __init__(self) -> None:
        self.root = resource_path("D12_Universal_Map_Library")
        self.cache: dict[tuple[str, str], list[str]] = {}

    def load(self, folder: str, density: str) -> list[str]:
        key = (folder, density)
        if key in self.cache:
            return self.cache[key]
        path = self.root / "01_PHYSICAL_UNIVERSALS" / folder / f"{density}.txt"
        rows: list[str] = []
        if path.exists():
            lines = path.read_text(encoding="utf-8").splitlines()
            # Pattern rows are the last 30 lines that look map-like.
            candidate = [ln.rstrip("\n") for ln in lines if len(ln) >= 20 and not ":" in ln[:18]]
            if len(candidate) >= 30:
                rows = candidate[-30:]
        if not rows:
            rows = ["." * 30 for _ in range(30)]
        rows = [r[:30].ljust(30, ".") for r in rows[:30]]
        self.cache[key] = rows
        return rows


class MapEngine:
    def __init__(self) -> None:
        self.library = PatternLibrary()

    def generate(self, state: MapState) -> None:
        state.base_layers = {}
        state.cell_slots = {}
        state.overrides_add = {}
        state.overrides_remove = {}
        for name, folder, symbol, color in LAYER_DEFS:
            density = state.densities.get(name, "None")
            cells = self.generate_layer(state.seed, state.width, state.height, name, folder, density)
            state.base_layers[name] = [[x, y] for x, y in sorted(cells)]
            state.overrides_add[name] = []
            state.overrides_remove[name] = []

    def generate_layer(self, seed: str, width: int, height: int, name: str, folder: str, density: str) -> set[tuple[int, int]]:
        if density == "None":
            return set()
        rows = self.library.load(folder, density)
        points = {(x, y) for y, row in enumerate(rows) for x, ch in enumerate(row) if ch != "."}
        rng = random.Random(stable_int(seed, name, density, width, height))

        # Deterministic pattern transforms. We preserve source shape language but change placement/orientation.
        rotate = rng.randrange(4)
        flip_x = bool(rng.getrandbits(1))
        flip_y = bool(rng.getrandbits(1))
        off_x = rng.randrange(30)
        off_y = rng.randrange(30)

        transformed = set()
        for x, y in points:
            for _ in range(rotate):
                x, y = 29 - y, x
            if flip_x:
                x = 29 - x
            if flip_y:
                y = 29 - y
            x = (x + off_x) % 30
            y = (y + off_y) % 30
            transformed.add((x, y))

        # Scale 30x30 pattern to requested size using normalized nearest-neighbor sampling.
        out: set[tuple[int, int]] = set()
        for y in range(height):
            sy = min(29, int((y + 0.5) * 30 / height))
            for x in range(width):
                sx = min(29, int((x + 0.5) * 30 / width))
                if (sx, sy) in transformed:
                    out.add((x, y))

        # Correct quantity toward density target so odd sizes remain faithful.
        target = int(round(width * height * DENSITY_PCT[density]))
        target = max(0, min(width * height, target))
        if len(out) > target:
            remove = list(out)
            rng.shuffle(remove)
            out.difference_update(remove[: len(out) - target])
        elif len(out) < target:
            candidates = [(x, y) for y in range(height) for x in range(width) if (x, y) not in out]
            # Prefer cells adjacent to existing shape; then fill deterministic remainder.
            def neighbor_score(c):
                x, y = c
                return sum((x+dx, y+dy) in out for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)))
            candidates.sort(key=lambda c: (-neighbor_score(c), stable_int(seed, name, density, c[0], c[1])))
            out.update(candidates[: target - len(out)])
        return out

    @staticmethod
    def cells_for_layer(state: MapState, layer_name: str) -> set[tuple[int, int]]:
        base = {tuple(v) for v in state.base_layers.get(layer_name, [])}
        adds = {tuple(v) for v in state.overrides_add.get(layer_name, [])}
        removes = {tuple(v) for v in state.overrides_remove.get(layer_name, [])}
        return (base | adds) - removes

    @staticmethod
    def toggle_layer_cell(state: MapState, layer_name: str, x: int, y: int) -> None:
        base = {tuple(v) for v in state.base_layers.get(layer_name, [])}
        adds = {tuple(v) for v in state.overrides_add.get(layer_name, [])}
        removes = {tuple(v) for v in state.overrides_remove.get(layer_name, [])}
        p = (x, y)
        if p in (base | adds) - removes:
            if p in adds:
                adds.remove(p)
            else:
                removes.add(p)
        else:
            if p in removes:
                removes.remove(p)
            elif p not in base:
                adds.add(p)
        state.overrides_add[layer_name] = [[a, b] for a, b in sorted(adds)]
        state.overrides_remove[layer_name] = [[a, b] for a, b in sorted(removes)]

    @staticmethod
    def paint_layer_cell(state: MapState, layer_name: str, x: int, y: int) -> None:
        """Authoritatively ensure one terrain layer exists at this cell."""
        if layer_name not in state.base_layers:
            return

        base = {tuple(v) for v in state.base_layers.get(layer_name, [])}
        adds = {tuple(v) for v in state.overrides_add.get(layer_name, [])}
        removes = {tuple(v) for v in state.overrides_remove.get(layer_name, [])}
        p = (x, y)

        # If generation originally placed the terrain here, painting simply cancels
        # a prior manual removal. Otherwise it becomes a manual addition.
        removes.discard(p)
        if p not in base:
            adds.add(p)

        state.overrides_add[layer_name] = [[a, b] for a, b in sorted(adds)]
        state.overrides_remove[layer_name] = [[a, b] for a, b in sorted(removes)]

    @staticmethod
    def erase_layer_cell(state: MapState, layer_name: str, x: int, y: int) -> None:
        """Authoritatively ensure one selected terrain layer is absent at this cell."""
        if layer_name not in state.base_layers:
            return

        base = {tuple(v) for v in state.base_layers.get(layer_name, [])}
        adds = {tuple(v) for v in state.overrides_add.get(layer_name, [])}
        removes = {tuple(v) for v in state.overrides_remove.get(layer_name, [])}
        p = (x, y)

        # Remove manual paint first. If this came from the generated base,
        # record a manual removal so regeneration authority remains separate.
        adds.discard(p)
        if p in base:
            removes.add(p)
        else:
            removes.discard(p)

        state.overrides_add[layer_name] = [[a, b] for a, b in sorted(adds)]
        state.overrides_remove[layer_name] = [[a, b] for a, b in sorted(removes)]

    @staticmethod
    def erase_all_at(state: MapState, x: int, y: int) -> None:
        state.cell_slots.pop(f"{col_label(x)}{y+1}", None)
        for name, *_ in LAYER_DEFS:
            current = MapEngine.cells_for_layer(state, name)
            if (x, y) in current:
                base = {tuple(v) for v in state.base_layers.get(name, [])}
                adds = {tuple(v) for v in state.overrides_add.get(name, [])}
                removes = {tuple(v) for v in state.overrides_remove.get(name, [])}
                if (x, y) in adds:
                    adds.remove((x, y))
                if (x, y) in base:
                    removes.add((x, y))
                state.overrides_add[name] = [[a,b] for a,b in sorted(adds)]
                state.overrides_remove[name] = [[a,b] for a,b in sorted(removes)]
        for layer in state.custom_layers:
            pts = {tuple(v) for v in state.custom_cells.get(layer.name, [])}
            pts.discard((x, y))
            state.custom_cells[layer.name] = [[a,b] for a,b in sorted(pts)]

    def ascii_grid(self, state: MapState) -> list[str]:
        grid = [["." for _ in range(state.width)] for _ in range(state.height)]
        for name, folder, symbol, color in LAYER_DEFS:
            for x, y in self.cells_for_layer(state, name):
                if 0 <= x < state.width and 0 <= y < state.height:
                    grid[y][x] = symbol
        for custom in state.custom_layers:
            for x, y in {tuple(v) for v in state.custom_cells.get(custom.name, [])}:
                if 0 <= x < state.width and 0 <= y < state.height:
                    grid[y][x] = custom.symbol[:1] or "§"
        return ["".join(row) for row in grid]

    def export_text(self, state: MapState) -> str:
        rows = self.ascii_grid(state)
        lines = [
            f"D12 MAPWORKS {APP_VERSION}",
            f"Name: {state.name}",
            f"Seed: {state.seed}",
            f"Size: {state.width}x{state.height}",
            f"Terrain: {state.terrain}",
            f"Visual Theme: {state.visual_theme}",
            f"Smart Art Connectivity: {'On' if state.smart_connectivity else 'Off'}",
            f"Theme Texture Details: {'On' if state.textured_tiles else 'Off'}",
            "",
            "DENSITIES",
        ]
        for name, *_ in LAYER_DEFS:
            lines.append(f"- {name}: {state.densities.get(name, 'None')}")
        lines += ["", "RENDER LAYERS (visual stack; higher draws on top)"]
        for name, *_ in LAYER_DEFS:
            lines.append(f"- {name}: {state.render_layers.get(name, DEFAULT_RENDER_LAYERS.get(name, 0))}")
        for custom in state.custom_layers:
            lines.append(f"- {custom.name}: {state.custom_render_layers.get(custom.name, CUSTOM_RENDER_LAYER_DEFAULT)}")
        if state.elevation_heights:
            lines += ["", "ELEVATION HEIGHT METADATA"]
            for key, feet in sorted(state.elevation_heights.items()):
                lines.append(f"- {key}: {feet} ft")
        if state.cell_slots:
            lines += ["", "CELL INSPECTOR DATA"]
            for key, rec in sorted(state.cell_slots.items()):
                if rec:
                    parts = [f"{k}={v}" for k, v in rec.items() if v not in (None, "", "None", "Default", 0)]
                    if parts:
                        lines.append(f"- {key}: " + "; ".join(parts))
        lines += ["", "LEGEND"]
        for name, folder, symbol, color in LAYER_DEFS:
            lines.append(f"{symbol} = {name}")
        for custom in state.custom_layers:
            lines.append(f"{custom.symbol} = {custom.name}")
        lines += ["", "MAP", *rows, "", "CREATOR NOTES", state.notes or "(none)"]
        return "\n".join(lines)


def _hex_to_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return tuple(int(value[i:i+2], 16) for i in (0, 2, 4))


def _rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#" + "".join(f"{max(0,min(255,int(v))):02x}" for v in rgb)


def blend_hex(a: str, b: str, amount: float) -> str:
    ar = _hex_to_rgb(a)
    br = _hex_to_rgb(b)
    return _rgb_to_hex(tuple(ar[i] * (1-amount) + br[i] * amount for i in range(3)))


class VisualRenderer:
    """Display-only renderer. It is forbidden from modifying MapState."""

    CARDINALS = ((0,-1), (1,0), (0,1), (-1,0))
    DIAGONALS = ((-1,-1), (1,-1), (1,1), (-1,1))

    def theme_color(self, state: MapState, name: str, fallback: str) -> str:
        theme = THEMES.get(state.visual_theme, THEMES["Generic"])
        return theme.get(name, fallback)

    def symbol_grid(self, engine: MapEngine, state: MapState) -> list[str]:
        return engine.ascii_grid(state)

    @staticmethod
    def in_bounds(rows: list[str], x: int, y: int) -> bool:
        return 0 <= y < len(rows) and 0 <= x < len(rows[y])

    def same_symbol_neighbors(self, rows: list[str], x: int, y: int, symbol: str):
        card = []
        diag = []
        for dx,dy in self.CARDINALS:
            nx,ny=x+dx,y+dy
            if self.in_bounds(rows,nx,ny) and rows[ny][nx] == symbol:
                card.append((dx,dy))
        for dx,dy in self.DIAGONALS:
            nx,ny=x+dx,y+dy
            if self.in_bounds(rows,nx,ny) and rows[ny][nx] == symbol:
                diag.append((dx,dy))
        return card, diag

    def inferred_gap_symbol(self, rows: list[str], x: int, y: int) -> str | None:
        """Decorative inference only: never edits the underlying open cell."""
        if not self.in_bounds(rows,x,y) or rows[y][x] != ".":
            return None
        counts: dict[str, int] = {}
        for dx,dy in self.DIAGONALS:
            nx,ny=x+dx,y+dy
            if self.in_bounds(rows,nx,ny):
                s=rows[ny][nx]
                if s in ART_CONNECTIVE_SYMBOLS:
                    counts[s]=counts.get(s,0)+1
        if not counts:
            return None
        symbol, count = max(counts.items(), key=lambda kv: kv[1])
        return symbol if count >= ART_GAP_MIN_DIAGONALS else None

    def connector_name_for_symbol(self, symbol: str) -> str:
        return {
            "`": "Darkness",
            "r": "Rough Terrain",
            "=": "Routes / Passages",
            "x": "Restricted Passages",
            "↑": "Vertical Connections",
            "u": "Unstable Ground",
            "^": "Elevation",
            "v": "Vegetation",
        }.get(symbol, "Open Ground")

    def skin_spec(self, state: MapState, name: str) -> tuple[str, str]:
        theme = THEME_SKINS.get(state.visual_theme, THEME_SKINS["Generic"])
        return theme.get(name, THEME_SKINS["Generic"].get(name, (name, "speckle")))

    def skin_label(self, state: MapState, name: str) -> str:
        return self.skin_spec(state, name)[0]

    def _detail_color(self, base: str, dark: bool = True, amount: float = 0.22) -> str:
        target = "#111111" if dark else "#ffffff"
        return blend_hex(base, target, amount)

    def _rng(self, state: MapState, name: str, x: int, y: int):
        return random.Random(stable_int(state.seed, state.visual_theme, name, x, y, "skin"))

    def natural_layers(self):
        return {
            "Rough Terrain",
            "Unstable Ground",
            "Half Obstructions",
            "Full Obstructions",
            "Hazards",
            "Vegetation",
            "Elevation",
            "Liquid Areas",
        }

    def _layer_cells(self, state, layer_name):
        cells = set()
        for item in state.base_layers.get(layer_name, []):
            try:
                cells.add((int(item[0]), int(item[1])))
            except Exception:
                pass
        for item in state.overrides_add.get(layer_name, []):
            try:
                cells.add((int(item[0]), int(item[1])))
            except Exception:
                pass
        for item in state.overrides_remove.get(layer_name, []):
            try:
                cells.discard((int(item[0]), int(item[1])))
            except Exception:
                pass
        return cells

    def _occupied_neighbor_mask(self, cells, x, y):
        # Cardinal-only mask for actual region ownership.
        return {
            "N": (x, y-1) in cells,
            "E": (x+1, y) in cells,
            "S": (x, y+1) in cells,
            "W": (x-1, y) in cells,
            "NE": (x+1, y-1) in cells,
            "SE": (x+1, y+1) in cells,
            "SW": (x-1, y+1) in cells,
            "NW": (x-1, y-1) in cells,
        }

    def region_components(self, state, layer_name):
        """Deterministic 8-neighbor grouping for visual interpretation only."""
        cells = self._layer_cells(state, layer_name)
        remaining = set(cells)
        comps = []
        while remaining:
            seed = min(remaining, key=lambda p: (p[1], p[0]))
            stack = [seed]
            comp = set()
            remaining.remove(seed)
            while stack:
                x, y = stack.pop()
                comp.add((x, y))
                for dy in (-1,0,1):
                    for dx in (-1,0,1):
                        if dx == 0 and dy == 0:
                            continue
                        n = (x+dx, y+dy)
                        if n in remaining:
                            remaining.remove(n)
                            stack.append(n)
            comps.append(comp)
        return comps

    def _natural_inset(self, state, layer_name, x, y, side, cell_size):
        """Seeded, display-only edge irregularity. Never changes cell ownership."""
        strength = getattr(state, "edge_strength", "Medium")
        frac = {"Low":0.06, "Medium":0.11, "High":0.17}.get(strength, 0.11)
        max_px = max(1, int(cell_size * frac))
        material = f"{state.seed}|{layer_name}|{x}|{y}|{side}|{strength}"
        digest = hashlib.sha256(material.encode("utf-8")).digest()
        return digest[0] % (max_px + 1)

    def shape_polygon_for_cell(self, state, layer_name, x, y, x0, y0, cs, cells=None):
        """
        Returns a deterministic polygon for one authoritative cell.
        Shared cardinal edges stay flush when the same region continues.
        Exposed edges inset slightly in Natural mode to soften the formation.

        Phase 4A: callers may pass a precomputed cell set so large maps do not
        rebuild the same layer membership thousands of times per frame.
        """
        if cells is None:
            cells = self._layer_cells(state, layer_name)
        n = self._occupied_neighbor_mask(cells, x, y)
        style = getattr(state, "shape_style", "Connected")

        if style == "Strict" or layer_name not in self.natural_layers():
            return [(x0,y0),(x0+cs,y0),(x0+cs,y0+cs),(x0,y0+cs)]

        # Connected mode: one clean rectangular ownership footprint, internal borders can disappear.
        if style == "Connected":
            return [(x0,y0),(x0+cs,y0),(x0+cs,y0+cs),(x0,y0+cs)]

        # Natural mode. Exposed edges get small deterministic offsets, but polygon remains inside cell.
        top_l = 0 if n["N"] else self._natural_inset(state,layer_name,x,y,"TL",cs)
        top_r = 0 if n["N"] else self._natural_inset(state,layer_name,x,y,"TR",cs)
        right_t = 0 if n["E"] else self._natural_inset(state,layer_name,x,y,"RT",cs)
        right_b = 0 if n["E"] else self._natural_inset(state,layer_name,x,y,"RB",cs)
        bot_r = 0 if n["S"] else self._natural_inset(state,layer_name,x,y,"BR",cs)
        bot_l = 0 if n["S"] else self._natural_inset(state,layer_name,x,y,"BL",cs)
        left_b = 0 if n["W"] else self._natural_inset(state,layer_name,x,y,"LB",cs)
        left_t = 0 if n["W"] else self._natural_inset(state,layer_name,x,y,"LT",cs)

        return [
            (x0 + top_l, y0),
            (x0 + cs - top_r, y0),
            (x0 + cs, y0 + right_t),
            (x0 + cs, y0 + cs - right_b),
            (x0 + cs - bot_r, y0 + cs),
            (x0 + bot_l, y0 + cs),
            (x0, y0 + cs - left_b),
            (x0, y0 + left_t),
        ]

    def draw_region_cell_canvas(self, canvas, state, layer_name, x, y, x0, y0, cs, fill_color):
        style = getattr(state, "shape_style", "Connected")
        cells = self._layer_cells(state, layer_name)
        n = self._occupied_neighbor_mask(cells, x, y)

        if style == "Strict" or layer_name not in self.natural_layers():
            canvas.create_rectangle(x0,y0,x0+cs,y0+cs,fill=fill_color,outline="#777777")
            return

        edge_width = {"Low":1,"Medium":2,"High":3}.get(getattr(state,"edge_strength","Medium"),2)
        edge = blend_hex(fill_color, "#000000", 0.22)

        if style == "Connected":
            # Clean cell ownership, but hide internal borders so the region reads as one shape.
            canvas.create_rectangle(x0,y0,x0+cs,y0+cs,fill=fill_color,outline="")
            if not n["N"]:
                canvas.create_line(x0,y0,x0+cs,y0,fill=edge,width=edge_width)
            if not n["E"]:
                canvas.create_line(x0+cs,y0,x0+cs,y0+cs,fill=edge,width=edge_width)
            if not n["S"]:
                canvas.create_line(x0+cs,y0+cs,x0,y0+cs,fill=edge,width=edge_width)
            if not n["W"]:
                canvas.create_line(x0,y0+cs,x0,y0,fill=edge,width=edge_width)
            return

        # Natural mode uses an 8-point irregular polygon.
        poly = self.shape_polygon_for_cell(state,layer_name,x,y,x0,y0,cs,cells=cells)
        canvas.create_polygon(*[v for pt in poly for v in pt], fill=fill_color, outline="")
        if not n["N"]:
            canvas.create_line(poly[0][0],poly[0][1],poly[1][0],poly[1][1],fill=edge,width=edge_width)
        if not n["E"]:
            canvas.create_line(poly[2][0],poly[2][1],poly[3][0],poly[3][1],fill=edge,width=edge_width)
        if not n["S"]:
            canvas.create_line(poly[4][0],poly[4][1],poly[5][0],poly[5][1],fill=edge,width=edge_width)
        if not n["W"]:
            canvas.create_line(poly[6][0],poly[6][1],poly[7][0],poly[7][1],fill=edge,width=edge_width)

    def draw_region_cell_pillow(self, dr, state, layer_name, x, y, x0, y0, cs, fill_color, show_grid=False, cells=None):
        style = getattr(state, "shape_style", "Connected")
        if cells is None:
            cells = self._layer_cells(state, layer_name)
        n = self._occupied_neighbor_mask(cells, x, y)

        if style == "Strict" or layer_name not in self.natural_layers():
            outline = "#777777" if show_grid else fill_color
            dr.rectangle((x0,y0,x0+cs-1,y0+cs-1),fill=fill_color,outline=outline)
            return

        edge_width = max(1, {"Low":1,"Medium":2,"High":3}.get(getattr(state,"edge_strength","Medium"),2) * max(1,cs//24))
        edge = blend_hex(fill_color, "#000000", 0.22)

        if style == "Connected":
            dr.rectangle((x0,y0,x0+cs-1,y0+cs-1),fill=fill_color)
            if not n["N"]:
                dr.line((x0,y0,x0+cs,y0), fill=edge, width=edge_width)
            if not n["E"]:
                dr.line((x0+cs,y0,x0+cs,y0+cs), fill=edge, width=edge_width)
            if not n["S"]:
                dr.line((x0+cs,y0+cs,x0,y0+cs), fill=edge, width=edge_width)
            if not n["W"]:
                dr.line((x0,y0+cs,x0,y0), fill=edge, width=edge_width)
            if show_grid:
                dr.rectangle((x0,y0,x0+cs-1,y0+cs-1),outline="#777777")
            return

        # Natural mode uses an 8-point irregular polygon.
        poly = self.shape_polygon_for_cell(state,layer_name,x,y,x0,y0,cs)
        dr.polygon(poly, fill=fill_color)
        if not n["N"]:
            dr.line((poly[0],poly[1]), fill=edge, width=edge_width)
        if not n["E"]:
            dr.line((poly[2],poly[3]), fill=edge, width=edge_width)
        if not n["S"]:
            dr.line((poly[4],poly[5]), fill=edge, width=edge_width)
        if not n["W"]:
            dr.line((poly[6],poly[7]), fill=edge, width=edge_width)

        if show_grid:
            dr.rectangle((x0,y0,x0+cs-1,y0+cs-1),outline="#777777")

    def guide_cells(self, start, end):
        """Deterministic integer line between two grid cells."""
        x0, y0 = int(start[0]), int(start[1])
        x1, y1 = int(end[0]), int(end[1])
        cells = []
        dx = abs(x1 - x0)
        sx = 1 if x0 < x1 else -1
        dy = -abs(y1 - y0)
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            cells.append((x0, y0))
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy
        return cells

    def guide_influence_cells(self, state, guide):
        """
        Visual-only corridor clipped to cells that already belong to the target layer.
        """
        layer_name = guide.get("layer", "")
        if layer_name not in self.natural_layers():
            return set()

        owned = self._layer_cells(state, layer_name)
        width = max(1, min(7, int(guide.get("width", 1))))
        radius = (width - 1) / 2.0
        line = self.guide_cells(guide.get("start", [0,0]), guide.get("end", [0,0]))

        influenced = set()
        rceil = int(math.ceil(radius))
        for lx, ly in line:
            for oy in range(-rceil, rceil + 1):
                for ox in range(-rceil, rceil + 1):
                    if math.hypot(ox, oy) <= radius + 0.35:
                        p = (lx + ox, ly + oy)
                        if p in owned:
                            influenced.add(p)
        return influenced

    def draw_guides_canvas(self, canvas, state, cs):
        """
        Draw directional marks only through existing cells in the selected terrain layer.
        """
        for guide in getattr(state, "visual_guides", []):
            layer_name = guide.get("layer", "")
            if layer_name not in self.natural_layers():
                continue

            influenced = self.guide_influence_cells(state, guide)
            if not influenced:
                continue

            layer = next((d for d in LAYER_DEFS if d[0] == layer_name), None)
            fallback = layer[3] if layer else "#777777"
            base = self.theme_color(state, layer_name, fallback)
            line_color = blend_hex(base, "#111111", 0.38)

            sx, sy = guide.get("start", [0,0])
            ex, ey = guide.get("end", [0,0])
            vx, vy = ex - sx, ey - sy
            mag = math.hypot(vx, vy) or 1.0
            ux, uy = vx / mag, vy / mag

            for x, y in influenced:
                cx, cy = x*cs + cs/2, y*cs + cs/2
                half = cs * 0.34
                canvas.create_line(
                    cx - ux*half, cy - uy*half,
                    cx + ux*half, cy + uy*half,
                    fill=line_color,
                    width=max(2, cs//7),
                    capstyle=tk.ROUND
                )

    def draw_guides_pillow(self, dr, state, cs):
        """PNG equivalent of draw_guides_canvas."""
        for guide in getattr(state, "visual_guides", []):
            layer_name = guide.get("layer", "")
            if layer_name not in self.natural_layers():
                continue

            influenced = self.guide_influence_cells(state, guide)
            if not influenced:
                continue

            layer = next((d for d in LAYER_DEFS if d[0] == layer_name), None)
            fallback = layer[3] if layer else "#777777"
            base = self.theme_color(state, layer_name, fallback)
            line_color = blend_hex(base, "#111111", 0.38)

            sx, sy = guide.get("start", [0,0])
            ex, ey = guide.get("end", [0,0])
            vx, vy = ex - sx, ey - sy
            mag = math.hypot(vx, vy) or 1.0
            ux, uy = vx / mag, vy / mag

            for x, y in influenced:
                cx, cy = x*cs + cs/2, y*cs + cs/2
                half = cs * 0.34
                dr.line(
                    (cx - ux*half, cy - uy*half,
                     cx + ux*half, cy + uy*half),
                    fill=line_color,
                    width=max(2, cs//7)
                )

    def draw_skin_canvas(self, canvas, state: MapState, name: str, x: int, y: int, x0: float, y0: float, cs: int, base: str):
        if not state.textured_tiles:
            return
        _, pattern = self.skin_spec(state, name)
        rng = self._rng(state, name, x, y)
        dark = self._detail_color(base, True, 0.23)
        light = self._detail_color(base, False, 0.28)
        cx, cy = x0 + cs/2, y0 + cs/2
        pad = max(2, cs*0.12)
        lw = max(1, cs//12)

        def line(*pts, fill=dark, width=lw, dash=None):
            canvas.create_line(*pts, fill=fill, width=width, dash=dash)
        def oval(a,b,c,d, fill="", outline=dark, width=1):
            canvas.create_oval(a,b,c,d, fill=fill, outline=outline, width=width)
        def rect(a,b,c,d, fill="", outline=dark, width=1):
            canvas.create_rectangle(a,b,c,d, fill=fill, outline=outline, width=width)

        if pattern in {"speckle","sand","leaf_litter","tropical_ground","basalt"}:
            count = 3 if cs < 22 else 5
            for _ in range(count):
                px=x0+pad+rng.random()*(cs-2*pad); py=y0+pad+rng.random()*(cs-2*pad)
                rr=max(1,cs*0.045)
                oval(px-rr,py-rr,px+rr,py+rr,fill=dark,outline="")
            if pattern in {"sand","tropical_ground"}:
                line(x0+pad,y0+cs*0.72,x0+cs-pad,y0+cs*0.62,fill=light,width=1)
            elif pattern == "leaf_litter":
                line(x0+cs*.25,y0+cs*.30,x0+cs*.38,y0+cs*.40,fill=dark,width=1)
                line(x0+cs*.62,y0+cs*.58,x0+cs*.76,y0+cs*.48,fill=dark,width=1)
            elif pattern == "basalt":
                line(x0+cs*.2,y0+cs*.2,x0+cs*.45,y0+cs*.35,x0+cs*.7,y0+cs*.22,fill=dark,width=1)

        elif pattern in {"cracks","fracture","ice_cracks","badland","lava_cracks","fissure","ice_fissure","lava_fissure"}:
            branches = 2 if "fissure" in pattern else 3
            for i in range(branches):
                sx=x0+cs*(0.15+0.2*i); sy=y0+cs*(0.2+rng.random()*0.2)
                mx=x0+cs*(0.35+rng.random()*0.3); my=y0+cs*(0.45+rng.random()*0.18)
                ex=x0+cs*(0.75-rng.random()*0.15); ey=y0+cs*(0.72+rng.random()*0.12)
                line(sx,sy,mx,my,ex,ey,fill=dark,width=max(lw,2 if "fissure" in pattern else lw))
                if pattern == "ice_cracks":
                    line(mx,my,mx+cs*.14,my-cs*.14,fill=light,width=1)

        elif pattern in {"ice_rubble","lava_rubble"}:
            for _ in range(4):
                px=x0+pad+rng.random()*(cs-2*pad); py=y0+pad+rng.random()*(cs-2*pad)
                rr=cs*(.08+rng.random()*.06)
                rect(px-rr,py-rr,px+rr,py+rr,fill=light if pattern=="ice_rubble" else dark,outline=dark,width=1)

        elif pattern in {"stone","ice_stone","desert_stone","volcanic_stone","boulder","ice_block","tree_block","basalt_block","log"}:
            if pattern == "log":
                line(x0+cs*.18,y0+cs*.68,x0+cs*.82,y0+cs*.32,fill=dark,width=max(3,cs//5))
                line(x0+cs*.18,y0+cs*.68,x0+cs*.82,y0+cs*.32,fill=light,width=1)
            elif pattern == "tree_block":
                oval(cx-cs*.22,cy-cs*.25,cx+cs*.22,cy+cs*.25,fill=dark,outline=light,width=1)
                line(cx,cy-cs*.23,cx,cy+cs*.23,fill=light,width=1)
            else:
                rr=cs*(.20 if "block" not in pattern and pattern!="boulder" else .30)
                oval(cx-rr,cy-rr*.8,cx+rr,cy+rr*.8,fill=dark,outline=light,width=1)

        elif pattern in {"hazard_ring","cold_hazard","heat_hazard","tropical_hazard","lava_hazard"}:
            rr=cs*.28
            oval(cx-rr,cy-rr,cx+rr,cy+rr,fill="",outline=dark,width=max(2,lw))
            oval(cx-rr*.45,cy-rr*.45,cx+rr*.45,cy+rr*.45,fill=light,outline="")
            if pattern in {"cold_hazard","tropical_hazard","lava_hazard"}:
                for ang in (0,120,240):
                    rad=math.radians(ang + rng.randrange(-15,16))
                    line(cx+math.cos(rad)*rr*.9, cy+math.sin(rad)*rr*.9,
                         cx+math.cos(rad)*rr*1.35, cy+math.sin(rad)*rr*1.35,fill=dark,width=1)

        elif pattern in {"tufts","frost_tufts","scrub","forest_tufts","jungle_tufts"}:
            stems = 3 if pattern in {"tufts","frost_tufts","scrub"} else 5
            for i in range(stems):
                ox=(i-(stems-1)/2)*cs*.08
                line(cx,cy+cs*.25,cx+ox+(rng.random()-.5)*cs*.1,cy-cs*(.1+.2*rng.random()),fill=dark,width=1)
            if pattern == "jungle_tufts":
                oval(cx-cs*.25,cy-cs*.15,cx+cs*.02,cy+cs*.05,fill=dark,outline="")
                oval(cx-cs*.02,cy-cs*.20,cx+cs*.28,cy+cs*.03,fill=dark,outline="")

        elif pattern in {"contour","snow_ridge","dune","lava_ridge"}:
            line(x0+pad,y0+cs*.70,x0+cs*.33,y0+cs*.50,x0+cs*.55,y0+cs*.38,x0+cs-pad,y0+cs*.30,fill=dark,width=max(1,lw))
            line(x0+pad,y0+cs*.82,x0+cs*.36,y0+cs*.64,x0+cs*.60,y0+cs*.53,x0+cs-pad,y0+cs*.45,fill=light,width=1)

        elif pattern in {"waves","cold_waves","tropical_waves","hot_waves"}:
            for yy in (.34,.62):
                yline=y0+cs*yy
                line(x0+pad,yline,x0+cs*.35,yline-cs*.07,x0+cs*.60,yline+cs*.05,x0+cs-pad,yline-cs*.02,fill=light,width=1)

        elif pattern in {"track","snow_track","jungle_track"}:
            line(x0+cs*.28,y0+pad,x0+cs*.34,y0+cs-pad,fill=dark,width=1,dash=(3,2))
            line(x0+cs*.68,y0+pad,x0+cs*.62,y0+cs-pad,fill=dark,width=1,dash=(3,2))

        elif pattern in {"crosshatch","vine_crosshatch"}:
            line(x0+pad,y0+pad,x0+cs-pad,y0+cs-pad,fill=dark,width=1)
            line(x0+cs-pad,y0+pad,x0+pad,y0+cs-pad,fill=dark,width=1)
            if pattern == "vine_crosshatch":
                oval(cx-cs*.10,cy-cs*.10,cx+cs*.10,cy+cs*.10,fill="",outline=dark,width=1)

        elif pattern in {"steps","ice_steps"}:
            for i in range(3):
                yy=y0+cs*(.28+i*.19)
                line(x0+cs*(.28+i*.06),yy,x0+cs*(.72-i*.06),yy,fill=dark,width=max(1,lw))

        elif pattern == "mud":
            oval(x0+cs*.18,y0+cs*.35,x0+cs*.52,y0+cs*.64,fill=dark,outline="")
            oval(x0+cs*.48,y0+cs*.48,x0+cs*.82,y0+cs*.72,fill=light,outline="")

        elif pattern == "snow_drift":
            line(x0+pad,y0+cs*.62,x0+cs*.35,y0+cs*.55,x0+cs*.58,y0+cs*.61,x0+cs-pad,y0+cs*.50,fill=light,width=max(1,lw))

        elif pattern == "loose_sand":
            for i in range(3):
                yy=y0+cs*(.30+i*.18)
                line(x0+pad,yy,x0+cs*.50,yy-cs*.06,x0+cs-pad,yy,fill=light,width=1)

        elif pattern == "dark_hatch":
            step=max(5,cs//3)
            for k in range(-cs, cs*2, step):
                line(x0+k,y0,x0+k+cs,y0+cs,fill=dark,width=1)

    def draw_skin_pillow(self, dr, state: MapState, name: str, x: int, y: int, x0: int, y0: int, cs: int, base: str):
        if not state.textured_tiles:
            return
        _, pattern = self.skin_spec(state, name)
        rng = self._rng(state,name,x,y)
        dark=self._detail_color(base,True,.23); light=self._detail_color(base,False,.28)
        cx,cy=x0+cs/2,y0+cs/2; pad=max(2,int(cs*.12)); lw=max(1,cs//12)
        def line(points, fill=dark, width=lw): dr.line(points, fill=fill, width=width)
        def oval(box, fill=None, outline=dark, width=1): dr.ellipse(box, fill=fill, outline=outline, width=width)
        def rect(box, fill=None, outline=dark, width=1): dr.rectangle(box, fill=fill, outline=outline, width=width)

        if pattern in {"speckle","sand","leaf_litter","tropical_ground","basalt"}:
            for _ in range(3 if cs<22 else 5):
                px=x0+pad+rng.random()*(cs-2*pad); py=y0+pad+rng.random()*(cs-2*pad); rr=max(1,cs*.045)
                oval((px-rr,py-rr,px+rr,py+rr),fill=dark,outline=None)
            if pattern in {"sand","tropical_ground"}: line([(x0+pad,y0+cs*.72),(x0+cs-pad,y0+cs*.62)],fill=light,width=1)
            elif pattern=="leaf_litter":
                line([(x0+cs*.25,y0+cs*.30),(x0+cs*.38,y0+cs*.40)],width=1)
                line([(x0+cs*.62,y0+cs*.58),(x0+cs*.76,y0+cs*.48)],width=1)
            elif pattern=="basalt": line([(x0+cs*.2,y0+cs*.2),(x0+cs*.45,y0+cs*.35),(x0+cs*.7,y0+cs*.22)],width=1)
        elif pattern in {"cracks","fracture","ice_cracks","badland","lava_cracks","fissure","ice_fissure","lava_fissure"}:
            branches=2 if "fissure" in pattern else 3
            for i in range(branches):
                sx=x0+cs*(.15+.2*i); sy=y0+cs*(.2+rng.random()*.2); mx=x0+cs*(.35+rng.random()*.3); my=y0+cs*(.45+rng.random()*.18); ex=x0+cs*(.75-rng.random()*.15); ey=y0+cs*(.72+rng.random()*.12)
                line([(sx,sy),(mx,my),(ex,ey)],width=max(lw,2 if "fissure" in pattern else lw))
                if pattern=="ice_cracks": line([(mx,my),(mx+cs*.14,my-cs*.14)],fill=light,width=1)
        elif pattern in {"ice_rubble","lava_rubble"}:
            for _ in range(4):
                px=x0+pad+rng.random()*(cs-2*pad); py=y0+pad+rng.random()*(cs-2*pad); rr=cs*(.08+rng.random()*.06)
                rect((px-rr,py-rr,px+rr,py+rr),fill=light if pattern=="ice_rubble" else dark,outline=dark,width=1)
        elif pattern in {"stone","ice_stone","desert_stone","volcanic_stone","boulder","ice_block","tree_block","basalt_block","log"}:
            if pattern=="log":
                line([(x0+cs*.18,y0+cs*.68),(x0+cs*.82,y0+cs*.32)],width=max(3,cs//5)); line([(x0+cs*.18,y0+cs*.68),(x0+cs*.82,y0+cs*.32)],fill=light,width=1)
            elif pattern=="tree_block":
                oval((cx-cs*.22,cy-cs*.25,cx+cs*.22,cy+cs*.25),fill=dark,outline=light,width=1); line([(cx,cy-cs*.23),(cx,cy+cs*.23)],fill=light,width=1)
            else:
                rr=cs*(.20 if "block" not in pattern and pattern!="boulder" else .30); oval((cx-rr,cy-rr*.8,cx+rr,cy+rr*.8),fill=dark,outline=light,width=1)
        elif pattern in {"hazard_ring","cold_hazard","heat_hazard","tropical_hazard","lava_hazard"}:
            rr=cs*.28; oval((cx-rr,cy-rr,cx+rr,cy+rr),fill=None,outline=dark,width=max(2,lw)); oval((cx-rr*.45,cy-rr*.45,cx+rr*.45,cy+rr*.45),fill=light,outline=None)
            if pattern in {"cold_hazard","tropical_hazard","lava_hazard"}:
                for ang in (0,120,240):
                    rad=math.radians(ang+rng.randrange(-15,16)); line([(cx+math.cos(rad)*rr*.9,cy+math.sin(rad)*rr*.9),(cx+math.cos(rad)*rr*1.35,cy+math.sin(rad)*rr*1.35)],width=1)
        elif pattern in {"tufts","frost_tufts","scrub","forest_tufts","jungle_tufts"}:
            stems=3 if pattern in {"tufts","frost_tufts","scrub"} else 5
            for i in range(stems):
                ox=(i-(stems-1)/2)*cs*.08; line([(cx,cy+cs*.25),(cx+ox+(rng.random()-.5)*cs*.1,cy-cs*(.1+.2*rng.random()))],width=1)
            if pattern=="jungle_tufts":
                oval((cx-cs*.25,cy-cs*.15,cx+cs*.02,cy+cs*.05),fill=dark,outline=None); oval((cx-cs*.02,cy-cs*.20,cx+cs*.28,cy+cs*.03),fill=dark,outline=None)
        elif pattern in {"contour","snow_ridge","dune","lava_ridge"}:
            line([(x0+pad,y0+cs*.70),(x0+cs*.33,y0+cs*.50),(x0+cs*.55,y0+cs*.38),(x0+cs-pad,y0+cs*.30)]); line([(x0+pad,y0+cs*.82),(x0+cs*.36,y0+cs*.64),(x0+cs*.60,y0+cs*.53),(x0+cs-pad,y0+cs*.45)],fill=light,width=1)
        elif pattern in {"waves","cold_waves","tropical_waves","hot_waves"}:
            for yy in (.34,.62): line([(x0+pad,y0+cs*yy),(x0+cs*.35,y0+cs*yy-cs*.07),(x0+cs*.60,y0+cs*yy+cs*.05),(x0+cs-pad,y0+cs*yy-cs*.02)],fill=light,width=1)
        elif pattern in {"track","snow_track","jungle_track"}:
            line([(x0+cs*.28,y0+pad),(x0+cs*.34,y0+cs-pad)],width=1); line([(x0+cs*.68,y0+pad),(x0+cs*.62,y0+cs-pad)],width=1)
        elif pattern in {"crosshatch","vine_crosshatch"}:
            line([(x0+pad,y0+pad),(x0+cs-pad,y0+cs-pad)],width=1); line([(x0+cs-pad,y0+pad),(x0+pad,y0+cs-pad)],width=1)
            if pattern=="vine_crosshatch": oval((cx-cs*.10,cy-cs*.10,cx+cs*.10,cy+cs*.10),fill=None,outline=dark,width=1)
        elif pattern in {"steps","ice_steps"}:
            for i in range(3):
                yy=y0+cs*(.28+i*.19); line([(x0+cs*(.28+i*.06),yy),(x0+cs*(.72-i*.06),yy)])
        elif pattern=="mud":
            oval((x0+cs*.18,y0+cs*.35,x0+cs*.52,y0+cs*.64),fill=dark,outline=None); oval((x0+cs*.48,y0+cs*.48,x0+cs*.82,y0+cs*.72),fill=light,outline=None)
        elif pattern=="snow_drift": line([(x0+pad,y0+cs*.62),(x0+cs*.35,y0+cs*.55),(x0+cs*.58,y0+cs*.61),(x0+cs-pad,y0+cs*.50)],fill=light,width=max(1,lw))
        elif pattern=="loose_sand":
            for i in range(3):
                yy=y0+cs*(.30+i*.18); line([(x0+pad,yy),(x0+cs*.50,yy-cs*.06),(x0+cs-pad,yy)],fill=light,width=1)
        elif pattern=="dark_hatch":
            step=max(5,cs//3)
            for k in range(-cs,cs*2,step): line([(x0+k,y0),(x0+k+cs,y0+cs)],width=1)

    def draw_connectivity_canvas(self, canvas, rows, state, x, y, x0, y0, cs):
        if not state.smart_connectivity:
            return
        symbol = rows[y][x]
        if symbol in ART_CONNECTIVE_SYMBOLS:
            card, diag = self.same_symbol_neighbors(rows,x,y,symbol)
            name = self.connector_name_for_symbol(symbol)
            color = self.theme_color(state,name,"#777777")
            cx,cy=x0+cs/2,y0+cs/2
            width=max(2,cs//4)
            # Extend art toward exact matching neighbors; underlying cells remain untouched.
            for dx,dy in card:
                ex = cx + dx*(cs/2)
                ey = cy + dy*(cs/2)
                canvas.create_line(cx,cy,ex,ey,fill=color,width=width)
            for dx,dy in diag:
                ex = cx + dx*(cs/2)
                ey = cy + dy*(cs/2)
                canvas.create_line(cx,cy,ex,ey,fill=color,width=max(1,width//2))
        elif symbol == ".":
            inferred = self.inferred_gap_symbol(rows,x,y)
            if inferred:
                name=self.connector_name_for_symbol(inferred)
                color=self.theme_color(state,name,"#777777")
                ground=self.theme_color(state,"Open Ground","#d6cfb7")
                soft=blend_hex(ground,color,0.28)
                pad=max(3,cs//4)
                # Soft visual hint only; leave center and grid readable.
                canvas.create_oval(x0+pad,y0+pad,x0+cs-pad,y0+cs-pad,
                                   fill=soft,outline="")



class D12MapworksApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1280x820")
        self.minsize(980, 650)
        self.engine = MapEngine()
        self.renderer = VisualRenderer()
        self.state_obj = MapState()
        self.current_file: Path | None = None
        self.selected_layer = tk.StringVar(value="Hazards")
        self.cell_size = 20
        self.show_symbols = tk.BooleanVar(value=True)
        self.smart_connectivity_var = tk.BooleanVar(value=True)
        self.textured_tiles_var = tk.BooleanVar(value=True)

        # Phase 2C-3 Tile Lens runtime state (visual/navigation only).
        self.tile_lens_after_id = None
        self.tile_lens_hover_cell = None
        self.tile_lens_pinned_cell = None
        self.tile_lens_display_anchor = None
        self.tile_lens_selected_cell = None
        self.tile_lens_window = None
        self.tile_lens_photo = None
        self._live_map_pil = None

        # Phase 2C-6 internal cell clipboard. This is map-authority data only;
        # renderer/theme preferences are never copied with a cell.
        self.cell_copy_buffer = None
        self.cell_copy_source = None
        self.cell_copy_waiting_for_target = False

        self._build_ui()
        self.engine.generate(self.state_obj)
        self.sync_controls_from_state()
        self.refresh_all()

    def _build_ui(self):
        self._build_menu()
        main = ttk.Panedwindow(self, orient=tk.HORIZONTAL)
        main.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(main, padding=8)
        center = ttk.Frame(main, padding=8)
        right = ttk.Frame(main, padding=8)
        main.add(left, weight=0)
        main.add(center, weight=1)
        main.add(right, weight=0)

        ttk.Label(left, text="MAP SETUP", font=("TkDefaultFont", 11, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0,6))
        ttk.Label(left, text="Name").grid(row=1,column=0,sticky="w")
        self.name_var = tk.StringVar()
        ttk.Entry(left, textvariable=self.name_var, width=22).grid(row=1,column=1,sticky="ew")
        ttk.Label(left, text="Seed").grid(row=2,column=0,sticky="w")
        self.seed_var = tk.StringVar()
        ttk.Entry(left, textvariable=self.seed_var, width=22).grid(row=2,column=1,sticky="ew")
        ttk.Label(left, text="Width").grid(row=3,column=0,sticky="w")
        self.width_var = tk.IntVar(value=30)
        ttk.Spinbox(left, from_=5, to=120, textvariable=self.width_var, width=8).grid(row=3,column=1,sticky="w")
        ttk.Label(left, text="Height").grid(row=4,column=0,sticky="w")
        self.height_var = tk.IntVar(value=30)
        ttk.Spinbox(left, from_=5, to=120, textvariable=self.height_var, width=8).grid(row=4,column=1,sticky="w")
        ttk.Label(left, text="Terrain").grid(row=5,column=0,sticky="w")
        self.terrain_var = tk.StringVar(value="Generic")
        ttk.Entry(left, textvariable=self.terrain_var, width=22).grid(row=5,column=1,sticky="ew")

        ttk.Label(left, text="Visual Theme").grid(row=6,column=0,sticky="w")
        self.theme_var = tk.StringVar(value="Generic")
        theme_combo = ttk.Combobox(left, textvariable=self.theme_var,
                                   values=list(THEMES.keys()), width=14, state="readonly")
        theme_combo.grid(row=6,column=1,sticky="ew")
        theme_combo.bind("<<ComboboxSelected>>", lambda e: self.on_visual_settings_changed())

        ttk.Label(left, text="Mood(s)").grid(row=7,column=0,sticky="w")
        self.mood_var = tk.StringVar(value="")
        mood_entry = ttk.Entry(left, textvariable=self.mood_var, width=22)
        mood_entry.grid(row=7,column=1,sticky="ew")
        mood_entry.bind("<FocusOut>", lambda e: self.on_visual_settings_changed())
        mood_entry.bind("<Return>", lambda e: self.on_visual_settings_changed())
        ttk.Label(
            left,
            text="Comma separated; custom words allowed",
            wraplength=210,
            justify="left"
        ).grid(row=8,column=0,columnspan=2,sticky="w",pady=(2,4))

        ttk.Checkbutton(left, text="Smart art connectivity",
                        variable=self.smart_connectivity_var,
                        command=self.on_visual_settings_changed).grid(
                            row=9,column=0,columnspan=2,sticky="w")
        ttk.Checkbutton(left, text="Theme texture details",
                        variable=self.textured_tiles_var,
                        command=self.on_visual_settings_changed).grid(
                            row=10,column=0,columnspan=2,sticky="w")

        ttk.Label(left, text="Shape Style").grid(row=11,column=0,sticky="w",pady=(6,0))
        self.shape_style_var = tk.StringVar(value=self.state_obj.shape_style)
        shape_combo = ttk.Combobox(left, textvariable=self.shape_style_var,
                                   values=["Strict","Connected","Natural"],
                                   width=14, state="readonly")
        shape_combo.grid(row=11,column=1,sticky="ew",pady=(6,0))
        shape_combo.bind("<<ComboboxSelected>>", lambda e: self.on_visual_settings_changed())

        ttk.Label(left, text="Edge Strength").grid(row=12,column=0,sticky="w")
        self.edge_strength_var = tk.StringVar(value=self.state_obj.edge_strength)
        edge_combo = ttk.Combobox(left, textvariable=self.edge_strength_var,
                                  values=["Low","Medium","High"],
                                  width=14, state="readonly")
        edge_combo.grid(row=12,column=1,sticky="ew")
        edge_combo.bind("<<ComboboxSelected>>", lambda e: self.on_visual_settings_changed())

        ttk.Button(left, text="Generate / Regenerate", command=self.generate).grid(row=11,column=0,columnspan=2,sticky="ew",pady=(8,10))

        ttk.Separator(left).grid(row=12,column=0,columnspan=2,sticky="ew",pady=4)
        ttk.Label(left, text="UNIVERSAL DENSITY", font=("TkDefaultFont", 10, "bold")).grid(row=13,column=0,columnspan=2,sticky="w")
        self.density_vars: dict[str, tk.StringVar] = {}
        r = 14
        for name, folder, symbol, color in LAYER_DEFS:
            ttk.Label(left, text=f"{symbol} {name}").grid(row=r,column=0,sticky="w")
            v = tk.StringVar(value="None")
            self.density_vars[name] = v
            cb = ttk.Combobox(left, textvariable=v, values=DENSITIES, width=8, state="readonly")
            cb.grid(row=r,column=1,sticky="e")
            r += 1

        ttk.Separator(left).grid(row=r,column=0,columnspan=2,sticky="ew",pady=5); r += 1
        ttk.Label(left, text="EDIT LAYER", font=("TkDefaultFont", 10, "bold")).grid(row=r,column=0,columnspan=2,sticky="w"); r+=1
        self.layer_combo = ttk.Combobox(left, textvariable=self.selected_layer, state="readonly", width=24)
        self.layer_combo.grid(row=r,column=0,columnspan=2,sticky="ew"); r += 1
        self.layer_combo.bind("<<ComboboxSelected>>", lambda e: self.sync_selected_layer_controls())

        ttk.Label(left, text="Render layer").grid(row=r,column=0,sticky="w")
        self.render_layer_var = tk.IntVar(value=0)
        ttk.Spinbox(left, from_=0, to=999, textvariable=self.render_layer_var, width=7).grid(row=r,column=1,sticky="w"); r+=1
        ttk.Button(left, text="Apply Render Layer", command=self.apply_selected_render_layer).grid(row=r,column=0,columnspan=2,sticky="ew",pady=(2,0)); r+=1

        ttk.Label(left, text="Elevation height (ft)").grid(row=r,column=0,sticky="w")
        self.elevation_height_var = tk.IntVar(value=DEFAULT_ELEVATION_HEIGHT_FT)
        ttk.Spinbox(left, from_=-500, to=5000, increment=5, textvariable=self.elevation_height_var, width=7).grid(row=r,column=1,sticky="w"); r+=1

        ttk.Button(left, text="Add Custom Marker", command=self.add_custom_layer).grid(row=r,column=0,columnspan=2,sticky="ew",pady=(4,0)); r+=1
        ttk.Button(left, text="Reset Overrides", command=self.reset_overrides).grid(row=r,column=0,columnspan=2,sticky="ew",pady=(4,0)); r+=1
        ttk.Checkbutton(left, text="Show symbols on tiles", variable=self.show_symbols, command=self.draw_canvas).grid(row=r,column=0,columnspan=2,sticky="w",pady=(4,0)); r+=1

        ttk.Separator(left).grid(row=r,column=0,columnspan=2,sticky="ew",pady=5); r+=1
        ttk.Label(left, text="VISUAL GUIDE LINE", font=("TkDefaultFont", 10, "bold")).grid(row=r,column=0,columnspan=2,sticky="w"); r+=1

        ttk.Label(left, text="Tool").grid(row=r,column=0,sticky="w")
        self.canvas_tool_var = tk.StringVar(value="Cell Edit")
        tool_combo = ttk.Combobox(left, textvariable=self.canvas_tool_var,
                                  values=["Cell Edit","Guide Line","Terrain Pen","Copy Cell","Tile Lens"],
                                  state="readonly", width=14)
        tool_combo.grid(row=r,column=1,sticky="ew"); r+=1
        tool_combo.bind("<<ComboboxSelected>>", lambda e: self.cancel_pending_guide())

        ttk.Label(left, text="Guide width").grid(row=r,column=0,sticky="w")
        self.guide_width_var = tk.IntVar(value=1)
        ttk.Spinbox(left, from_=1, to=7, textvariable=self.guide_width_var, width=6).grid(row=r,column=1,sticky="w"); r+=1

        ttk.Label(left, text="Pen width").grid(row=r,column=0,sticky="w")
        self.pen_width_var = tk.IntVar(value=1)
        ttk.Spinbox(left, from_=1, to=7, textvariable=self.pen_width_var, width=6).grid(row=r,column=1,sticky="w"); r+=1

        ttk.Button(left, text="Undo Last Guide", command=self.undo_last_guide).grid(row=r,column=0,columnspan=2,sticky="ew",pady=(4,0)); r+=1
        ttk.Button(left, text="Clear Guides", command=self.clear_guides).grid(row=r,column=0,columnspan=2,sticky="ew",pady=(4,0)); r+=1
        ttk.Label(
            left,
            text="Cell Edit: normal single-cell editing.\nGuide Line: click start, then end.\nTerrain Pen: left-drag paints, right-drag erases selected terrain.\nCopy Cell: click source, then destination.\nTile Lens: click a tile to pin a 5x5 local view.",
            foreground="#555"
        ).grid(row=r,column=0,columnspan=2,sticky="w",pady=(6,0))

        # Center tabs
        self.tabs = ttk.Notebook(center)
        self.tabs.pack(fill=tk.BOTH, expand=True)
        tile_tab = ttk.Frame(self.tabs)
        ascii_tab = ttk.Frame(self.tabs)
        self.tabs.add(tile_tab, text="Tile View")
        self.tabs.add(ascii_tab, text="ASCII View")

        self.canvas = tk.Canvas(tile_tab, background="#1f2326", highlightthickness=0)
        self.hscroll = ttk.Scrollbar(tile_tab, orient=tk.HORIZONTAL, command=self.canvas.xview)
        self.vscroll = ttk.Scrollbar(tile_tab, orient=tk.VERTICAL, command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=self.hscroll.set, yscrollcommand=self.vscroll.set)
        self.canvas.grid(row=0,column=0,sticky="nsew")
        self.vscroll.grid(row=0,column=1,sticky="ns")
        self.hscroll.grid(row=1,column=0,sticky="ew")
        tile_tab.rowconfigure(0, weight=1); tile_tab.columnconfigure(0, weight=1)
        self.pending_guide_start = None
        self.pen_active = False
        self.pen_erase = False
        self.pen_seen_cells = set()

        self.canvas.bind("<Button-1>", self.on_canvas_left)
        self.canvas.bind("<Button-3>", self.on_canvas_right)
        self.canvas.bind("<B1-Motion>", self.on_canvas_left_drag)
        self.canvas.bind("<B3-Motion>", self.on_canvas_right_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_canvas_pen_release)
        self.canvas.bind("<ButtonRelease-3>", self.on_canvas_pen_release)
        self.canvas.bind("<Motion>", self.on_canvas_motion)
        self.canvas.bind("<Leave>", self.on_canvas_leave)

        self.ascii_text = tk.Text(ascii_tab, wrap="none", font=("Consolas", 11), background="#0b0f0d", foreground="#8ee69b", insertbackground="white")
        ays = ttk.Scrollbar(ascii_tab, orient=tk.VERTICAL, command=self.ascii_text.yview)
        axs = ttk.Scrollbar(ascii_tab, orient=tk.HORIZONTAL, command=self.ascii_text.xview)
        self.ascii_text.configure(yscrollcommand=ays.set, xscrollcommand=axs.set)
        self.ascii_text.grid(row=0,column=0,sticky="nsew"); ays.grid(row=0,column=1,sticky="ns"); axs.grid(row=1,column=0,sticky="ew")
        ascii_tab.rowconfigure(0,weight=1); ascii_tab.columnconfigure(0,weight=1)

        # Right side legend/actions
        ttk.Label(right, text="INTERACTIVE LEGEND", font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
        self.legend_frame = ttk.Frame(right)
        self.legend_frame.pack(fill=tk.X, pady=(4,12))
        ttk.Separator(right).pack(fill=tk.X, pady=4)
        ttk.Label(right, text="MAP OUTPUT", font=("TkDefaultFont", 10, "bold")).pack(anchor="w", pady=(4,4))
        for label, cmd in [
            ("Copy Map", self.copy_map),
            ("Export Map (.txt)", self.export_txt),
            ("Export Data (.json)", self.export_json),
            ("Export Tile PNG", self.export_png_dialog),
            ("Print / Export Setup", self.open_export_setup),
            ("Run Phase 1D Self-Test", self.run_phase1d_self_test),
            ("Export Bundle", self.export_bundle),
            ("Print-Friendly HTML", self.export_html),
        ]:
            ttk.Button(right, text=label, command=cmd).pack(fill=tk.X, pady=2)
        ttk.Separator(right).pack(fill=tk.X, pady=8)
        ttk.Label(right, text="Creator Notes").pack(anchor="w")
        self.notes_text = tk.Text(right, width=30, height=12, wrap="word")
        self.notes_text.pack(fill=tk.BOTH, expand=True)

        self.status = tk.StringVar(value="Ready")
        ttk.Label(self, textvariable=self.status, relief=tk.SUNKEN, anchor="w").pack(fill=tk.X, side=tk.BOTTOM)

    def _build_menu(self):
        m = tk.Menu(self)
        fm = tk.Menu(m, tearoff=False)
        fm.add_command(label="New", command=self.new_map)
        fm.add_command(label="Open...", command=self.open_map)
        fm.add_command(label="Save", command=self.save_map)
        fm.add_command(label="Save As...", command=lambda: self.save_map(save_as=True))
        fm.add_separator()
        fm.add_command(label="Copy Map", command=self.copy_map)
        fm.add_command(label="Export Bundle...", command=self.export_bundle)
        fm.add_separator()
        fm.add_command(label="Exit", command=self.destroy)
        m.add_cascade(label="File", menu=fm)
        vm = tk.Menu(m, tearoff=False)
        vm.add_command(label="Tile View", command=lambda: self.tabs.select(0))
        vm.add_command(label="ASCII View", command=lambda: self.tabs.select(1))
        m.add_cascade(label="View", menu=vm)
        hm = tk.Menu(m, tearoff=False)
        hm.add_command(label="About", command=lambda: messagebox.showinfo(APP_NAME, f"{APP_NAME} {APP_VERSION}\nLocal deterministic D12 map generator."))
        m.add_cascade(label="Help", menu=hm)
        self.config(menu=m)

    def on_visual_settings_changed(self):
        if hasattr(self, "theme_var"):
            self.state_obj.visual_theme = self.theme_var.get() or "Generic"
        if hasattr(self, "mood_var"):
            self.state_obj.mood_tags = [x.strip() for x in self.mood_var.get().split(",") if x.strip()]
        self.state_obj.smart_connectivity = bool(self.smart_connectivity_var.get())
        self.state_obj.textured_tiles = bool(self.textured_tiles_var.get())
        if hasattr(self, "shape_style_var"):
            self.state_obj.shape_style = self.shape_style_var.get()
        if hasattr(self, "edge_strength_var"):
            self.state_obj.edge_strength = self.edge_strength_var.get()
        self.draw_canvas()
        self.rebuild_legend()
        self.status.set(
            f"Theme {self.state_obj.visual_theme} | Shape {self.state_obj.shape_style} "
            f"| Edge {self.state_obj.edge_strength} | texture "
            f"{'on' if self.state_obj.textured_tiles else 'off'} | connectivity "
            f"{'on' if self.state_obj.smart_connectivity else 'off'} "
            f"| render {getattr(self, 'last_render_ms', 0.0):.0f} ms"
        )

    def pull_controls_to_state(self):
        self.state_obj.name = self.name_var.get().strip() or "Untitled Map"
        self.state_obj.seed = self.seed_var.get().strip() or "D12-001"
        self.state_obj.width = max(5, min(120, int(self.width_var.get())))
        self.state_obj.height = max(5, min(120, int(self.height_var.get())))
        self.state_obj.terrain = self.terrain_var.get().strip() or "Generic"
        self.state_obj.visual_theme = self.theme_var.get().strip() or "Generic"
        if hasattr(self, "mood_var"):
            self.state_obj.mood_tags = [x.strip() for x in self.mood_var.get().split(",") if x.strip()]
        self.state_obj.smart_connectivity = bool(self.smart_connectivity_var.get())
        self.state_obj.textured_tiles = bool(self.textured_tiles_var.get())
        if hasattr(self, "shape_style_var"):
            self.state_obj.shape_style = self.shape_style_var.get()
        if hasattr(self, "edge_strength_var"):
            self.state_obj.edge_strength = self.edge_strength_var.get()
        self.state_obj.notes = self.notes_text.get("1.0", "end-1c")
        for name, v in self.density_vars.items():
            self.state_obj.densities[name] = v.get()

    def sync_controls_from_state(self):
        self.name_var.set(self.state_obj.name)
        self.seed_var.set(self.state_obj.seed)
        self.width_var.set(self.state_obj.width)
        self.height_var.set(self.state_obj.height)
        self.terrain_var.set(self.state_obj.terrain)
        self.theme_var.set(self.state_obj.visual_theme if self.state_obj.visual_theme in THEMES else "Generic")
        if hasattr(self, "mood_var"):
            self.mood_var.set(", ".join(self.state_obj.mood_tags))
        self.smart_connectivity_var.set(bool(self.state_obj.smart_connectivity))
        self.textured_tiles_var.set(bool(self.state_obj.textured_tiles))
        if hasattr(self, "shape_style_var"):
            self.shape_style_var.set(self.state_obj.shape_style)
        if hasattr(self, "edge_strength_var"):
            self.edge_strength_var.set(self.state_obj.edge_strength)
        for name, v in self.density_vars.items():
            v.set(self.state_obj.densities.get(name, "None"))
        self.notes_text.delete("1.0", tk.END)
        self.notes_text.insert("1.0", self.state_obj.notes)
        self.update_layer_combo()

    def update_layer_combo(self):
        values = [name for name, *_ in LAYER_DEFS] + [CUSTOM_PREFIX + x.name for x in self.state_obj.custom_layers]
        self.layer_combo["values"] = values
        if self.selected_layer.get() not in values and values:
            self.selected_layer.set(values[0])
        if hasattr(self, "render_layer_var"):
            self.sync_selected_layer_controls()
        self.rebuild_legend()

    def rebuild_legend(self):
        for w in self.legend_frame.winfo_children():
            w.destroy()
        for name, folder, symbol, color in LAYER_DEFS:
            row = ttk.Frame(self.legend_frame)
            row.pack(fill=tk.X, pady=1)
            render_color = self.renderer.theme_color(self.state_obj, name, color)
            swatch = tk.Label(row, text="  ", background=render_color, width=2)
            swatch.pack(side=tk.LEFT)
            skin_label = self.renderer.skin_label(self.state_obj, name)
            ttk.Label(row, text=f" {symbol}  {name} — {skin_label}", wraplength=245, justify="left").pack(side=tk.LEFT)
        for custom in self.state_obj.custom_layers:
            row = ttk.Frame(self.legend_frame)
            row.pack(fill=tk.X, pady=1)
            tk.Label(row, text="  ", background=custom.color, width=2).pack(side=tk.LEFT)
            ttk.Label(row, text=f" {custom.symbol}  {custom.name}").pack(side=tk.LEFT)

    def render_layer_for(self, name: str) -> int:
        if name.startswith(CUSTOM_PREFIX):
            name = name[len(CUSTOM_PREFIX):]
            return int(self.state_obj.custom_render_layers.get(name, CUSTOM_RENDER_LAYER_DEFAULT))
        return int(self.state_obj.render_layers.get(name, DEFAULT_RENDER_LAYERS.get(name, 0)))

    def sync_selected_layer_controls(self):
        if not hasattr(self, "render_layer_var"):
            return
        sel = self.selected_layer.get()
        self.render_layer_var.set(self.render_layer_for(sel))
        if sel == "Elevation" and hasattr(self, "elevation_height_var"):
            # The current stamp height remains user-controlled. Do not overwrite it
            # just because a different elevation cell may contain another height.
            try:
                self.elevation_height_var.set(int(self.elevation_height_var.get()))
            except Exception:
                self.elevation_height_var.set(DEFAULT_ELEVATION_HEIGHT_FT)

    def apply_selected_render_layer(self):
        sel = self.selected_layer.get()
        try:
            value = max(0, min(999, int(self.render_layer_var.get())))
        except Exception:
            value = 0
        if sel.startswith(CUSTOM_PREFIX):
            name = sel[len(CUSTOM_PREFIX):]
            self.state_obj.custom_render_layers[name] = value
        else:
            self.state_obj.render_layers[sel] = value
        self.refresh_all()
        self.status.set(f"Render layer: {sel} = {value}")

    @staticmethod
    def _elevation_key(x: int, y: int) -> str:
        return f"{x},{y}"

    def elevation_height_at(self, x: int, y: int) -> int:
        return int(self.state_obj.elevation_heights.get(
            self._elevation_key(x, y),
            DEFAULT_ELEVATION_HEIGHT_FT
        ))

    def _current_elevation_stamp_height(self) -> int:
        try:
            value = int(self.elevation_height_var.get())
        except Exception:
            value = DEFAULT_ELEVATION_HEIGHT_FT
        # Snap to the 5-ft grid convention.
        return int(round(value / 5.0) * 5)

    def generate(self):
        self.pull_controls_to_state()
        self.engine.generate(self.state_obj)
        self.status.set(f"Generated seed {self.state_obj.seed}")
        self.refresh_all()

    def refresh_all(self):
        self.draw_canvas()
        self.refresh_ascii()
        self.rebuild_legend()

    def _build_visual_cell_cache(self):
        """Build terrain membership once for one complete frame."""
        normal = {
            name: self.engine.cells_for_layer(self.state_obj, name)
            for name, *_ in LAYER_DEFS
        }
        custom = {
            c.name: {tuple(v) for v in self.state_obj.custom_cells.get(c.name, [])}
            for c in self.state_obj.custom_layers
        }
        return normal, custom

    def layer_visual(self, x:int, y:int, cache=None):
        hits=[]
        if cache is None:
            normal_cache, custom_cache = self._build_visual_cell_cache()
        else:
            normal_cache, custom_cache = cache

        p = (x, y)
        indexed_hits = []
        for idx, (name, folder, symbol, color) in enumerate(LAYER_DEFS):
            if p in normal_cache.get(name, set()):
                indexed_hits.append((
                    self.render_layer_for(name), idx, name, symbol, color
                ))
        custom_base = len(LAYER_DEFS)
        for idx, custom in enumerate(self.state_obj.custom_layers):
            if p in custom_cache.get(custom.name, set()):
                indexed_hits.append((
                    self.render_layer_for(CUSTOM_PREFIX + custom.name),
                    custom_base + idx, custom.name, custom.symbol, custom.color
                ))

        indexed_hits.sort(key=lambda item: (item[0], item[1]))
        hits = [(name, symbol, color) for _, _, name, symbol, color in indexed_hits]
        if hits:
            name,symbol,color = hits[-1]
            return (name,symbol,self.renderer.theme_color(self.state_obj,name,color)), hits
        return ("Open Ground", ".", self.renderer.theme_color(self.state_obj,"Open Ground","#d6cfb7")), []

    def _render_live_bitmap(self):
        """Render the live battlefield into one Pillow image."""
        try:
            from PIL import Image, ImageDraw, ImageFont
        except Exception:
            return None

        w, h = self.state_obj.width, self.state_obj.height
        cs = self.cell_size
        rows = self.engine.ascii_grid(self.state_obj)
        visual_cache = self._build_visual_cell_cache()
        normal_cache, _ = visual_cache

        img = Image.new(
            "RGB",
            (max(1, w * cs), max(1, h * cs)),
            self.renderer.theme_color(self.state_obj, "Open Ground", "#d6cfb7")
        )
        dr = ImageDraw.Draw(img)
        natural = self.renderer.natural_layers()

        for y in range(h):
            for x in range(w):
                (name, symbol, color), hits = self.layer_visual(x, y, cache=visual_cache)
                x0, y0 = x * cs, y * cs

                if name in natural:
                    self.renderer.draw_region_cell_pillow(
                        dr, self.state_obj, name, x, y, x0, y0, cs, color,
                        show_grid=False,
                        cells=normal_cache.get(name)
                    )
                else:
                    dr.rectangle(
                        (x0, y0, x0 + cs - 1, y0 + cs - 1),
                        fill=color,
                        outline="#6f6f6f"
                    )

                self.renderer.draw_skin_pillow(
                    dr, self.state_obj, name, x, y, x0, y0, cs, color
                )

        if self.state_obj.smart_connectivity:
            for y in range(h):
                for x in range(w):
                    symbol = rows[y][x]
                    x0, y0 = x * cs, y * cs
                    cx, cy = x0 + cs/2, y0 + cs/2

                    if symbol in ART_CONNECTIVE_SYMBOLS:
                        card, diag = self.renderer.same_symbol_neighbors(rows, x, y, symbol)
                        name = self.renderer.connector_name_for_symbol(symbol)
                        color = self.renderer.theme_color(self.state_obj, name, "#777777")
                        width = max(2, cs // 4)
                        for dx, dy in card:
                            dr.line((cx, cy, cx + dx*cs/2, cy + dy*cs/2),
                                    fill=color, width=width)
                        for dx, dy in diag:
                            dr.line((cx, cy, cx + dx*cs/2, cy + dy*cs/2),
                                    fill=color, width=max(1, width//2))
                    elif symbol == ".":
                        inferred = self.renderer.inferred_gap_symbol(rows, x, y)
                        if inferred:
                            name = self.renderer.connector_name_for_symbol(inferred)
                            color = self.renderer.theme_color(self.state_obj, name, "#777777")
                            ground = self.renderer.theme_color(
                                self.state_obj, "Open Ground", "#d6cfb7"
                            )
                            soft = blend_hex(ground, color, 0.28)
                            pad = max(3, cs//4)
                            dr.ellipse((x0+pad, y0+pad, x0+cs-pad, y0+cs-pad),
                                       fill=soft)

        self.renderer.draw_guides_pillow(dr, self.state_obj, cs)

        if self.show_symbols.get():
            try:
                font = ImageFont.truetype("consola.ttf", max(7, cs//2))
                small_font = ImageFont.truetype("consola.ttf", max(6, cs//3))
            except Exception:
                font = None
                small_font = None
            for y, row in enumerate(rows):
                for x, symbol in enumerate(row):
                    if symbol != ".":
                        dr.text(
                            (x*cs + cs*.28, y*cs + cs*.12),
                            symbol,
                            fill="#111111",
                            font=font
                        )

            # Elevation height is metadata, not a new Universal symbol.
            elevation_cells = normal_cache.get("Elevation", set())
            for x, y in elevation_cells:
                feet = self.elevation_height_at(x, y)
                dr.text(
                    (x*cs + 2, y*cs + cs*.60),
                    f"{feet}'",
                    fill="#111111",
                    font=small_font
                )

        return img

    def draw_canvas(self):
        if not hasattr(self, "canvas"):
            return

        started = time.perf_counter()
        c = self.canvas
        c.delete("all")
        w, h = self.state_obj.width, self.state_obj.height
        cs = self.cell_size

        img = self._render_live_bitmap()
        if img is None:
            c.create_text(
                20, 20, anchor="nw",
                text="Live bitmap renderer requires Pillow.",
                fill="white"
            )
            self.last_render_ms = (time.perf_counter() - started) * 1000.0
            return

        from PIL import ImageTk
        self._live_map_pil = img
        self._live_map_photo = ImageTk.PhotoImage(img)
        self._live_map_image_id = c.create_image(
            0, 0, anchor="nw", image=self._live_map_photo, tags=("map_bitmap",)
        )

        # A pinned Tile Lens keeps a visible marker on the source tile.
        if self.tile_lens_pinned_cell is not None:
            px, py = self.tile_lens_pinned_cell
            if 0 <= px < w and 0 <= py < h:
                x0, y0 = px*cs, py*cs
                c.create_rectangle(
                    x0+1, y0+1, x0+cs-1, y0+cs-1,
                    outline="#ffffff", width=3, tags=("tile_lens_focus",)
                )
                c.create_rectangle(
                    x0+4, y0+4, x0+cs-4, y0+cs-4,
                    outline="#111111", width=1, tags=("tile_lens_focus",)
                )

        c.configure(scrollregion=(0, 0, w*cs, h*cs))
        self.last_render_ms = (time.perf_counter() - started) * 1000.0

    def refresh_ascii(self):
        rows=self.engine.ascii_grid(self.state_obj)
        header = f"{self.state_obj.name} | Seed {self.state_obj.seed} | {self.state_obj.width}x{self.state_obj.height}\n"
        self.ascii_text.delete("1.0", tk.END)
        self.ascii_text.insert("1.0", header + "\n".join(rows))

    def _cancel_tile_lens_timer(self):
        if self.tile_lens_after_id is not None:
            try:
                self.after_cancel(self.tile_lens_after_id)
            except Exception:
                pass
        self.tile_lens_after_id = None

    def on_canvas_motion(self, event):
        # Do not pop a lens while actively painting.
        if getattr(self, "pen_active", False):
            self._cancel_tile_lens_timer()
            return

        p = self.canvas_cell(event)
        if not p:
            self.on_canvas_leave(event)
            return

        # A pinned lens stays where it is until explicitly moved/unpinned.
        if self.tile_lens_pinned_cell is not None:
            return

        if p == self.tile_lens_hover_cell:
            return

        self._cancel_tile_lens_timer()
        self.tile_lens_hover_cell = p
        root_x = self.winfo_pointerx()
        root_y = self.winfo_pointery()
        self.tile_lens_after_id = self.after(
            2000,
            lambda cell=p, rx=root_x, ry=root_y: self.show_tile_lens(
                cell[0], cell[1], pinned=False, screen_x=rx, screen_y=ry
            )
        )

    def on_canvas_leave(self, event=None):
        self._cancel_tile_lens_timer()
        self.tile_lens_hover_cell = None
        if self.tile_lens_pinned_cell is None:
            self.close_tile_lens()

    def close_tile_lens(self):
        self._cancel_tile_lens_timer()
        if self.tile_lens_window is not None:
            try:
                self.tile_lens_window.destroy()
            except Exception:
                pass
        self.tile_lens_window = None
        self.tile_lens_photo = None

    def unpin_tile_lens(self):
        self.tile_lens_pinned_cell = None
        self.tile_lens_display_anchor = None
        self.tile_lens_selected_cell = None
        self.close_tile_lens()
        if hasattr(self, "canvas"):
            self.canvas.delete("tile_lens_focus")
        self.status.set("Tile Lens unpinned")

    def pin_tile_lens(self, x, y):
        self.tile_lens_pinned_cell = (x, y)
        self.tile_lens_selected_cell = (x, y)
        self.show_tile_lens(x, y, pinned=True)
        self.draw_tile_lens_focus()
        self.status.set(f"Tile Lens pinned at {col_label(x)}{y+1}")

    def draw_tile_lens_focus(self):
        if not hasattr(self, "canvas"):
            return
        self.canvas.delete("tile_lens_focus")
        if self.tile_lens_pinned_cell is None:
            return
        x, y = self.tile_lens_pinned_cell
        cs = self.cell_size
        x0, y0 = x*cs, y*cs
        self.canvas.create_rectangle(
            x0+1, y0+1, x0+cs-1, y0+cs-1,
            outline="#ffffff", width=3, tags=("tile_lens_focus",)
        )
        self.canvas.create_rectangle(
            x0+4, y0+4, x0+cs-4, y0+cs-4,
            outline="#111111", width=1, tags=("tile_lens_focus",)
        )

    def _lens_layer_display_values(self):
        values = []
        for name, folder, symbol, color in LAYER_DEFS:
            values.append(f"{symbol}  {name}")
        for custom in self.state_obj.custom_layers:
            values.append(f"{custom.symbol}  {CUSTOM_PREFIX}{custom.name}")
        return values

    def _lens_layer_display_for_selected(self):
        sel = self.selected_layer.get()
        for name, folder, symbol, color in LAYER_DEFS:
            if sel == name:
                return f"{symbol}  {name}"
        if sel.startswith(CUSTOM_PREFIX):
            cname = sel[len(CUSTOM_PREFIX):]
            custom = next((c for c in self.state_obj.custom_layers if c.name == cname), None)
            if custom is not None:
                return f"{custom.symbol}  {CUSTOM_PREFIX}{custom.name}"
        return sel

    def _on_lens_layer_selected(self, event=None):
        if not hasattr(self, "tile_lens_layer_var"):
            return
        display = self.tile_lens_layer_var.get()
        chosen = None
        for name, folder, symbol, color in LAYER_DEFS:
            if display == f"{symbol}  {name}":
                chosen = name
                break
        if chosen is None:
            for custom in self.state_obj.custom_layers:
                if display == f"{custom.symbol}  {CUSTOM_PREFIX}{custom.name}":
                    chosen = CUSTOM_PREFIX + custom.name
                    break
        if chosen is not None:
            self.selected_layer.set(chosen)
            self.sync_selected_layer_controls()
            self.status.set(f"Edit layer: {chosen}")

    def _sync_lens_tool_controls(self):
        if hasattr(self, "tile_lens_tool_var"):
            self.tile_lens_tool_var.set(self.canvas_tool_var.get())
        if hasattr(self, "tile_lens_layer_var"):
            self.tile_lens_layer_combo.configure(values=self._lens_layer_display_values())
            self.tile_lens_layer_var.set(self._lens_layer_display_for_selected())

    def _capture_cell_for_copy(self, x, y):
        normal_layers = {}
        for name, *_ in LAYER_DEFS:
            normal_layers[name] = (x, y) in self.engine.cells_for_layer(self.state_obj, name)

        custom_layers = {}
        for custom in self.state_obj.custom_layers:
            pts = {tuple(v) for v in self.state_obj.custom_cells.get(custom.name, [])}
            custom_layers[custom.name] = (x, y) in pts

        key = self._cell_slot_key(x, y)
        explicit_slots = self.state_obj.cell_slots.get(key, {})
        slots = dict(explicit_slots) if isinstance(explicit_slots, dict) else {}

        self.cell_copy_buffer = {
            "normal_layers": normal_layers,
            "custom_layers": custom_layers,
            "cell_slots": slots,
            "elevation_height": self.state_obj.elevation_heights.get(self._elevation_key(x, y)),
        }
        self.cell_copy_source = (x, y)
        self.status.set(f"Copied cell {col_label(x)}{y+1}")

    def _paste_copied_cell(self, x, y):
        if not self.cell_copy_buffer:
            self.status.set("No copied cell yet")
            return False

        data = self.cell_copy_buffer

        # Make every normal mechanical layer at the destination match the source.
        for name, present in data.get("normal_layers", {}).items():
            self._ensure_layer_at(name, x, y, bool(present))

        # Match custom-marker presence without changing the custom-marker definitions.
        for custom in self.state_obj.custom_layers:
            pts = {tuple(v) for v in self.state_obj.custom_cells.get(custom.name, [])}
            if data.get("custom_layers", {}).get(custom.name, False):
                pts.add((x, y))
            else:
                pts.discard((x, y))
            self.state_obj.custom_cells[custom.name] = [[a, b] for a, b in sorted(pts)]

        # Copy explicit fixed-slot values.
        dest_key = self._cell_slot_key(x, y)
        copied_slots = dict(data.get("cell_slots", {}))
        if copied_slots:
            self.state_obj.cell_slots[dest_key] = copied_slots
        else:
            self.state_obj.cell_slots.pop(dest_key, None)

        # Copy authoritative elevation measurement.
        ekey = self._elevation_key(x, y)
        copied_height = data.get("elevation_height")
        if copied_height is None:
            self.state_obj.elevation_heights.pop(ekey, None)
        else:
            self.state_obj.elevation_heights[ekey] = copied_height

        self.refresh_all()
        if self.tile_lens_display_anchor is not None:
            ax, ay = self.tile_lens_display_anchor
            self.tile_lens_selected_cell = (x, y)
            self.show_tile_lens(ax, ay, pinned=self.tile_lens_pinned_cell is not None)
        src = self.cell_copy_source
        if src:
            self.status.set(
                f"Copied {col_label(src[0])}{src[1]+1} -> {col_label(x)}{y+1}"
            )
        else:
            self.status.set(f"Pasted copied cell to {col_label(x)}{y+1}")
        return True

    def copy_selected_lens_cell(self):
        if self.tile_lens_selected_cell is None:
            self.status.set("Select a lens cell first")
            return
        x, y = self.tile_lens_selected_cell
        self._capture_cell_for_copy(x, y)

    def paste_to_selected_lens_cell(self):
        if self.tile_lens_selected_cell is None:
            self.status.set("Select a lens cell first")
            return
        x, y = self.tile_lens_selected_cell
        self._paste_copied_cell(x, y)

    def _lens_cell_from_event(self, event):
        anchor = self.tile_lens_display_anchor
        if anchor is None:
            return None
        lens_cs = 56
        lx = int(event.x // lens_cs)
        ly = int(event.y // lens_cs)
        if not (0 <= lx < 5 and 0 <= ly < 5):
            return None
        ax, ay = anchor
        mx = ax + (lx - 2)
        my = ay + (ly - 2)
        if not (0 <= mx < self.state_obj.width and 0 <= my < self.state_obj.height):
            return None
        return mx, my

    def _paint_lens_cell(self, x, y, erase=False):
        layer = self._terrain_pen_layer()
        if layer is None:
            messagebox.showinfo(
                "Terrain Pen",
                "Choose a normal terrain layer under Symbol / Layer first."
            )
            return

        width = self._pen_width()
        for px, py in self._brush_cells(x, y, width):
            if erase:
                self.engine.erase_layer_cell(self.state_obj, layer, px, py)
                if layer == "Elevation":
                    self.state_obj.elevation_heights.pop(self._elevation_key(px, py), None)
            else:
                self.engine.paint_layer_cell(self.state_obj, layer, px, py)
                if layer == "Elevation":
                    self.state_obj.elevation_heights[self._elevation_key(px, py)] = self._current_elevation_stamp_height()
            self._invalidate_cell_slot_for_layer(px, py, layer)

        self.refresh_all()
        if self.tile_lens_display_anchor is not None:
            ax, ay = self.tile_lens_display_anchor
            self.tile_lens_selected_cell = (x, y)
            self.show_tile_lens(ax, ay, pinned=True)
        self.status.set(
            f"{'Erased' if erase else 'Painted'} {layer} at {col_label(x)}{y+1}"
        )

    def on_tile_lens_image_right_click(self, event):
        p = self._lens_cell_from_event(event)
        if p is None:
            return
        x, y = p
        self.tile_lens_selected_cell = p
        tool = self.canvas_tool_var.get() if hasattr(self, "canvas_tool_var") else "Cell Edit"

        if tool == "Terrain Pen":
            self._paint_lens_cell(x, y, erase=True)
            return

        # In every other lens mode, right-click simply selects the enlarged cell.
        if self.tile_lens_display_anchor is not None:
            ax, ay = self.tile_lens_display_anchor
            self.show_tile_lens(ax, ay, pinned=True)
        self.status.set(f"Tile Lens: selected {col_label(x)}{y+1}")

    def _tile_stack_lines(self, x, y):
        cache = self._build_visual_cell_cache()
        normal_cache, custom_cache = cache
        rows = self.engine.ascii_grid(self.state_obj)
        entries = []

        for idx, (name, folder, symbol, color) in enumerate(LAYER_DEFS):
            if (x, y) in normal_cache.get(name, set()):
                layer_no = self.render_layer_for(name)
                extra = ""
                if name == "Elevation":
                    extra = f" | {self.elevation_height_at(x, y)} ft"
                entries.append((layer_no, idx, f"{layer_no:>3}  {symbol}  {name}{extra}"))

        base = len(LAYER_DEFS)
        for idx, custom in enumerate(self.state_obj.custom_layers):
            if (x, y) in custom_cache.get(custom.name, set()):
                layer_no = self.render_layer_for(CUSTOM_PREFIX + custom.name)
                entries.append((
                    layer_no, base+idx,
                    f"{layer_no:>3}  {custom.symbol}  {custom.name}"
                ))

        entries.sort(key=lambda item: (item[0], item[1]), reverse=True)
        lines = [e[2] for e in entries]

        if not lines:
            lines.append("  0  .  Open Ground")

        symbol = rows[y][x] if 0 <= y < len(rows) and 0 <= x < len(rows[y]) else "."
        return symbol, lines

    def _tile_lens_image(self, x, y, selected=None):
        """Crop a 5x5 neighborhood from the already-rendered live bitmap."""
        if self._live_map_pil is None:
            self._live_map_pil = self._render_live_bitmap()
        if self._live_map_pil is None:
            return None

        from PIL import Image, ImageDraw

        cs = self.cell_size
        lens_cs = 56
        radius = 2
        size = 5 * lens_cs

        # Start with a neutral frame so map edges still show a true 5x5 lens.
        out = Image.new("RGB", (size, size), "#202428")

        for ly in range(5):
            for lx in range(5):
                mx = x + (lx - radius)
                my = y + (ly - radius)
                dx0 = lx * lens_cs
                dy0 = ly * lens_cs

                if 0 <= mx < self.state_obj.width and 0 <= my < self.state_obj.height:
                    sx0, sy0 = mx*cs, my*cs
                    tile = self._live_map_pil.crop((sx0, sy0, sx0+cs, sy0+cs))
                    tile = tile.resize((lens_cs, lens_cs))
                    out.paste(tile, (dx0, dy0))

        dr = ImageDraw.Draw(out)
        for i in range(6):
            p = i * lens_cs
            dr.line((p, 0, p, size), fill="#555555", width=1)
            dr.line((0, p, size, p), fill="#555555", width=1)

        # Center tile marks the lens anchor. The currently inspected tile gets
        # the stronger double marker so the user can work inside the 5x5 lens.
        c0 = radius * lens_cs
        c1 = c0 + lens_cs - 1
        dr.rectangle((c0+2, c0+2, c1-2, c1-2), outline="#ffffff", width=2)

        if selected is None:
            selected = (x, y)
        sx, sy = selected
        lx = sx - x + radius
        ly = sy - y + radius
        if 0 <= lx < 5 and 0 <= ly < 5:
            x0 = lx * lens_cs
            y0 = ly * lens_cs
            x1 = x0 + lens_cs - 1
            y1 = y0 + lens_cs - 1
            dr.rectangle((x0+2, y0+2, x1-2, y1-2), outline="#ffffff", width=4)
            dr.rectangle((x0+7, y0+7, x1-7, y1-7), outline="#111111", width=2)
        return out

    def _cell_slot_key(self, x, y):
        return f"{col_label(x)}{y+1}"

    def _cell_slot_record(self, x, y):
        key = self._cell_slot_key(x, y)
        rec = dict(CELL_SLOT_DEFAULTS)
        saved = self.state_obj.cell_slots.get(key, {})
        if isinstance(saved, dict):
            saved = dict(saved)

            # Migrate the earlier prototype names when reading old test maps.
            if "obstruction" in saved and "structure" not in saved:
                old_value = saved.get("obstruction", "None")
                saved["structure"] = "Wall / Solid Structure" if old_value not in ("None", "", None) else "None"
            if "trap_state" in saved and "trap" not in saved:
                old_trap = str(saved.get("trap_state", "None"))
                saved["trap"] = "Used" if old_trap == "Used" else ("Active" if old_trap != "None" else "None")

            leftovers = []
            for old_key in ("misc_1", "misc_2", "special_1", "special_2"):
                val = saved.get(old_key)
                if val and val != "None":
                    leftovers.append(val)
            for i, val in enumerate(leftovers[:4], start=1):
                saved.setdefault(f"scenario_{i}", val)

            rec.update(saved)

        # Legacy generated/manual layers remain the source for existing physical
        # Universals. If this cell has no explicit inspector choice, show what is
        # already on the map instead of pretending the square is empty.
        explicit = self.state_obj.cell_slots.get(key, {}) if isinstance(self.state_obj.cell_slots.get(key, {}), dict) else {}
        if "terrain_effect" not in explicit:
            terrain_hits = []
            if (x, y) in self.engine.cells_for_layer(self.state_obj, "Rough Terrain"):
                terrain_hits.append("Rough Terrain")
            if (x, y) in self.engine.cells_for_layer(self.state_obj, "Unstable Ground"):
                terrain_hits.append("Unstable Ground")
            if (x, y) in self.engine.cells_for_layer(self.state_obj, "Hazards"):
                terrain_hits.append("Hazardous Terrain")
            if len(terrain_hits) == 1:
                rec["terrain_effect"] = terrain_hits[0]
            elif len(terrain_hits) > 1:
                rec["terrain_effect"] = "Review: " + " + ".join(terrain_hits)

        if "liquid" not in explicit and (x, y) in self.engine.cells_for_layer(self.state_obj, "Liquid Areas"):
            rec["liquid"] = "Water"
        if "structure" not in explicit and (x, y) in self.engine.cells_for_layer(self.state_obj, "Full Obstructions"):
            rec["structure"] = "Wall / Solid Structure"
        if "cover" not in explicit and (x, y) in self.engine.cells_for_layer(self.state_obj, "Half Obstructions"):
            rec["cover"] = "Half Cover"

        if "height_ft" not in explicit:
            key2 = self._elevation_key(x, y)
            if (x, y) in self.engine.cells_for_layer(self.state_obj, "Elevation"):
                rec["height_ft"] = int(self.state_obj.elevation_heights.get(key2, DEFAULT_ELEVATION_HEIGHT_FT))
        return rec

    def _ensure_layer_at(self, layer_name, x, y, present):
        if present:
            self.engine.paint_layer_cell(self.state_obj, layer_name, x, y)
        else:
            self.engine.erase_layer_cell(self.state_obj, layer_name, x, y)

    def _invalidate_cell_slot_for_layer(self, x, y, layer_name):
        mapping = {
            "Rough Terrain": "terrain_effect",
            "Unstable Ground": "terrain_effect",
            "Hazards": "terrain_effect",
            "Liquid Areas": "liquid",
            "Full Obstructions": "structure",
            "Half Obstructions": "cover",
            "Elevation": "height_ft",
        }
        slot = mapping.get(layer_name)
        if slot is None:
            return
        key = self._cell_slot_key(x, y)
        rec = dict(self.state_obj.cell_slots.get(key, {}))
        rec.pop(slot, None)
        if rec:
            self.state_obj.cell_slots[key] = rec
        else:
            self.state_obj.cell_slots.pop(key, None)

    def _write_cell_slot(self, x, y, slot, value):
        key = self._cell_slot_key(x, y)
        rec = dict(self.state_obj.cell_slots.get(key, {}))
        rec[slot] = value
        for old_key in ("obstruction", "trap_state", "misc_1", "misc_2", "special_1", "special_2"):
            rec.pop(old_key, None)
        self.state_obj.cell_slots[key] = rec

        # Bridge the fixed inspector into the existing authoritative Universal
        # layers wherever there is already a direct equivalent. This lets the
        # user handle the new schema without creating a second map underneath it.
        if slot == "terrain_effect":
            for layer in ("Rough Terrain", "Unstable Ground", "Hazards"):
                self._ensure_layer_at(layer, x, y, False)
            mapping = {
                "Rough Terrain": "Rough Terrain",
                "Unstable Ground": "Unstable Ground",
                "Damaging Terrain": "Hazards",
            }
            if value in mapping:
                self._ensure_layer_at(mapping[value], x, y, True)
        elif slot == "liquid":
            self._ensure_layer_at("Liquid Areas", x, y, value != "None")
        elif slot == "structure":
            self._ensure_layer_at("Full Obstructions", x, y, value != "None")
        elif slot == "cover":
            self._ensure_layer_at("Half Obstructions", x, y, value == "Half Cover")

    def _choose_custom_value(self, slot, current):
        label = dict(CELL_SLOT_LABELS).get(slot, slot.replace("_", " ").title())
        answer = simpledialog.askstring("Custom Cell Value", f"Custom value for {label}:", parent=self.tile_lens_window)
        if answer is None or not answer.strip():
            return current
        return "Custom: " + answer.strip()

    def _on_cell_slot_changed(self, slot):
        if self.tile_lens_selected_cell is None:
            return
        if self.tile_lens_pinned_cell is None and self.tile_lens_display_anchor is not None:
            self.tile_lens_pinned_cell = self.tile_lens_display_anchor
            self.draw_tile_lens_focus()
        x, y = self.tile_lens_selected_cell
        var = self.tile_slot_vars[slot]
        value = var.get()
        if value == "Custom...":
            previous = self._cell_slot_record(x, y).get(slot, CELL_SLOT_DEFAULTS.get(slot, "None"))
            value = self._choose_custom_value(slot, previous)
            var.set(value)
        self._write_cell_slot(x, y, slot, value)
        self.status.set(f"{col_label(x)}{y+1}: {dict(CELL_SLOT_LABELS).get(slot, slot)} = {value}")
        self.refresh_all()
        self.show_tile_lens(self.tile_lens_pinned_cell[0], self.tile_lens_pinned_cell[1], pinned=True)

    def _apply_cell_height(self):
        if self.tile_lens_selected_cell is None:
            return
        if self.tile_lens_pinned_cell is None and self.tile_lens_display_anchor is not None:
            self.tile_lens_pinned_cell = self.tile_lens_display_anchor
            self.draw_tile_lens_focus()
        x, y = self.tile_lens_selected_cell
        try:
            feet = int(self.tile_height_var.get())
        except Exception:
            feet = 0
            self.tile_height_var.set(0)
        feet = max(-500, min(5000, feet))
        self.tile_height_var.set(feet)
        self._write_cell_slot(x, y, "height_ft", feet)
        if feet == 0:
            self._ensure_layer_at("Elevation", x, y, False)
            self.state_obj.elevation_heights.pop(self._elevation_key(x, y), None)
        else:
            self._ensure_layer_at("Elevation", x, y, True)
            self.state_obj.elevation_heights[self._elevation_key(x, y)] = feet
        self.refresh_all()
        self.show_tile_lens(self.tile_lens_pinned_cell[0], self.tile_lens_pinned_cell[1], pinned=True)

    def _on_direction_changed(self, event=None):
        if self.tile_lens_selected_cell is None:
            return
        if self.tile_lens_pinned_cell is None and self.tile_lens_display_anchor is not None:
            self.tile_lens_pinned_cell = self.tile_lens_display_anchor
            self.draw_tile_lens_focus()
        x, y = self.tile_lens_selected_cell
        value = self.tile_direction_var.get()
        if value == "Custom...":
            answer = simpledialog.askstring("Custom Direction", "Custom direction:", parent=self.tile_lens_window)
            if answer is None or not answer.strip():
                value = self._cell_slot_record(x, y).get("direction", "None")
            else:
                value = "Custom: " + answer.strip()
            self.tile_direction_var.set(value)
        self._write_cell_slot(x, y, "direction", value)
        self.status.set(f"{col_label(x)}{y+1}: Direction = {value}")

    def _apply_trap_radius(self):
        if self.tile_lens_selected_cell is None:
            return
        if self.tile_lens_pinned_cell is None and self.tile_lens_display_anchor is not None:
            self.tile_lens_pinned_cell = self.tile_lens_display_anchor
            self.draw_tile_lens_focus()
        x, y = self.tile_lens_selected_cell
        try:
            feet = int(self.tile_trap_radius_var.get())
        except Exception:
            feet = 0
        feet = max(0, min(5000, feet))
        self.tile_trap_radius_var.set(feet)
        self._write_cell_slot(x, y, "trap_radius_ft", feet)
        self.status.set(f"{col_label(x)}{y+1}: Trap Radius = {feet} ft")
        self.refresh_all()
        self.show_tile_lens(self.tile_lens_pinned_cell[0], self.tile_lens_pinned_cell[1], pinned=True)

    def _load_tile_inspector(self, x, y):
        self.tile_lens_selected_cell = (x, y)
        rec = self._cell_slot_record(x, y)
        self.tile_inspector_title.configure(text=f"EDIT CELL {col_label(x)}{y+1}")
        for slot, _label in CELL_SLOT_LABELS:
            value = str(rec.get(slot, CELL_SLOT_DEFAULTS.get(slot, "None")))
            combo = self.tile_slot_combos[slot]
            values = list(CELL_SLOT_CHOICES[slot])
            if value not in values:
                values.insert(0, value)
            combo.configure(values=values)
            self.tile_slot_vars[slot].set(value)
        self.tile_height_var.set(int(rec.get("height_ft", 0) or 0))
        self.tile_direction_var.set(str(rec.get("direction", "None")))
        self.tile_trap_radius_var.set(int(rec.get("trap_radius_ft", 0) or 0))

    def on_tile_lens_image_click(self, event):
        p = self._lens_cell_from_event(event)
        if p is None:
            return
        mx, my = p
        anchor = self.tile_lens_display_anchor

        # Any interaction with the enlarged lens locks the current 5x5 area.
        if self.tile_lens_pinned_cell is None:
            self.tile_lens_pinned_cell = anchor
            self.draw_tile_lens_focus()

        self.tile_lens_selected_cell = (mx, my)
        tool = self.canvas_tool_var.get() if hasattr(self, "canvas_tool_var") else "Cell Edit"

        if tool == "Guide Line":
            self.handle_guide_click(mx, my)
            self.show_tile_lens(anchor[0], anchor[1], pinned=True)
            return

        if tool == "Terrain Pen":
            self._paint_lens_cell(mx, my, erase=False)
            return

        if tool == "Copy Cell":
            if not self.cell_copy_waiting_for_target:
                self._capture_cell_for_copy(mx, my)
                self.cell_copy_waiting_for_target = True
                self.status.set(
                    f"Copied {col_label(mx)}{my+1}. Click destination cell."
                )
            else:
                self._paste_copied_cell(mx, my)
                self.cell_copy_waiting_for_target = False
            self.show_tile_lens(anchor[0], anchor[1], pinned=True)
            return

        # Cell Edit / Tile Lens: select the enlarged cell for dropdown editing.
        self.show_tile_lens(anchor[0], anchor[1], pinned=True)
        self.status.set(f"Tile Lens: inspecting {col_label(mx)}{my+1}")

    def show_tile_lens(self, x, y, pinned=False, screen_x=None, screen_y=None):
        if not (0 <= x < self.state_obj.width and 0 <= y < self.state_obj.height):
            return

        self._cancel_tile_lens_timer()
        if pinned:
            self.tile_lens_pinned_cell = (x, y)
        self.tile_lens_display_anchor = (x, y)
        if self.tile_lens_selected_cell is None or self.tile_lens_pinned_cell is None:
            self.tile_lens_selected_cell = (x, y)

        img = self._tile_lens_image(x, y, selected=self.tile_lens_selected_cell)
        if img is None:
            return

        from PIL import ImageTk

        # Reuse one popup instead of creating a trail of windows.
        if self.tile_lens_window is None or not self.tile_lens_window.winfo_exists():
            win = tk.Toplevel(self)
            self.tile_lens_window = win
            win.title("D12 Tile Lens")
            win.resizable(False, False)
            win.transient(self)

            body = ttk.Frame(win, padding=8)
            body.pack(fill=tk.BOTH, expand=True)
            body.columnconfigure(1, weight=1)

            left_panel = ttk.Frame(body)
            left_panel.grid(row=0, column=0, sticky="n")
            editor = ttk.Frame(body, padding=(12, 0, 0, 0))
            editor.grid(row=0, column=1, sticky="nsew")

            self.tile_lens_title = ttk.Label(
                left_panel, font=("TkDefaultFont", 10, "bold")
            )
            self.tile_lens_title.pack(anchor="w")

            self.tile_lens_image_label = ttk.Label(left_panel)
            self.tile_lens_image_label.pack(pady=(6, 6))
            self.tile_lens_image_label.bind("<Button-1>", self.on_tile_lens_image_click)
            self.tile_lens_image_label.bind("<Button-3>", self.on_tile_lens_image_right_click)

            ttk.Label(left_panel, text="Right-click main map to lock. Lens tools work directly on enlarged cells.").pack(anchor="w")

            self.tile_lens_stack = tk.Text(
                left_panel, width=38, height=9, wrap="none",
                font=("Consolas", 9)
            )
            self.tile_lens_stack.pack(fill=tk.BOTH, expand=True, pady=(6, 0))

            controls = ttk.Frame(left_panel)
            controls.pack(fill=tk.X, pady=(6, 0))
            self.tile_lens_pin_button = ttk.Button(
                controls, text="Pin", command=lambda: None
            )
            self.tile_lens_pin_button.pack(side=tk.LEFT)
            ttk.Button(
                controls, text="Close / Unpin", command=self.unpin_tile_lens
            ).pack(side=tk.RIGHT)

            self.tile_inspector_title = ttk.Label(editor, text="EDIT CELL", font=("TkDefaultFont", 10, "bold"))
            self.tile_inspector_title.grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))

            lens_tools = ttk.LabelFrame(editor, text="LENS TOOLS", padding=6)
            lens_tools.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(0, 8))
            lens_tools.columnconfigure(1, weight=1)
            lens_tools.columnconfigure(3, weight=1)

            ttk.Label(lens_tools, text="Tool").grid(row=0, column=0, sticky="w", padx=(0,4))
            self.tile_lens_tool_var = self.canvas_tool_var
            self.tile_lens_tool_combo = ttk.Combobox(
                lens_tools,
                textvariable=self.tile_lens_tool_var,
                values=["Cell Edit","Guide Line","Terrain Pen","Copy Cell"],
                state="readonly",
                width=14
            )
            self.tile_lens_tool_combo.grid(row=0, column=1, sticky="ew", padx=(0,8))
            self.tile_lens_tool_combo.bind("<<ComboboxSelected>>", lambda e: self.cancel_pending_guide())

            ttk.Label(lens_tools, text="Symbol / Layer").grid(row=0, column=2, sticky="w", padx=(0,4))
            self.tile_lens_layer_var = tk.StringVar(value=self._lens_layer_display_for_selected())
            self.tile_lens_layer_combo = ttk.Combobox(
                lens_tools,
                textvariable=self.tile_lens_layer_var,
                values=self._lens_layer_display_values(),
                state="readonly",
                width=24
            )
            self.tile_lens_layer_combo.grid(row=0, column=3, sticky="ew")
            self.tile_lens_layer_combo.bind("<<ComboboxSelected>>", self._on_lens_layer_selected)

            ttk.Label(lens_tools, text="Guide width").grid(row=1, column=0, sticky="w", pady=(5,0))
            ttk.Spinbox(lens_tools, from_=1, to=7, textvariable=self.guide_width_var, width=6).grid(row=1, column=1, sticky="w", pady=(5,0))
            ttk.Label(lens_tools, text="Pen width").grid(row=1, column=2, sticky="w", pady=(5,0))
            ttk.Spinbox(lens_tools, from_=1, to=7, textvariable=self.pen_width_var, width=6).grid(row=1, column=3, sticky="w", pady=(5,0))

            cell_copy_buttons = ttk.Frame(lens_tools)
            cell_copy_buttons.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(6,0))
            ttk.Button(cell_copy_buttons, text="Copy Selected Cell", command=self.copy_selected_lens_cell).pack(side=tk.LEFT)
            ttk.Button(cell_copy_buttons, text="Paste Into Selected Cell", command=self.paste_to_selected_lens_cell).pack(side=tk.LEFT, padx=(6,0))
            ttk.Label(cell_copy_buttons, text="  Terrain Pen: left paints, right erases").pack(side=tk.LEFT)

            self.tile_slot_vars = {}
            self.tile_slot_combos = {}
            for idx, (slot, label) in enumerate(CELL_SLOT_LABELS):
                rr = 2 + idx // 2
                cc = (idx % 2) * 2
                ttk.Label(editor, text=label).grid(row=rr, column=cc, sticky="w", padx=(0, 4), pady=2)
                var = tk.StringVar(value=CELL_SLOT_DEFAULTS.get(slot, "None"))
                combo = ttk.Combobox(editor, textvariable=var, values=CELL_SLOT_CHOICES[slot], state="readonly", width=20)
                combo.grid(row=rr, column=cc+1, sticky="ew", padx=(0, 8), pady=2)
                combo.bind("<<ComboboxSelected>>", lambda e, s=slot: self._on_cell_slot_changed(s))
                self.tile_slot_vars[slot] = var
                self.tile_slot_combos[slot] = combo

            base_row = 2 + (len(CELL_SLOT_LABELS)+1)//2
            ttk.Separator(editor).grid(row=base_row, column=0, columnspan=4, sticky="ew", pady=8)

            props = ttk.LabelFrame(editor, text="TILE PROPERTIES", padding=6)
            props.grid(row=base_row+1, column=0, columnspan=4, sticky="ew")
            props.columnconfigure(1, weight=1)

            ttk.Label(props, text="Height (ft)").grid(row=0, column=0, sticky="w")
            self.tile_height_var = tk.IntVar(value=0)
            ttk.Spinbox(props, from_=-500, to=5000, increment=5, textvariable=self.tile_height_var, width=9).grid(row=0, column=1, sticky="w")
            ttk.Button(props, text="Apply", command=self._apply_cell_height).grid(row=0, column=2, sticky="w", padx=(5, 12))

            ttk.Label(props, text="Trap Radius (ft)").grid(row=0, column=3, sticky="w")
            self.tile_trap_radius_var = tk.IntVar(value=0)
            ttk.Spinbox(props, from_=0, to=5000, increment=5, textvariable=self.tile_trap_radius_var, width=9).grid(row=0, column=4, sticky="w", padx=(4,0))
            ttk.Button(props, text="Apply", command=self._apply_trap_radius).grid(row=0, column=5, sticky="w", padx=(5,0))

            ttk.Label(props, text="Direction").grid(row=1, column=0, sticky="nw", pady=(7,0))
            self.tile_direction_var = tk.StringVar(value="None")
            compass = ttk.Frame(props)
            compass.grid(row=1, column=1, columnspan=5, sticky="w", pady=(5,0))

            for glyph, value, rr, cc in [
                ("↖", "Northwest", 0, 0), ("↑", "North", 0, 1), ("↗", "Northeast", 0, 2),
                ("←", "West", 1, 0), ("•", "None", 1, 1), ("→", "East", 1, 2),
                ("↙", "Southwest", 2, 0), ("↓", "South", 2, 1), ("↘", "Southeast", 2, 2),
            ]:
                ttk.Button(
                    compass, text=glyph, width=3,
                    command=lambda v=value: (self.tile_direction_var.set(v), self._on_direction_changed())
                ).grid(row=rr, column=cc, padx=1, pady=1)

            ttk.Button(compass, text="Up", width=5,
                       command=lambda: (self.tile_direction_var.set("Up"), self._on_direction_changed())).grid(row=0, column=3, padx=(7,1), pady=1)
            ttk.Button(compass, text="Down", width=5,
                       command=lambda: (self.tile_direction_var.set("Down"), self._on_direction_changed())).grid(row=1, column=3, padx=(7,1), pady=1)
            ttk.Label(compass, textvariable=self.tile_direction_var, width=12).grid(row=2, column=3, padx=(7,1), pady=1)

            ttk.Label(
                editor,
                text="Map Type and Mood are visual-only. These cell slots are the mechanical map.",
                wraplength=420,
                justify="left"
            ).grid(row=base_row+2, column=0, columnspan=4, sticky="w", pady=(10,0))
            editor.columnconfigure(1, weight=1)
            editor.columnconfigure(3, weight=1)

            win.protocol("WM_DELETE_WINDOW", self.unpin_tile_lens)
        else:
            win = self.tile_lens_window

        self.tile_lens_photo = ImageTk.PhotoImage(img)
        self.tile_lens_image_label.configure(image=self.tile_lens_photo)
        self._sync_lens_tool_controls()

        sx, sy = self.tile_lens_selected_cell if self.tile_lens_selected_cell is not None else (x, y)
        self._load_tile_inspector(sx, sy)
        symbol, stack_lines = self._tile_stack_lines(sx, sy)
        coord = f"{col_label(sx)}{sy+1}"
        mode = "PINNED" if self.tile_lens_pinned_cell is not None else "HOVER"
        self.tile_lens_title.configure(
            text=f"{coord}  |  {mode}  |  selected symbol: {symbol}"
        )

        text = "TOP -> BOTTOM\n" + "\n".join(stack_lines)
        self.tile_lens_stack.configure(state="normal")
        self.tile_lens_stack.delete("1.0", tk.END)
        self.tile_lens_stack.insert("1.0", text)
        self.tile_lens_stack.configure(state="disabled")

        if self.tile_lens_pinned_cell is None:
            self.tile_lens_pin_button.configure(
                text="Pin This Tile",
                command=lambda xx=x, yy=y: self.pin_tile_lens(xx, yy)
            )
        else:
            self.tile_lens_pin_button.configure(
                text="Pinned",
                command=lambda: None
            )

        if screen_x is not None and screen_y is not None and not pinned:
            win.geometry(f"+{screen_x+18}+{screen_y+18}")
        elif pinned:
            # Keep the pinned lens near the app rather than covering the source tile.
            self.update_idletasks()
            win.geometry(f"+{self.winfo_rootx()+self.winfo_width()-430}+{self.winfo_rooty()+70}")

        win.deiconify()
        try:
            win.lift()
        except Exception:
            pass

    def canvas_cell(self,event):
        x=int(self.canvas.canvasx(event.x)//self.cell_size)
        y=int(self.canvas.canvasy(event.y)//self.cell_size)
        if 0<=x<self.state_obj.width and 0<=y<self.state_obj.height:
            return x,y
        return None

    def on_canvas_left(self,event):
        p=self.canvas_cell(event)
        if not p:
            return
        x,y=p

        tool = self.canvas_tool_var.get() if hasattr(self, "canvas_tool_var") else "Cell Edit"
        if tool == "Tile Lens":
            self.pin_tile_lens(x, y)
            return
        if tool == "Guide Line":
            self.handle_guide_click(x,y)
            return
        if tool == "Terrain Pen":
            self.begin_pen_stroke(x, y, erase=False)
            return
        if tool == "Copy Cell":
            if not self.cell_copy_waiting_for_target:
                self._capture_cell_for_copy(x, y)
                self.cell_copy_waiting_for_target = True
                self.status.set(
                    f"Copied {col_label(x)}{y+1}. Click destination cell."
                )
            else:
                self._paste_copied_cell(x, y)
                self.cell_copy_waiting_for_target = False
            return

        sel=self.selected_layer.get()
        if sel.startswith(CUSTOM_PREFIX):
            name=sel[len(CUSTOM_PREFIX):]
            pts={tuple(v) for v in self.state_obj.custom_cells.get(name,[])}
            if (x,y) in pts: pts.remove((x,y))
            else: pts.add((x,y))
            self.state_obj.custom_cells[name]=[[a,b] for a,b in sorted(pts)]
        else:
            before_present = (x, y) in self.engine.cells_for_layer(self.state_obj, sel)
            self.engine.toggle_layer_cell(self.state_obj,sel,x,y)
            after_present = (x, y) in self.engine.cells_for_layer(self.state_obj, sel)
            if sel == "Elevation":
                key = self._elevation_key(x, y)
                if after_present:
                    self.state_obj.elevation_heights[key] = self._current_elevation_stamp_height()
                else:
                    self.state_obj.elevation_heights.pop(key, None)
        self._invalidate_cell_slot_for_layer(x, y, sel)
        self.status.set(f"Edited {col_label(x)}{y+1}: {sel}")
        self.refresh_all()

    def cancel_pending_guide(self):
        self.pending_guide_start = None
        self.cell_copy_waiting_for_target = False
        if hasattr(self, "pen_active"):
            self.pen_active = False
            self.pen_erase = False
            self.pen_seen_cells = set()
        if hasattr(self, "canvas"):
            self.canvas.delete("pen_preview")
        if hasattr(self, "canvas_tool_var"):
            self.status.set(f"Tool: {self.canvas_tool_var.get()}")

    def handle_guide_click(self, x, y):
        sel = self.selected_layer.get()

        if sel.startswith(CUSTOM_PREFIX) or sel not in self.renderer.natural_layers():
            messagebox.showinfo(
                "Guide Line",
                "Choose a supported terrain layer first:\n"
                "Rough Terrain, Unstable Ground, Half Obstructions, Full Obstructions, "
                "Hazards, Vegetation, Elevation, or Liquid Areas."
            )
            self.pending_guide_start = None
            return

        if self.pending_guide_start is None:
            self.pending_guide_start = [x,y]
            self.status.set(
                f"Guide start {col_label(x)}{y+1} for {sel}. Click the end point."
            )
            self.draw_canvas()
            cs=self.cell_size
            cx,cy=x*cs+cs/2,y*cs+cs/2
            self.canvas.create_oval(
                cx-4,cy-4,cx+4,cy+4,
                fill="#ffffff",outline="#111111",width=2
            )
            return

        try:
            width = max(1, min(7, int(self.guide_width_var.get())))
        except Exception:
            width = 1

        start = list(self.pending_guide_start)
        self.state_obj.visual_guides.append({
            "layer": sel,
            "start": start,
            "end": [x,y],
            "width": width
        })
        self.pending_guide_start = None
        self.status.set(
            f"Guide added: {sel} {col_label(start[0])}{start[1]+1} -> "
            f"{col_label(x)}{y+1}, width {width}"
        )
        self.refresh_all()

    def undo_last_guide(self):
        self.pending_guide_start = None
        if not self.state_obj.visual_guides:
            self.status.set("No guide lines to undo")
            return
        self.state_obj.visual_guides.pop()
        self.refresh_all()
        self.status.set("Removed last visual guide line")

    def clear_guides(self):
        self.pending_guide_start = None
        if not self.state_obj.visual_guides:
            self.status.set("No guide lines to clear")
            return
        if not messagebox.askyesno("Clear Guides","Clear all visual guide lines?"):
            return
        self.state_obj.visual_guides = []
        self.refresh_all()
        self.status.set("Visual guide lines cleared")

    def lock_hover_tile_lens(self):
        """Lock the currently visible hover Tile Lens without editing/erasing a map cell."""
        if self.tile_lens_pinned_cell is not None:
            return False
        if self.tile_lens_display_anchor is None:
            return False
        if self.tile_lens_window is None:
            return False
        try:
            if not self.tile_lens_window.winfo_exists():
                return False
        except Exception:
            return False

        x, y = self.tile_lens_display_anchor
        self.pin_tile_lens(x, y)
        self.status.set(
            f"Tile Lens locked at {col_label(x)}{y+1}. "
            "Left-click enlarged cells to inspect/edit."
        )
        return True

    def on_canvas_right(self,event):
        # Phase 2C-5: when the hover Tile Lens is visible, right-click locks it
        # in place instead of erasing the underlying cell. Once pinned, the
        # normal right-click tool behavior is restored.
        if self.lock_hover_tile_lens():
            return

        tool = self.canvas_tool_var.get() if hasattr(self, "canvas_tool_var") else "Cell Edit"
        if tool == "Guide Line":
            self.pending_guide_start = None
            self.draw_canvas()
            self.status.set("Pending guide cancelled")
            return

        if tool == "Terrain Pen":
            p=self.canvas_cell(event)
            if p:
                self.begin_pen_stroke(p[0], p[1], erase=True)
            return
        if tool == "Copy Cell":
            self.cell_copy_waiting_for_target = False
            self.status.set("Copy Cell cancelled")
            return

        p=self.canvas_cell(event)
        if not p:return
        self.engine.erase_all_at(self.state_obj,*p)
        self.state_obj.elevation_heights.pop(self._elevation_key(p[0], p[1]), None)
        self.status.set(f"Cleared {col_label(p[0])}{p[1]+1}")
        self.refresh_all()

    def _terrain_pen_layer(self):
        sel = self.selected_layer.get()
        valid = {name for name, *_ in LAYER_DEFS}
        if sel.startswith(CUSTOM_PREFIX) or sel not in valid:
            return None
        return sel

    def _pen_width(self):
        try:
            return max(1, min(7, int(self.pen_width_var.get())))
        except Exception:
            return 1

    def _brush_cells(self, cx, cy, width):
        """
        Circular-ish grid brush. Width 1 is one cell.
        Larger widths remain centered on the mouse cell and are clipped to the map.
        """
        if width <= 1:
            candidates = {(cx, cy)}
        else:
            radius = (width - 1) / 2.0
            reach = int(math.ceil(radius))
            candidates = set()
            for oy in range(-reach, reach + 1):
                for ox in range(-reach, reach + 1):
                    # Small allowance keeps integer brushes visually continuous.
                    if math.hypot(ox, oy) <= radius + 0.35:
                        candidates.add((cx + ox, cy + oy))

        return {
            (x, y) for x, y in candidates
            if 0 <= x < self.state_obj.width and 0 <= y < self.state_obj.height
        }

    def begin_pen_stroke(self, x, y, erase=False):
        layer = self._terrain_pen_layer()
        if layer is None:
            messagebox.showinfo(
                "Terrain Pen",
                "Choose a normal terrain layer under Edit Layer first."
            )
            self.pen_active = False
            return

        self.pending_guide_start = None
        self.pen_active = True
        self.pen_erase = bool(erase)
        self.pen_seen_cells = set()
        self.apply_pen_at(x, y)

    def apply_pen_at(self, x, y):
        if not self.pen_active:
            return

        layer = self._terrain_pen_layer()
        if layer is None:
            return

        width = self._pen_width()
        cells = self._brush_cells(x, y, width)
        fresh = cells - self.pen_seen_cells
        if not fresh:
            return

        for px, py in fresh:
            if self.pen_erase:
                self.engine.erase_layer_cell(self.state_obj, layer, px, py)
                if layer == "Elevation":
                    self.state_obj.elevation_heights.pop(self._elevation_key(px, py), None)
            else:
                self.engine.paint_layer_cell(self.state_obj, layer, px, py)
                if layer == "Elevation":
                    self.state_obj.elevation_heights[
                        self._elevation_key(px, py)
                    ] = self._current_elevation_stamp_height()
            self._invalidate_cell_slot_for_layer(px, py, layer)

        self.pen_seen_cells.update(fresh)

        # Lightweight immediate visual feedback.
        # Full terrain/connectivity/textures redraw only when the stroke ends.
        layer_def = next((d for d in LAYER_DEFS if d[0] == layer), None)
        fallback = layer_def[3] if layer_def else "#777777"
        color = self.renderer.theme_color(self.state_obj, layer, fallback)
        cs = self.cell_size
        preview_color = "#2b2b2b" if self.pen_erase else color

        for px, py in fresh:
            x0, y0 = px*cs, py*cs
            self.canvas.create_rectangle(
                x0+2, y0+2, x0+cs-2, y0+cs-2,
                outline=preview_color,
                width=max(2, cs//8),
                tags=("pen_preview",)
            )

        action = "Erasing" if self.pen_erase else "Painting"
        height_note = ""
        if layer == "Elevation" and not self.pen_erase:
            height_note = f" | height {self._current_elevation_stamp_height()} ft"
        self.status.set(
            f"{action} {layer} | width {width}{height_note} | "
            f"{len(self.pen_seen_cells)} cell(s) in stroke"
        )

    def on_canvas_left_drag(self, event):
        if not self.pen_active or self.pen_erase:
            return
        tool = self.canvas_tool_var.get() if hasattr(self, "canvas_tool_var") else "Cell Edit"
        if tool != "Terrain Pen":
            return
        p = self.canvas_cell(event)
        if p:
            self.apply_pen_at(p[0], p[1])

    def on_canvas_right_drag(self, event):
        if not self.pen_active or not self.pen_erase:
            return
        tool = self.canvas_tool_var.get() if hasattr(self, "canvas_tool_var") else "Cell Edit"
        if tool != "Terrain Pen":
            return
        p = self.canvas_cell(event)
        if p:
            self.apply_pen_at(p[0], p[1])

    def on_canvas_pen_release(self, event):
        if not self.pen_active:
            return

        layer = self._terrain_pen_layer() or "terrain"
        changed = len(self.pen_seen_cells)
        action = "Erased" if self.pen_erase else "Painted"

        self.pen_active = False
        self.pen_erase = False
        self.pen_seen_cells = set()

        # One expensive rebuild per completed stroke instead of one per mouse move.
        self.refresh_all()
        self.status.set(f"{action} {changed} {layer} cell(s)")

    def reset_overrides(self):
        if not messagebox.askyesno("Reset Overrides","Clear all manual cell edits and custom marker placements?"):
            return
        for name,*_ in LAYER_DEFS:
            self.state_obj.overrides_add[name]=[]
            self.state_obj.overrides_remove[name]=[]
        for c in self.state_obj.custom_layers:
            self.state_obj.custom_cells[c.name]=[]
        self.state_obj.elevation_heights = {}
        self.refresh_all(); self.status.set("Overrides and elevation metadata reset")

    def add_custom_layer(self):
        name=simpledialog.askstring("Custom Marker","Marker name:",parent=self)
        if not name:return
        symbol=simpledialog.askstring("Custom Marker","Single-character symbol:",parent=self,initialvalue="§") or "§"
        symbol=symbol[0]
        color=colorchooser.askcolor(title="Marker color",parent=self)[1] or "#d9c55f"
        if any(x.name==name for x in self.state_obj.custom_layers):
            messagebox.showerror("Duplicate","A custom marker with that name already exists.")
            return
        self.state_obj.custom_layers.append(CustomLayer(name,symbol,color))
        self.state_obj.custom_cells[name]=[]
        self.state_obj.custom_render_layers[name]=CUSTOM_RENDER_LAYER_DEFAULT
        self.update_layer_combo()
        self.selected_layer.set(CUSTOM_PREFIX+name)
        self.sync_selected_layer_controls()

    def copy_map(self):
        self.pull_controls_to_state()
        txt=self.engine.export_text(self.state_obj)
        self.clipboard_clear(); self.clipboard_append(txt); self.update()
        self.status.set("Map copied to clipboard")

    def export_txt(self):
        self.pull_controls_to_state()
        p=filedialog.asksaveasfilename(defaultextension=".txt",filetypes=[("Text map","*.txt")],initialfile=f"{self.state_obj.name}.txt")
        if p:
            Path(p).write_text(self.engine.export_text(self.state_obj),encoding="utf-8")
            self.status.set(f"Exported {p}")

    def export_json(self):
        self.pull_controls_to_state()
        p=filedialog.asksaveasfilename(defaultextension=".json",filetypes=[("JSON map","*.json")],initialfile=f"{self.state_obj.name}.json")
        if p:
            data=self.state_obj.to_json_dict(); data["final_ascii"]=self.engine.ascii_grid(self.state_obj)
            Path(p).write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding="utf-8")
            self.status.set(f"Exported {p}")

    def _state_authority_fingerprint(self, state: MapState | None = None) -> str:
        """Hash only authoritative map state. Visual/export preferences are excluded."""
        if state is None:
            state = self.state_obj
        payload = {
            "name": state.name,
            "seed": state.seed,
            "width": state.width,
            "height": state.height,
            "terrain": state.terrain,
            "densities": state.densities,
            "base_layers": state.base_layers,
            "overrides_add": state.overrides_add,
            "overrides_remove": state.overrides_remove,
            "custom_layers": [asdict(x) for x in state.custom_layers],
            "custom_cells": state.custom_cells,
            "elevation_heights": state.elevation_heights,
            "cell_slots": state.cell_slots,
        }
        raw = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def run_phase1d_self_test(self):
        self.pull_controls_to_state()
        original = MapState.from_json_dict(self.state_obj.to_json_dict())
        report = []
        failures = []
        start_time = time.perf_counter()

        def check(name, condition, detail=""):
            status = "PASS" if condition else "FAIL"
            report.append(f"{status}: {name}" + (f" — {detail}" if detail else ""))
            if not condition:
                failures.append(name)

        try:
            # 1. Current map integrity baseline.
            base_fp = self._state_authority_fingerprint(original)
            base_ascii = self.engine.ascii_grid(original)
            check("Authoritative state fingerprint created", bool(base_fp))
            check("ASCII dimensions match state",
                  len(base_ascii) == original.height and
                  all(len(r) == original.width for r in base_ascii),
                  f"{original.width}×{original.height}")

            # 2. Same seed + same inputs must reproduce the same generated base map.
            regen_a = MapState.from_json_dict(original.to_json_dict())
            regen_b = MapState.from_json_dict(original.to_json_dict())
            # Clear edits so this specifically tests the seeded generator.
            for s in (regen_a, regen_b):
                s.overrides_add = {k: [] for k in s.overrides_add}
                s.overrides_remove = {k: [] for k in s.overrides_remove}
                s.custom_cells = {}
                self.engine.generate(s)
            same_seed_same = (
                regen_a.base_layers == regen_b.base_layers and
                self.engine.ascii_grid(regen_a) == self.engine.ascii_grid(regen_b)
            )
            check("Same seed + same inputs are deterministic", same_seed_same)

            # 3. Different seed should normally alter placement.
            regen_c = MapState.from_json_dict(original.to_json_dict())
            regen_c.seed = original.seed + "-DIFFERENT"
            regen_c.overrides_add = {k: [] for k in regen_c.overrides_add}
            regen_c.overrides_remove = {k: [] for k in regen_c.overrides_remove}
            regen_c.custom_cells = {}
            self.engine.generate(regen_c)
            different_seed = regen_c.base_layers != regen_a.base_layers
            check("Different seed changes generated placement", different_seed)

            # 4. Visual themes must not alter authoritative state.
            visual_test = MapState.from_json_dict(original.to_json_dict())
            visual_before = self._state_authority_fingerprint(visual_test)
            for theme in THEMES:
                visual_test.visual_theme = theme
                visual_test.textured_tiles = not visual_test.textured_tiles
                visual_test.smart_connectivity = not visual_test.smart_connectivity
                visual_test.shape_style = "Natural" if visual_test.shape_style != "Natural" else "Connected"
                visual_test.edge_strength = "High" if visual_test.edge_strength != "High" else "Low"
                visual_test.visual_guides = [{
                    "layer":"Rough Terrain",
                    "start":[0,0],
                    "end":[max(0, visual_test.width-1), max(0, visual_test.height-1)],
                    "width":3
                }]
                rows = self.engine.ascii_grid(visual_test)
                # exercise art inference without writing data
                for y in range(min(visual_test.height, 20)):
                    for x in range(min(visual_test.width, 20)):
                        self.renderer.inferred_gap_symbol(rows, x, y)
            visual_after = self._state_authority_fingerprint(visual_test)
            check("Themes/connectivity/textures do not alter map data",
                  visual_before == visual_after)

            # 5. Export preferences must not alter authoritative state.
            export_test = MapState.from_json_dict(original.to_json_dict())
            export_before = self._state_authority_fingerprint(export_test)
            export_test.export_show_grid = not export_test.export_show_grid
            export_test.export_show_symbols = not export_test.export_show_symbols
            export_test.export_show_legend = not export_test.export_show_legend
            export_test.export_scale = 6 if export_test.export_scale != 6 else 1
            export_after = self._state_authority_fingerprint(export_test)
            check("Export preferences do not alter map data",
                  export_before == export_after)

            # 6. Save/load round-trip must preserve authoritative state.
            roundtrip = MapState.from_json_dict(original.to_json_dict())
            check("Save/load model round-trip preserves authority",
                  self._state_authority_fingerprint(roundtrip) == base_fp)

            # 7. Overrides survive a round-trip.
            override_test = MapState.from_json_dict(original.to_json_dict())
            layer_name = LAYER_DEFS[0][0]
            probe = [0, 0]
            if probe not in override_test.overrides_add[layer_name]:
                override_test.overrides_add[layer_name].append(probe)
            override_rt = MapState.from_json_dict(override_test.to_json_dict())
            check("Manual overrides survive save/load model",
                  probe in override_rt.overrides_add[layer_name])

            # 8. Reset overrides removes only overrides, not generated base data.
            reset_test = MapState.from_json_dict(override_rt.to_json_dict())
            base_snapshot = json.dumps(reset_test.base_layers, sort_keys=True)
            reset_test.overrides_add = {k: [] for k in reset_test.overrides_add}
            reset_test.overrides_remove = {k: [] for k in reset_test.overrides_remove}
            reset_test.custom_cells = {}
            check("Reset Overrides leaves generated base layers intact",
                  json.dumps(reset_test.base_layers, sort_keys=True) == base_snapshot)
            check("Reset Overrides clears override additions",
                  all(not v for v in reset_test.overrides_add.values()))
            check("Reset Overrides clears override removals",
                  all(not v for v in reset_test.overrides_remove.values()))

            # 9. Copy/TXT source must be the exact authoritative ASCII grid.
            ascii_text = "\n".join(base_ascii)
            check("Authoritative ASCII text is rectangular",
                  len(ascii_text.splitlines()) == original.height and
                  all(len(row) == original.width for row in ascii_text.splitlines()))

            # 10. Basic scale/performance sanity.
            cell_count = original.width * original.height
            elapsed = time.perf_counter() - start_time
            check("Regression suite completed", True,
                  f"{cell_count:,} cells checked in {elapsed:.2f}s")

        except Exception as exc:
            failures.append("Self-test crashed")
            report.append(f"FAIL: Self-test crashed — {type(exc).__name__}: {exc}")

        finally:
            # Absolutely restore the user's live map.
            self.state_obj = original
            self.sync_controls_from_state()
            self.draw_canvas()
            self.rebuild_legend()

        result = "PHASE 1D SELF-TEST\n\n" + "\n".join(report)
        result += "\n\n"
        if failures:
            result += f"RESULT: {len(failures)} FAILURE(S)\n" + "\n".join(f"- {x}" for x in failures)
        else:
            result += "RESULT: ALL AUTOMATED REGRESSION CHECKS PASSED"

        # Save an easy-to-share report beside the user's selected location if requested.
        win = tk.Toplevel(self)
        win.title("Phase 1D Self-Test")
        win.geometry("760x560")
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        box = tk.Text(frame, wrap="word", font=("Consolas", 10))
        box.pack(fill=tk.BOTH, expand=True)
        box.insert("1.0", result)
        box.configure(state="disabled")

        buttons = ttk.Frame(frame)
        buttons.pack(fill=tk.X, pady=(8,0))

        def save_report():
            path = filedialog.asksaveasfilename(
                defaultextension=".txt",
                filetypes=[("Text file","*.txt")],
                initialfile="D12_Mapworks_Phase1D_Self_Test.txt"
            )
            if path:
                Path(path).write_text(result, encoding="utf-8")
                self.status.set(f"Saved regression report {path}")

        ttk.Button(buttons, text="Save Report", command=save_report).pack(side=tk.LEFT)
        ttk.Button(buttons, text="Close", command=win.destroy).pack(side=tk.RIGHT)

        if failures:
            self.status.set(f"Phase 1D self-test: {len(failures)} failure(s)")
        else:
            self.status.set("Phase 1D self-test: PASS")

    def open_export_setup(self):
        win = tk.Toplevel(self)
        win.title("Print / Export Setup")
        win.transient(self)
        win.grab_set()

        body = ttk.Frame(win, padding=12)
        body.pack(fill=tk.BOTH, expand=True)

        grid_var = tk.BooleanVar(value=self.state_obj.export_show_grid)
        symbols_var = tk.BooleanVar(value=self.state_obj.export_show_symbols)
        legend_var = tk.BooleanVar(value=self.state_obj.export_show_legend)
        scale_var = tk.IntVar(value=max(1, min(6, int(self.state_obj.export_scale or 2))))
        paper_var = tk.StringVar(value="Letter - Landscape")

        ttk.Label(body, text="Visual export options", font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
        ttk.Checkbutton(body, text="Show grid lines", variable=grid_var).pack(anchor="w", pady=(8,0))
        ttk.Checkbutton(body, text="Show ASCII symbols", variable=symbols_var).pack(anchor="w")
        ttk.Checkbutton(body, text="Include legend", variable=legend_var).pack(anchor="w")

        scale_row = ttk.Frame(body)
        scale_row.pack(fill=tk.X, pady=(10,0))
        ttk.Label(scale_row, text="PNG scale").pack(side=tk.LEFT)
        ttk.Combobox(scale_row, textvariable=scale_var, values=[1,2,3,4,5,6],
                     width=5, state="readonly").pack(side=tk.LEFT, padx=8)
        ttk.Label(scale_row, text="1x = screen size; 2x+ = higher resolution").pack(side=tk.LEFT)

        paper_row = ttk.Frame(body)
        paper_row.pack(fill=tk.X, pady=(10,0))
        ttk.Label(paper_row, text="Print paper").pack(side=tk.LEFT)
        ttk.Combobox(paper_row, textvariable=paper_var,
                     values=["Letter - Landscape","Letter - Portrait","A4 - Landscape","A4 - Portrait"],
                     width=20, state="readonly").pack(side=tk.LEFT, padx=8)

        estimate = ttk.Label(body, text="", justify="left")
        estimate.pack(anchor="w", pady=(12,8))

        def refresh_estimate(*_):
            scale = max(1, int(scale_var.get()))
            cell_px = 24 * scale
            px_w = self.state_obj.width * cell_px
            px_h = self.state_obj.height * cell_px
            estimate.config(text=(
                f"Map: {self.state_obj.width} × {self.state_obj.height} cells\n"
                f"PNG: {px_w} × {px_h} pixels\n"
                f"At 300 DPI: about {px_w/300:.1f} × {px_h/300:.1f} inches before fit-to-page scaling."
            ))

        scale_var.trace_add("write", refresh_estimate)
        refresh_estimate()

        def apply_settings():
            self.state_obj.export_show_grid = bool(grid_var.get())
            self.state_obj.export_show_symbols = bool(symbols_var.get())
            self.state_obj.export_show_legend = bool(legend_var.get())
            self.state_obj.export_scale = int(scale_var.get())
            self.status.set("Print/export settings updated")

        def export_png_now():
            apply_settings()
            win.destroy()
            self.export_png_dialog()

        def print_page_now():
            apply_settings()
            choice = paper_var.get()
            win.destroy()
            self.export_visual_print_page(choice)

        buttons = ttk.Frame(body)
        buttons.pack(fill=tk.X, pady=(8,0))
        ttk.Button(buttons, text="Export PNG", command=export_png_now).pack(side=tk.LEFT, padx=(0,6))
        ttk.Button(buttons, text="Create Print Page", command=print_page_now).pack(side=tk.LEFT, padx=(0,6))
        ttk.Button(buttons, text="Apply", command=apply_settings).pack(side=tk.LEFT)
        ttk.Button(buttons, text="Close", command=win.destroy).pack(side=tk.RIGHT)

    def render_visual_png(self, target: Path, scale: int | None = None,
                          show_grid: bool | None = None,
                          show_symbols: bool | None = None,
                          include_legend: bool | None = None):
        try:
            from PIL import Image, ImageDraw, ImageFont
        except Exception:
            return False

        if scale is None:
            scale = self.state_obj.export_scale
        if show_grid is None:
            show_grid = self.state_obj.export_show_grid
        if show_symbols is None:
            show_symbols = self.state_obj.export_show_symbols
        if include_legend is None:
            include_legend = self.state_obj.export_show_legend

        scale = max(1, min(8, int(scale)))
        cs = 24 * scale
        rows = self.engine.ascii_grid(self.state_obj)
        visual_cache = self._build_visual_cell_cache()
        normal_cache, _ = visual_cache

        used_names = []
        if include_legend:
            for y in range(self.state_obj.height):
                for x in range(self.state_obj.width):
                    (name, symbol, color), hits = self.layer_visual(x, y, cache=visual_cache)
                    if name not in used_names:
                        used_names.append(name)

        legend_w = 340 * scale if include_legend else 0
        legend_h = (len(used_names) + 3) * 34 * scale if include_legend else 0
        map_w = self.state_obj.width * cs
        map_h = self.state_obj.height * cs
        img = Image.new("RGB", (map_w + legend_w, max(map_h, legend_h)), "white")
        dr = ImageDraw.Draw(img)

        for y in range(self.state_obj.height):
            for x in range(self.state_obj.width):
                (name, symbol, color), hits = self.layer_visual(x, y, cache=visual_cache)
                x0, y0 = x * cs, y * cs
                if name in self.renderer.natural_layers():
                    self.renderer.draw_region_cell_pillow(
                        dr, self.state_obj, name, x, y, x0, y0, cs, color, show_grid=show_grid,
                        cells=normal_cache.get(name)
                    )
                else:
                    outline = "#777777" if show_grid else color
                    dr.rectangle((x0, y0, x0 + cs - 1, y0 + cs - 1),
                                 fill=color, outline=outline)
                self.renderer.draw_skin_pillow(
                    dr, self.state_obj, name, x, y, x0, y0, cs, color
                )

        # Smart-connect art remains display-only.
        if self.state_obj.smart_connectivity:
            for y in range(self.state_obj.height):
                for x in range(self.state_obj.width):
                    symbol = rows[y][x]
                    x0, y0 = x * cs, y * cs
                    cx, cy = x0 + cs/2, y0 + cs/2

                    if symbol in ART_CONNECTIVE_SYMBOLS:
                        card, diag = self.renderer.same_symbol_neighbors(rows, x, y, symbol)
                        name = self.renderer.connector_name_for_symbol(symbol)
                        color = self.renderer.theme_color(self.state_obj, name, "#777777")
                        width = max(2, cs // 4)
                        for dx, dy in card:
                            dr.line((cx, cy, cx + dx*cs/2, cy + dy*cs/2),
                                    fill=color, width=width)
                        for dx, dy in diag:
                            dr.line((cx, cy, cx + dx*cs/2, cy + dy*cs/2),
                                    fill=color, width=max(1, width//2))
                    elif symbol == ".":
                        inferred = self.renderer.inferred_gap_symbol(rows, x, y)
                        if inferred:
                            name = self.renderer.connector_name_for_symbol(inferred)
                            color = self.renderer.theme_color(self.state_obj, name, "#777777")
                            ground = self.renderer.theme_color(self.state_obj, "Open Ground", "#d6cfb7")
                            soft = blend_hex(ground, color, 0.28)
                            pad = max(3, cs//4)
                            dr.ellipse((x0+pad, y0+pad, x0+cs-pad, y0+cs-pad), fill=soft)

        # Phase 2B directional guides.
        self.renderer.draw_guides_pillow(dr, self.state_obj, cs)

        if show_symbols:
            try:
                font = ImageFont.truetype("consola.ttf", max(11, cs//2))
            except Exception:
                font = None
            for y, row in enumerate(rows):
                for x, symbol in enumerate(row):
                    if symbol != ".":
                        dr.text((x*cs + cs*.25, y*cs + cs*.10),
                                symbol, fill="black", font=font)

        if include_legend:
            lx = map_w + 20 * scale
            yy = 18 * scale
            try:
                hfont = ImageFont.truetype("arialbd.ttf", 16*scale)
                lfont = ImageFont.truetype("arial.ttf", 12*scale)
            except Exception:
                hfont = None
                lfont = None

            dr.text((lx, yy), "D12 Mapworks Legend", fill="black", font=hfont)
            yy += 30 * scale

            for name in used_names:
                layer = next((d for d in LAYER_DEFS if d[0] == name), None)
                if layer:
                    _, _, symbol, fallback = layer
                else:
                    symbol, fallback = ".", "#d6cfb7"
                color = self.renderer.theme_color(self.state_obj, name, fallback)
                label = self.renderer.skin_label(self.state_obj, name)
                box = 20 * scale
                dr.rectangle((lx, yy, lx+box, yy+box), fill=color, outline="#555555")
                dr.text((lx+box+8*scale, yy), f"{symbol} {name}", fill="black", font=lfont)
                dr.text((lx+box+8*scale, yy+15*scale), label, fill="#444444", font=lfont)
                yy += 34 * scale

        img.save(target)
        return True

    def export_visual_print_page(self, paper_choice="Letter - Landscape"):
        self.pull_controls_to_state()
        target = filedialog.asksaveasfilename(
            defaultextension=".html",
            filetypes=[("Printable HTML", "*.html")],
            initialfile=f"{self.state_obj.name}_{self.state_obj.visual_theme}_visual_print.html"
        )
        if not target:
            return

        target = Path(target)
        png_target = target.with_name(target.stem + "_map.png")

        ok = self.render_visual_png(
            png_target,
            scale=max(2, int(self.state_obj.export_scale)),
            show_grid=self.state_obj.export_show_grid,
            show_symbols=self.state_obj.export_show_symbols,
            include_legend=False
        )
        if not ok:
            messagebox.showerror("Print Export", "Pillow is required for visual print export.")
            return

        paper = "A4" if paper_choice.startswith("A4") else "letter"
        orientation = "landscape" if "Landscape" in paper_choice else "portrait"

        legend_html = ""
        if self.state_obj.export_show_legend:
            seen = set()
            rows_html = []
            for y in range(self.state_obj.height):
                for x in range(self.state_obj.width):
                    (name, symbol, color), hits = self.layer_visual(x, y, cache=visual_cache)
                    if name in seen:
                        continue
                    seen.add(name)
                    rows_html.append(
                        f"<tr><td>{symbol}</td><td>{name}</td>"
                        f"<td>{self.renderer.skin_label(self.state_obj, name)}</td></tr>"
                    )
            legend_html = (
                "<h2>Legend</h2><table>"
                "<tr><th>Symbol</th><th>Universal</th><th>Theme appearance</th></tr>"
                + "".join(rows_html) + "</table>"
            )

        html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>{self.state_obj.name} - D12 Mapworks</title>
<style>
@page {{ size: {paper} {orientation}; margin: 0.35in; }}
body {{ font-family: Arial, sans-serif; margin:0; color:#111; }}
h1 {{ margin:0 0 4px 0; font-size:18pt; }}
.meta {{ font-size:9pt; margin-bottom:8px; }}
.mapwrap {{ width:100%; text-align:center; page-break-inside:avoid; }}
.mapwrap img {{ max-width:100%; max-height:7.1in; object-fit:contain; }}
table {{ border-collapse:collapse; font-size:8pt; width:100%; margin-top:6px; }}
td,th {{ border:1px solid #999; padding:3px 5px; text-align:left; }}
.note {{ font-size:8pt; margin-top:5px; }}
@media print {{ .screenonly {{ display:none; }} }}
</style>
</head>
<body>
<button class="screenonly" onclick="window.print()">Print</button>
<h1>{self.state_obj.name}</h1>
<div class="meta">
Seed: {self.state_obj.seed} &nbsp; | &nbsp;
Size: {self.state_obj.width}×{self.state_obj.height} &nbsp; | &nbsp;
Terrain: {self.state_obj.terrain} &nbsp; | &nbsp;
Theme: {self.state_obj.visual_theme}
</div>
<div class="mapwrap"><img src="{png_target.name}" alt="D12 Map"></div>
{legend_html}
<div class="note">
Visual export only. Authoritative map data remains the saved D12/JSON/ASCII source.
</div>
</body>
</html>"""

        target.write_text(html, encoding="utf-8")
        self.status.set(f"Created visual print page {target}")
        messagebox.showinfo(
            "Print Page Created",
            f"Created:\n{target}\n\nand\n{png_target}\n\n"
            "Open the HTML in your browser, then use Print Preview."
        )

    def export_png_dialog(self):
        self.pull_controls_to_state()
        target = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG image", "*.png")],
            initialfile=f"{self.state_obj.name}_{self.state_obj.visual_theme}_{self.state_obj.export_scale}x.png"
        )
        if not target:
            return
        ok = self.render_visual_png(
            Path(target),
            scale=self.state_obj.export_scale,
            show_grid=self.state_obj.export_show_grid,
            show_symbols=self.state_obj.export_show_symbols,
            include_legend=self.state_obj.export_show_legend
        )
        if ok:
            self.status.set(f"Exported visual PNG {target}")
        else:
            messagebox.showerror("PNG Export", "Pillow is required for PNG export.")

    def export_html(self, target: str|None=None):
        self.pull_controls_to_state()
        if target is None:
            target=filedialog.asksaveasfilename(defaultextension=".html",filetypes=[("HTML","*.html")],initialfile=f"{self.state_obj.name}_print.html")
        if not target:return
        rows=self.engine.ascii_grid(self.state_obj)
        legend="".join(f"<li><b>{symbol}</b> — {name}</li>" for name,folder,symbol,color in LAYER_DEFS)
        legend += "".join(f"<li><b>{c.symbol}</b> — {c.name}</li>" for c in self.state_obj.custom_layers)
        html=f'''<!doctype html><meta charset="utf-8"><title>{self.state_obj.name}</title>
<style>body{{font-family:Arial,sans-serif;margin:24px}}pre{{font:16px/1 Consolas,monospace;white-space:pre}}@media print{{button{{display:none}}}}</style>
<h1>{self.state_obj.name}</h1><p><b>Seed:</b> {self.state_obj.seed} &nbsp; <b>Size:</b> {self.state_obj.width}×{self.state_obj.height} &nbsp; <b>Terrain:</b> {self.state_obj.terrain} &nbsp; <b>Visual Theme:</b> {self.state_obj.visual_theme}</p>
<button onclick="window.print()">Print</button><pre>{os.linesep.join(rows)}</pre><h2>Legend</h2><ul>{legend}</ul><h2>Creator Notes</h2><pre>{self.state_obj.notes}</pre>'''
        Path(target).write_text(html,encoding="utf-8")
        self.status.set(f"Exported print view {target}")

    def export_png(self, target: Path):
        return self.render_visual_png(
            target,
            scale=self.state_obj.export_scale,
            show_grid=self.state_obj.export_show_grid,
            show_symbols=self.state_obj.export_show_symbols,
            include_legend=self.state_obj.export_show_legend
        )

    def export_bundle(self):
        self.pull_controls_to_state()
        folder=filedialog.askdirectory(title="Choose export folder")
        if not folder:return
        safe="".join(ch if ch.isalnum() or ch in "-_ " else "_" for ch in self.state_obj.name).strip() or "D12_Map"
        out=Path(folder)/safe
        out.mkdir(parents=True,exist_ok=True)
        (out/f"{safe}.txt").write_text(self.engine.export_text(self.state_obj),encoding="utf-8")
        data=self.state_obj.to_json_dict(); data["final_ascii"]=self.engine.ascii_grid(self.state_obj)
        (out/f"{safe}.json").write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding="utf-8")
        self.export_html(str(out/f"{safe}_print.html"))
        png_ok=self.export_png(out/f"{safe}_tiles.png")
        readme=(
            "D12 MAPWORKS EXPORT BUNDLE\n\n"
            ".txt  = human/AI-readable authoritative ASCII map + legend + notes\n"
            ".json = structured map state, seed, densities, coordinates and final ASCII\n"
            ".html = browser print view\n"
            + (".png  = tile preview\n" if png_ok else ".png  = not created (install Pillow for PNG export)\n")
            + "\nFor AI rendering: provide the TXT file and ask the image/map tool to preserve the grid, symbols, coordinates, and legend while applying the desired visual style.\n"
        )
        (out/"README_EXPORT.txt").write_text(readme,encoding="utf-8")
        self.status.set(f"Export bundle created: {out}")
        messagebox.showinfo("Export Complete",f"Created:\n{out}\n\nTXT and JSON are the authoritative handoff files.")

    def new_map(self):
        self.unpin_tile_lens()
        self.state_obj=MapState(); self.current_file=None; self.engine.generate(self.state_obj); self.sync_controls_from_state(); self.refresh_all()

    def save_map(self, save_as=False):
        self.pull_controls_to_state()
        p=self.current_file
        if save_as or not p:
            chosen=filedialog.asksaveasfilename(defaultextension=".d12map",filetypes=[("D12 Mapworks Map","*.d12map"),("JSON","*.json")],initialfile=f"{self.state_obj.name}.d12map")
            if not chosen:return
            p=Path(chosen); self.current_file=p
        p.write_text(json.dumps(self.state_obj.to_json_dict(),indent=2,ensure_ascii=False),encoding="utf-8")
        self.status.set(f"Saved {p}")

    def open_map(self):
        self.unpin_tile_lens()
        p=filedialog.askopenfilename(filetypes=[("D12 Mapworks Map","*.d12map *.json"),("All files","*.*")])
        if not p:return
        try:
            d=json.loads(Path(p).read_text(encoding="utf-8"))
            d.pop("final_ascii",None)
            self.state_obj=MapState.from_json_dict(d)
            self.current_file=Path(p)
            self.sync_controls_from_state(); self.refresh_all(); self.status.set(f"Loaded {p}")
        except Exception as e:
            messagebox.showerror("Open Failed",str(e))


def main():
    app=D12MapworksApp()
    app.mainloop()

if __name__ == "__main__":
    main()
